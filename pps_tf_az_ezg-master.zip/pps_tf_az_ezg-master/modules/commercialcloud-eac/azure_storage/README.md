# azure_storage

## Overview

Terraform module for implementing Azure Storage and related resources.  Using this module enforces security practices such as HTTPS only and encryption at rest.

## Azure Storage Features

### Storage Account `[/]`

An Azure storage account provides a unique namespace to store and access your Azure Storage data objects. All objects in a storage account are billed together as a group.

**Note:** The storage account is an Azure global account, it must be a globally unique name as it forms an externally addressable hostname appended to a Microsoft domain name. The string must be 3-24 characters, lowercase, and needs to conform to general domain name [requirements](https://www.ietf.org/rfc/rfc1035.txt).

### Storage Container `[/modules/storage_container]`

A container organizes a set of blobs, similar to a folder in a file system. All blobs reside within a container. Blob storage is optimized for storing massive amounts of unstructured data, such as text or binary data.

## Terraform Modules

### Storage Account Inputs

**Note:** If you are using the `virtual_network_subnet_ids` property, the virtual network must have a [service endpoint](https://docs.microsoft.com/en-us/azure/virtual-network/virtual-network-service-endpoints-overview) for `Microsoft.Storage`. Also, the virtual network and the storage account locations must be a [regional pair](https://docs.microsoft.com/en-us/azure/best-practices-availability-paired-regions).

**Note:** We are restricting the storage account kinds to `StorageV2` (General-purpose v2) and `BlobStorage`. We are not allowing `Storage` (General-purpose v1) since Microsoft recommends General-purpose v2 over General-purpose v1. More details on storage account options can be found [here](https://docs.microsoft.com/en-us/azure/storage/common/storage-account-options#evaluating-and-migrating-to-gpv2-storage-accounts.). Upgrading to General-purpose v2 can be done with no downtime or API changes as stated [here](https://docs.microsoft.com/en-us/azure/storage/common/storage-account-options#migrating-existing-data). Users should not use Terraform to perform the update as changing `account_kind` triggers a new resource to be created.
 
| Property | Description | Default |
| --- | --- | --- |
| name | Specifies the name of the storage account. Changing this forces a new resource to be created. This must be unique across the entire Azure service, not just within the resource group. | `{random 12 characters}{namespace}` |
| namespace | Namespace for this terraform run. | |
| resource_group_name | The name of the resource group in which to create the storage account. Changing this forces a new resource to be created. | |
| account_kind | Defines the Kind of account. Valid options are `StorageV2` and `BlobStorage`. Changing this forces a new resource to be created. | `StorageV2` |
| account_tier | Defines the Tier of this storage account, either `Standard` or `Premium`. | `Standard` |
| account_replication_type | Defines the type of replication to use for this storage account. Valid options are `LRS`, `GRS`, `RAGRS` and `ZRS`. | `LRS` |
| access_tier | Defines the access tier for BlobStorage and StorageV2 accounts. Valid options are `Hot` and `Cool`. | `Hot` |
| account_encryption_source | The Encryption Source for this Storage Account. Possible values are `Microsoft.Keyvault` and `Microsoft.Storage`. | `Microsoft.Storage` |
| location | Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created. | `centralus` |
| tags | Map of tags to apply to storage resources. | |
| global_tags | Map of tags to apply to all resources that have tags parameters. | |
| virtual_network_subnet_ids | A list of subnet ids that are allowed to use the storage account. | |
| ip_rules | List of IPs to allow storage account access from. | Optum ips defined in [variables.tf](/variables.tf) | 
| bypass | Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of `Logging`, `Metrics`, `AzureServices`, or `None`. | `["AzureServices"]` |

### Storage Account Outputs

**Note:** [Terraform](https://www.terraform.io/docs/providers/azurerm/r/storage_account.html#attributes-reference) does not expose an output for `secondary_file_endpoint`. 

| Output | Description |
| --- | --- |
| id | The storage account Resource ID. |
| name | The name of the storage account. | 
| primary_location | The primary location of the storage account. |
| primary_blob_endpoint | The endpoint URL for blob storage in the primary location. | 
| primary_queue_endpoint | The endpoint URL for queue storage in the primary location. |
| primary_table_endpoint | The endpoint URL for table storage in the primary location. |
| primary_file_endpoint | The endpoint URL for file storage in the primary location. |
| primary_access_key | The primary access key for the storage account. |
| primary_connection_string | The connection string associated with the primary location. | 
| primary_blob_connection_string | The connection string associated with the primary blob location. |  
| secondary_location | The secondary location of the storage account. |
| secondary_access_key | The secondary access key for the storage account. | 
| secondary_connection_string | The connection string associated with the secondary location. |

### Storage Container Inputs

| Property | Description | Default |
| --- | --- | --- |
| name | The name of the storage container. Must be unique within the storage service the container is located. | `container` |
| namespace | Namespace for this terraform run. | |
| resource_group_name | Name of the Azure resource group to reference the storage account. | |
| storage_account_name | Name of the storage account to create storage related resources. | |

### Storage Container Outputs

| Output | Description |
| --- | --- |
| id | The storage container Resource ID. |
| name | The storage container name. |

## Testing

For unit tests, ensure that ruby and bundler have been installed, install the required gems and run the tests:

```
> ruby --version
> bundle install
> rspec
```

## Integration tests

Integration tests use pytest. See the [README](/tests/README.md) in the `tests/` directory for more details.

All tests should pass.

## Examples

Examples are included in this repository, for more information see the examples folder.

Before running the examples, ensure the following environment variables from creating your service principal are exported:

```
export ARM_SUBSCRIPTION_ID="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
export ARM_CLIENT_ID="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
export ARM_CLIENT_SECRET="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
export ARM_TENANT_ID="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
```

**NOTE:** If using Windows, please refer to this [Microsoft documentation page](https://msdn.microsoft.com/en-us/library/windows/desktop/ms682653(v=vs.85).aspx) to setup your environment variables.

## Innersource Guidelines

All contributions to the CommercialCloud repositories must follow the guidelines outlined in the following guides:
* [Commercial Cloud Terraform Developers Guide](https://github.optum.com/CommercialCloud-EAC/welcome/tree/master/DEVELOPER_GUIDE.md)
* [Contributing](https://github.optum.com/CommercialCloud-EAC/welcome/tree/master/CONTRIBUTING.md)
* [Contributor Code of Conduct](https://github.optum.com/CommercialCloud-EAC/welcome/tree/master/CODE_OF_CONDUCT.md)

## EIS Security Endorsement

This module helps to enforce the following EIS mandates:

| Req ID | Requirement | How module addresses requirement |
|-------------|-----------|-----------|
|**2.1** | *key strength*: Cloud native functionality protecting the confidentiality, authenticity and integrity of data must be enabled to encrypt data at rest and in motion. | Storage module enforces AES-256 encryption at rest, HTTPS when in motion|
|**2.2** | *key management*: Key Management: Optum Technology will manage keys and certificates associated with encryption. Storage at Optum technology data centers or on approved hardware service modules required. Auditing of all key management activities required. | This module does not allow us to directly manage the key used to encrypt a storage resource.  A storage resource is created and a new key is managed by Azure.|
|**2.3** | *data in transit*: Cloud native functionality protecting the confidentiality, authenticity and integrity of data in transit must be implemented. | Storage module enforces HTTPS.|
|**2.4** | *data at rest*: Cloud native functionality protecting the confidentiality, authenticity and integrity of data at rest must be implemented. | Storage module enforces AES-256 encryption at rest.  Public Access to a module is restricted (by default).|
|**3.1** | *Information System Boundaries*: A native collection of solutions shall be selected to provide information system boundaries for information services, users, and information systems to prevent information leakage and unauthorized access.| Boundry protected by RBAC.  A storage account cannot be accessed unless a group or user is given a role to do so.  |
