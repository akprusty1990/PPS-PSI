# Examples

## Directions

Ensure the required environment variables are exported as specified in the README.

Then run the following commands:

```
> cd <example folder>
> terraform init
> terraform plan
> terraform apply
```

The resources can then be destroyed by running:

```
> terraform destroy
```

## Descriptions

| Example Name | Description |
| --- | --- |
| storage_account_and_container | Creates a storage account and a container. |
