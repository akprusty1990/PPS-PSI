## 2.0.1 (November 5, 2018)
FIX: 
* Ensure that blob storage can only be created as private.

## 2.0.0 (July 24, 2018)
FIX: 
* Storage account default action for network rules is Deny

FEATURE:
* Added [parameter](https://www.terraform.io/docs/providers/azurerm/r/storage_account.html#virtual_network_subnet_ids) to storage account to set which Vnet subnet IDs have access to storage account
* Added [parameter](https://www.terraform.io/docs/providers/azurerm/r/storage_account.html#ip_rules) to storage account for whitelisted ips
* Added an integration test for `storage_account_and_container` example
* Added tagging to the storage account. The account is tagged with the module version

BREAKING CHANGE: 
* Updated variable, output, and file names to follow Terraform naming convention
* Updated repo structure to follow Terraform guidelines
* Removed `storage_container_access_type` parameter to require container to always be private

## 1.1.6 (June 5, 2018)
FEATURES:

* **Added Storage Container Name Output :** Added storage container "name" as an output to the container submodule.
* **Deprecated Storage Container Id Output :** Added storage container "id" as an output to the container submodule and deprecated "storage_container_id"

## 1.1.5 (May 17, 2018)

FIX: removed unavailable outputs from main `README.md` and added descriptions for outputs 

## 1.1.4 (Apr 25, 2018)

FIX:
* Solves issue storage_account_primary_blob_endpoint not set for general purpose storage account. Allows for storage accounts with `storage_account_kind` set to `storage` to have additional outputs `storage_account_primary_blob_endpoint`, `storage_account_primary_table_endpoint`, and `storage_account_primary_blob_connection_string`.

## 1.1.3 (Apr 25, 2018)

BREAKING CHANGE: removed outputs that caused errors when using blobstorage for storage account kind. Removed outputs include:
* storage_account_secondary_blob_endpoint
* storage_account_secondary_queue_endpoint
* storage_account_secondary_table_endpoint
* storage_account_secondary_blob_connection_string

## 1.1.2 (Apr 5, 2018)

FIX: removed explicit azurerm version (changed to min version)

## 1.1.0 (March 22, 2018)

FIX:
* **Account Module :** Changed local variable from storage_account_tier_type to storage_account_tier to fix issue `local.storage_account_tier_type: no local value of this name has been declared` with creating blobstorage account   

## 1.0.0 (Feb 21, 2018)
FEATURES:

* **Initial Storage Module :** Create a Azure storage account (with semi-random name to reduce collisions), storage container
* **Storage tags :** Both global and storage tags can be applied

Please see github commit and pull request history for more details.