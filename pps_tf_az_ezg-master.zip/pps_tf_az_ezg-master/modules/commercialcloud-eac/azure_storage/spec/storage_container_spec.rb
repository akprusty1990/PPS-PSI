require 'spec_helper'
require "commercial_cloud/test/terraform"
require "commercial_cloud/test/matcher/terraform"

include CommercialCloud::Test

describe 'storage_container' do

  # Setup terraform client
  before(:all) do
    @tf = Terraform.new(
      default_target_dir: "#{__dir__}/fixtures"
    )
  end 

  it 'should verify the plan output' do
    hcl = %{
      module "storage_container" {
        source = "#{__dir__}/../modules/storage_container"
        resource_group_name = "resource_group"
        storage_account_name = "storage_account" 
      }
    }
    plan_out = @tf.plan(hcl: hcl)
    expect(plan_out)
      .to be_terraform_plan
        .to_add(3)
        .to_change(0)
        .to_destroy(0)
        .with_resources({
          "module.storage_container.module.namespace.null_resource.namespace" => {
            "triggers.name" => /"container"/,
            "triggers.namespace" => /""/,
            "id"=> /<computed>/,
            "triggers.%" => /"3"/,
            "triggers.format" => "%s%s"
          },
          "module.storage_container.module.namespace.random_string.random_string" => {
            "upper" => /"false"/,
            "lower" => /"true"/,
            "min_numeric" => /"0"/,
            "min_lower" => /"0"/,
            "number" => /"true"/,
            "length" => /"12"/,
            "result"=> /<computed>/,
            "min_upper" => /"0"/,
            "id"=> /<computed>/,
            "special" => /"false"/,
            "min_special" => /"0"/
          },
          "module.storage_container.azurerm_storage_container.storage_container" => {
            "resource_group_name" => /"resource_group"/,
            "name" => "${module.namespace.name}",
            "properties.%"=> /<computed>/,
            "container_access_type" => /"private"/,
            "storage_account_name" => /"storage_account"/,
            "id"=> /<computed>/
          }
        })
  end
end