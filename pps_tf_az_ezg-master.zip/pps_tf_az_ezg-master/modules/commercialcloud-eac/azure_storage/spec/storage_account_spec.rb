require 'spec_helper'
require "commercial_cloud/test/terraform"
require "commercial_cloud/test/matcher/terraform"

include CommercialCloud::Test

describe 'storage_account' do

  # Setup terraform client
  before(:all) do
    @tf = Terraform.new(
      default_target_dir: "#{__dir__}/fixtures"
    )
  end 

  it 'should verify the plan output' do
    hcl = %{
      module "storage_account" {
        source = "#{__dir__}/../"
        resource_group_name = "resource_group" 
      }
    }
    plan_out = @tf.plan(hcl: hcl)
    expect(plan_out)
      .to be_terraform_plan
        .to_add(3)
        .to_change(0)
        .to_destroy(0)
        .with_resources({
          "module.storage_account.module.namespace.null_resource.namespace" => {
            "triggers.name" => /""/,
            "triggers.namespace" => /""/,
            "id"=> /<computed>/,
            "triggers.%" => /"3"/,
            "triggers.format" => "%s%s"
          },
          "module.storage_account.module.namespace.random_string.random_string" => {
            "upper" => /"false"/,
            "lower" => /"true"/,
            "min_numeric" => /"0"/,
            "min_lower" => /"0"/,
            "number" => /"true"/,
            "length" => /"12"/,
            "result"=> /<computed>/,
            "min_upper" => /"0"/,
            "id"=> /<computed>/,
            "special" => /"false"/,
            "min_special" => /"0"/
          },
          "module.storage_account.azurerm_storage_account.storage_account" => {
            "secondary_location"=> /<computed>/,
            "secondary_access_key"=> /<computed>/,
            "primary_location"=> /<computed>/,
            "network_rules.0.ip_rules.4232842970" => /"203.39.148.18"/,
            "network_rules.0.ip_rules.4106001999" => /"168.183.84.12"/,
            "network_rules.0.ip_rules.201046838" => /"161.249.72.14"/,
            "tags.%" => /"1"/,
            "id"=> /<computed>/,
            "network_rules.0.ip_rules.899323296" => /"198.203.175.175"/,
            "secondary_table_endpoint"=> /<computed>/,
            "network_rules.0.ip_rules.3534983048" => /"149.111.26.128"/,
            "network_rules.0.ip_rules.1837314537" => /"149.111.28.128"/,
            "network_rules.0.ip_rules.2564401851" => /"12.163.96.0\/24"/,
            "identity.#"=> /<computed>/,
            "enable_blob_encryption" => /"true"/,
            "network_rules.0.ip_rules.2522385354" => /"161.249.16.0\/23"/,
            "location" => /"centralus"/,
            "primary_queue_endpoint"=> /<computed>/,
            "network_rules.0.ip_rules.2705977115" => /"220.227.15.70"/,
            "network_rules.0.bypass.#" => /"1"/,
            "account_tier" => /"Standard"/,
            "network_rules.0.ip_rules.3709761039" => /"161.249.176.14"/,
            "enable_file_encryption" => /"true"/,
            "network_rules.0.ip_rules.2981714275" => /"198.203.181.181"/,
            "network_rules.0.ip_rules.1000968704" => /"161.249.96.14"/,
            "secondary_queue_endpoint"=> /<computed>/,
            "network_rules.0.ip_rules.817349716" => /"161.249.144.14"/,
            "secondary_blob_connection_string"=> /<computed>/,
            "primary_table_endpoint"=> /<computed>/,
            "network_rules.#" => /"1"/,
            "account_kind" => /"StorageV2"/,
            "primary_connection_string"=> /<computed>/,
            "enable_https_traffic_only" => /"true"/,
            "resource_group_name" => /"resource_group"/,
            "network_rules.0.bypass.625562768" => /"AzureServices"/,
            "tags.cc-eac_azure_storage" => /"v2.0.0"/,
            "name" => "${module.namespace.name}",
            "account_replication_type" => /"LRS"/,
            "network_rules.0.ip_rules.2706679788" => /"198.203.177.177"/,
            "primary_file_endpoint"=> /<computed>/,
            "primary_blob_connection_string"=> /<computed>/,
            "network_rules.0.ip_rules.597877868" => /"161.249.80.14"/,
            "network_rules.0.ip_rules.2528094605" => /"149.111.30.128"/,
            "network_rules.0.ip_rules.3981205305" => /"161.249.192.14"/,
            "primary_access_key"=> /<computed>/,
            "primary_blob_endpoint"=> /<computed>/,
            "access_tier" => /"Hot"/,
            "secondary_connection_string"=> /<computed>/,
            "secondary_blob_endpoint"=> /<computed>/,
            "account_encryption_source" => /"Microsoft.Storage"/,
            "network_rules.0.ip_rules.#" => /"17"/
          }
        })
  end
end