﻿Set-Location "C:\Users\ezittoun\Workspaces\github\ezittoun\pps_tf_az_ezg\scripts"

$moduleDir = $PWD.Path
$vms = Get-AzVM -Status
foreach( $vm in $vms ) {
    if ( $vm.Name -match "psi-user55" ) {
        if ( $vm.PowerState -eq "VM running" ) {
            if ( -Not ( $vm.Extensions.Id -match "/extensions/AzureDiskEncryption$" )) {
                $vm.Name
                $scriptBlock = { 
                    param($moduleDir, $vm)
                    Import-Module "$moduleDir\pps_azure.psm1" -Force
                    Enable-PPSVMExtDiskEncryption -VMResourceGroupName $vm.ResourceGroupName -VMName $vm.Name
                }
                Start-Job -ScriptBlock $scriptBlock -ArgumentList $moduleDir, $vm
            }
        }
    }
}
Get-Job

function Get-VMEncryptionStatus {
    $moduleDir = $PWD.Path
    Import-Module "$moduleDir\pps_azure.psm1" -Force
    $vms = Get-AzVM -Status
    foreach( $vm in $vms ) {
        if ( $vm.Name -match "psi-user5" ) {
            $vm.Name
            Get-PPSVMExtDiskEncryptionStatus -VM $vm
        }
    }
}    