
$moduleDir = $PWD.Path
$vms = Get-AzVM -Status
foreach( $vm in $vms ) {
    if (( $vm.Name -match "psi-user4" ) -or ( $vm.Name -match "psi-user5" )) {
        if ( -Not ( $vm.Name -match "psi-user43" )) {
            $vm.Name
            if ( $vm.PowerState -eq "VM deallocated" ) {
                $vm.Name
                Start-AzVM -Id $vm.Id -AsJob
            }
        }
     }
}