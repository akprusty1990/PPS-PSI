
function Connect-PPSAzure {
    Write-Host "Logging into Azure using ARM environment variables..."
    $azSecPass = ConvertTo-SecureString "$env:ARM_CLIENT_SECRET" -AsPlainText -Force
    $azCred = New-Object System.Management.Automation.PSCredential ("$env:ARM_CLIENT_ID", $azSecPass)
    $azTenant = "$env:ARM_TENANT_ID"
    $azSubscription = "$env:ARM_SUBSCRIPTION_ID"
    Connect-AzAccount -Credential $azCred -TenantId $azTenant -ServicePrincipal -Subscription $azSubscription
    Set-AzContext -SubscriptionId $azSubscription
    $ctx = Get-AzContext
}

function Disconnect-PPSAzure {
    Write-Host "Disconnecting Azure accounts..."
    $acct = $(Get-AzContext).Account
    while ( -Not ([string]::IsNullOrEmpty($acct)) ) {
        Write-Host " disconnecting $acct.Id"
        $acct = Disconnect-AzAccount
    }
}

function Enable-PPSVMExtLogAnalytics {
    param(
        $VMResourceGroupName,
        $VMName,
        $WorkspaceResourceGroupName = 'pps-common-rg-ppsezgnp',
        $WorkspaceName              = 'pps-loganalytics-workspace-ppsezgnp'
    )
    $Workspace = Get-AzOperationalInsightsWorkspace -ResourceGroupName $WorkspaceResourceGroupName -Name $WorkspaceName
    $WorkspaceId = $Workspace.CustomerId
    $WorkspaceKey = (Get-AzOperationalInsightsWorkspaceSharedKeys -ResourceGroupName $WorkspaceResourceGroupName -Name $WorkspaceName).PrimarySharedKey
    $VM = Get-AzVM -ResourceGroupName $VMResourceGroupName -Name $VMName
    $VMLocation = $VM.Location
    $VMExtPublicSettings = @{"workspaceId" = $WorkspaceId}
    $VMExtProtectedSettings = @{"workspaceKey" = $WorkspaceKey}
    Set-AzVMExtension -ResourceGroupName $VMResourceGroupName -VMName $VMName -Location $VMLocation `
        -ExtensionName "MicrosoftMonitoringAgent" -Publisher "Microsoft.EnterpriseCloud.Monitoring" `
        -ExtensionType "MicrosoftMonitoringAgent" -TypeHandlerVersion 1.0 `
        -Settings $VMExtPublicSettings -ProtectedSettings $VMExtProtectedSettings
}