
$moduleDir = $PWD.Path
$vms = Get-AzVM -Status
foreach( $vm in $vms ) {
    if ( $vm.Name -match "psi-user4" ) {
        if ( -Not ( $vm.Name -match "psi-user43" )) {
            if ( $vm.PowerState -eq "VM running" ) {
                $vm.Name
                Stop-AzVM -Id $vm.Id -Force -AsJob
            }
        }
     }
}