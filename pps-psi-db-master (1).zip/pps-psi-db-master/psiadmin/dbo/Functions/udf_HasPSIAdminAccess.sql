﻿-- ==============================================================================
-- Author:        Tuan Nha Nguyen
-- Create date: 10/12/2020
-- Description:
-- Check if the user has the permission (1: SuperAdmin, 2: Support, 3: Admin) to access PSIAdmin
-- ==============================================================================
/*********************************************************************
  --Test Case 1:
  SELECT dbo.udf_HasPSIAdminAccess(1)
  SELECT dbo.udf_HasPSIAdminAccess(2)
  SELECT dbo.udf_HasPSIAdminAccess(55)
*********************************************************************************/
/*********************************************************************
  --Test Case 2:
  SELECT dbo.udf_HasPSIAdminAccess(NULL)
  SELECT dbo.udf_HasPSIAdminAccess(53)
*********************************************************************************/

CREATE FUNCTION dbo.udf_HasPSIAdminAccess (@ADMUID int)
RETURNS bit
AS
BEGIN
  RETURN (SELECT
    COUNT(1)
  FROM [ADM_User] WITH (NOLOCK)
  WHERE [ADMUID] = @ADMUID
  AND [ADMRID] IN (SELECT
    [ADMRID]
  FROM [ADM_Role] WITH (NOLOCK)
  WHERE [ADMRID] IN (1, 2, 3)) -- SuperAdmin, Support, Admin
  );
END
