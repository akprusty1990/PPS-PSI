﻿-- ==============================================================================================================
-- Author: Amy zhao
-- Create date: 09/18/2020
-- Handle Identity based on the param @Action 
--    @Action = 'HealthIDCreate': add a new Health ID to the @ADMUID. This action should come from email link
--        this action will update the ProviderKey
--    @Action = 'HealthIDLogin': for login purpose. This action should come from the redirect from Health ID site
--    both actions will update the user info: fname, lname, username and email
-- ==============================================================================================================
/************************************************************
--Test case 1: Action = HealthIDCreate: Id, ProviderKey, UserName are required
DECLARE @loginUserInfoJson varchar(max)=N'{"AuthenticationType":null,"IsAuthenticated":false,"Name":null,"Id":1,"ProviderKey":"5fbf5416-d069-4946-873f-bb0711d22f75","UserName":"optid_stg_dzhao2","Email":"amy.zhao@optum.com","FName":"Amy","LName":"Zhao","UserAction":"HealthIDCreate"}'
EXEC [dbo].[SP_ADM_User_IdentityHandle] @loginUserInfoJson

--Test case 2: Action = HealthIDLogin: ProviderKey, UserName are required
DECLARE @loginUserInfoJson varchar(max)=N'{"AuthenticationType":null,"IsAuthenticated":false,"Name":null,"Id":0,"ProviderKey":"5fbf5416-d069-4946-873f-bb0711d22f75","UserName":"optid_stg_dzhao2","Email":"amy.zhao@optum.com","FName":"Amy","LName":"Zhao","UserAction":"HealthIDLogin"}'
EXEC [dbo].[SP_ADM_User_IdentityHandle] @loginUserInfoJson

*************************************************************/
CREATE PROCEDURE [dbo].[SP_ADM_User_IdentityHandle] @loginUserInfoJson nvarchar(max)

AS
BEGIN

	SET NOCOUNT ON;
	DECLARE	@ADMUID int,
			@Action varchar(20),
			@UserName varchar(100),
			@ProviderKey varchar(50),
			@FName varchar(200),
			@LName varchar(200),
			@Email varchar(200)

	DECLARE	@currentStep varchar(100),
			@accessRole int

	BEGIN TRY
		DECLARE @ErrorMessage varchar(4000)
		SET @currentStep = 'Parse json string of @loginUserInfoJson.'	
		select             
			@ADMUID = Id
			, @Action = UserAction
			, @ProviderKey = ProviderKey
			, @UserName = UserName
			, @FName = FName
			, @LName = LName
			, @Email = Email from openjson(@loginUserInfoJson)
		with(
			Id Int,
			ProviderKey uniqueidentifier,
			UserName varchar(200),
			FName varchar(200),
			LName varchar(200),
			Email varchar(200),
			UserAction varchar(50)
		)

		SET @currentStep = 'Validate the permission and params.'

		-- validate required param
		IF (LTRIM(ISNULL(@ProviderKey, '')) = ''
			OR LTRIM(ISNULL(@UserName, '')) = '')
		BEGIN
			RAISERROR ('INGX: ProviderKey or UserName is required', 16, 1)
			RETURN
		END

		IF (@Action = 'HealthIDLogin')
		BEGIN

			-- validate if the username exists based on ProviderKey
			IF (NOT EXISTS (SELECT
					*
				FROM [dbo].[ADM_User] WITH (NOLOCK)
				WHERE [ProviderKey] = @ProviderKey)
				)
			BEGIN
				RAISERROR ('INGX: Provider Key does not exist. ', 16, 1)
				RETURN
			END
		END

		IF (@Action = 'HealthIDCreate')
		BEGIN
			-- validate required param
			IF (ISNULL(@ADMUID, 0) = 0
				OR NOT EXISTS (SELECT
					*
				FROM ADM_User WITH (NOLOCK)
				WHERE ADMUID = @ADMUID)
				)
			BEGIN
				RAISERROR ('INGX: ADMUID is required or ADMUID doesn''t exist', 16, 1)
				RETURN
			END

			-- if the ProviderKey exists, but not the current user, raise an error and let the user know
			IF (EXISTS (SELECT
					*
				FROM [dbo].[ADM_User]
				WHERE [ADMUID] <> @ADMUID
				AND ([ProviderKey] = @ProviderKey))
				)
			BEGIN
				RAISERROR ('INGX: Health ID has been used. Please create a new Health ID and try again.', 16, 1)
				RETURN
			END
		END

		BEGIN TRAN SP_HealthIDHandle_Transaction

			SET @currentStep = 'Link the health id Guid to the user'
			IF (@Action = 'HealthIDCreate')
			BEGIN
				UPDATE ADM_User
				SET	[ProviderKey] = @ProviderKey,
					[Status] = @Action,
					[ModifiedTS] = GETUTCDATE()
				WHERE [ADMUID] = @ADMUID
			END

			SET @currentStep = 'Update the user info'
			UPDATE ADM_User
			SET	[UserName] = @UserName,
				[FName] = @FName,
				[LName] = @LName,
				[Email] = @Email,
				[Status] = @Action,
				[ModifiedTS] = GETUTCDATE()
			WHERE ProviderKey = @ProviderKey

		COMMIT TRAN SP_HealthIDHandle_Transaction

		SET @currentStep = 'Return user info.'
		SELECT
			@ADMUID = ADMUID
		FROM ADM_User
		WHERE ProviderKey = @ProviderKey
		EXEC [dbo].[SP_ADM_User_Get]	0,
										@ADMUID
	END TRY
	BEGIN CATCH

		IF (ISNULL(@ErrorMessage, '') = '')
		BEGIN
			SELECT
				@ErrorMessage = 'ERROR' + ERROR_MESSAGE()
		END

		IF EXISTS (SELECT
				[name]
			FROM sys.dm_tran_active_transactions
			WHERE name = 'SP_HealthIDHandle_Transaction')
		BEGIN
			ROLLBACK
		END

		EXEC [oepps].[dbo].[sp_DTA_EventLog_Insert_SP]	'PSIAdmin: SP_ADM_User_IdentityHandle',
														@errorMessage,
														@@TRANCOUNT,
														@currentStep
		RAISERROR (@ErrorMessage, 16, 1)

	END CATCH


END