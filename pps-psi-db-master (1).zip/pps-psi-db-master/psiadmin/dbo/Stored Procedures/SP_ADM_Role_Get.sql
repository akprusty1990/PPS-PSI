﻿-- ==========================================================
-- Author: Amy Zhao
-- Create date: 09/28/2020
-- Return role info
-- ==========================================================
/************************************************************
EXEC [dbo].[SP_ADM_Role_Get] ''
*************************************************************/
CREATE PROCEDURE [dbo].[SP_ADM_Role_Get] @LoginADMUID int
AS
BEGIN

	SET NOCOUNT ON;
	SELECT
		admr.ADMRID
		, admr.RoleName
	FROM 
		[dbo].[ADM_Role] admr WITH(NOLOCK) 

END
GO


