﻿-- =============================================
-- Author:   Venkatesh
-- Create date: 10/30/2020
-- Description:  Save Organization info.

--Test Case 
--DECLARE @LoginADMUID int = 1,
--    @ADMOID int = 3,
--    @SelectedDB varchar(1000),
--SET @SelectedDB=
--N'<Database>
--        <DatabaseName>oepps_new</DatabaseName>
--</Database>';
--EXEC [SP_ADM_Organization_Save] @LoginADMUID, @ADMOID, @SelectedDB, @DatabaseName
-- =============================================

--***********************************************/
CREATE PROCEDURE [dbo].[SP_ADM_Organization_Save] @LoginADMUID int,
@ADMOID int,
@SelectedDB varchar(1000)

AS
BEGIN

  SET NOCOUNT ON;
  BEGIN TRY
    DECLARE @hasPermission bit,
            @ErrorMessage varchar(4000),
            @currentStep varchar(100)

    -- check if @LoginADMUID has proper role
    SET @hasPermission = dbo.udf_HasPSIAdminAccess(@LoginADMUID)
    IF (@hasPermission = 0)
    BEGIN
      SET @currentStep = 'Validate Proper Role'
      SET @ErrorMessage = 'The user does not have proper role to save the info.'
      RAISERROR (@ErrorMessage, 16, 1)
    END

    -- valid param
    SET @currentStep = 'Check input xml is valid.'
    IF (RTRIM(ISNULL(@SelectedDB, '')) = '')
    BEGIN
      SET @ErrorMessage = 'Selected database can not be empty.'
      RAISERROR (@ErrorMessage, 16, 1)
    END

    BEGIN
      SET @currentStep = 'Parse xml and get data.'
      DECLARE @ixmlSelectedDB AS int
      SET @ixmlSelectedDB = NULL
      EXEC sp_xml_preparedocument @ixmlSelectedDB OUTPUT,
                                  @SelectedDB
      SELECT
        * INTO #Databases
      FROM OPENXML(@ixmlSelectedDB, '/Database/data', 2)
      WITH
      (
      [DatabaseName] [varchar](50)
      ) xmlData

      -- clean up xml
      EXEC sp_xml_removedocument @ixmlSelectedDB
      SET @SelectedDB = NULL

      --save user access info
      BEGIN TRAN ADM_Organization_Save
        SET @currentStep = 'Delete existing record.'
        DELETE FROM ADM_Organization_Database
        WHERE ADMOID = @ADMOID 
        SET @currentStep = 'Insert new record.'
        INSERT INTO ADM_Organization_Database ([ADMOID],
        [DatabaseName],
        [InsertedTS])
          SELECT
            @ADMOID,
            [DatabaseName],
            GETUTCDATE()
          FROM #Databases
      COMMIT TRAN ADM_Organization_Save
    END
  END TRY

  BEGIN CATCH
    IF (ISNULL(@ErrorMessage, '') = '')
    BEGIN
      SELECT
        @ErrorMessage = @@ERROR
    END

    IF EXISTS (SELECT
        [name]
      FROM sys.dm_tran_active_transactions
      WHERE name = 'ADM_Organization_Save')
    BEGIN
      ROLLBACK
    END

    EXEC [oepps].[dbo].[sp_DTA_EventLog_Insert_SP] 'PSIAdmin: SP_ADM_Organization_Save',
                                                   @ErrorMessage,
                                                   @@TRANCOUNT,
                                                   @currentStep
    RAISERROR (@ErrorMessage, 16, 1)
  END CATCH
END
GO


