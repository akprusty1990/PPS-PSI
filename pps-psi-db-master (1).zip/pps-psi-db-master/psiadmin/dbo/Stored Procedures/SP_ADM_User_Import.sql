﻿-- ==============================================================================
-- Author: Tuan Nha Nguyen
-- Create date: 11/18/2020
-- Description: 
-- Import Users from spreadsheet
-- ==============================================================================

/*********************************************************************
  --Test Case:
  EXEC  [dbo].[SP_ADM_User_Import] 1, 1,
  '<importusers>
  <data>
    <existedUser>false</existedUser>
	<FirstName>Nick</FirstName>
	<LastName />
	<UserEmail>nick@test.com</UserEmail>
	<Note />
  </data>
  <data>
	<existedUser>false</existedUser>
	<FirstName>Mary</FirstName>
	<LastName>Jones</LastName>
	<UserEmail>Mary@test.com</UserEmail>
	<Note />
  </data>
  <data>
	<existedUser>false</existedUser>
	<FirstName>Peter</FirstName>
	<LastName>Williams</LastName>
	<UserEmail>peter@test.com</UserEmail>
	<Note />
  </data>
  </importusers>'
*********************************************************************************/

CREATE PROCEDURE [dbo].[SP_ADM_User_Import] @LoginADMUID int = 0, @ADMOID int,
@ImportUsers varchar(max) = ''
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @hasPermission bit,
          @ErrorMessage varchar(4000),
          @currentStep varchar(100),
          @docHandle AS int,
          @spName varchar(100)

  SELECT
    @spName = OBJECT_NAME(@@PROCID);

  DECLARE @tblUsers TABLE (
    [ID] int IDENTITY (1, 1),
    [IsExisted] [bit],
    [FName] [varchar](200),
    [LName] [varchar](200),
    [Email] [varchar](200)
  );

  BEGIN TRY
    -- check if @LoginADMUID has proper role to access
    SET @hasPermission = dbo.udf_HasPSIAdminAccess(@LoginADMUID)
    IF (@hasPermission = 0)
    BEGIN
      SET @currentStep = 'Validate Proper Role'
      SET @ErrorMessage = 'The user does not have proper role to review the result.'
      RAISERROR (@ErrorMessage, 16, 1)
    END
    -- parse imported users
    IF (RTRIM(ISNULL(@ImportUsers, '')) <> '')
    BEGIN
      SET @currentStep = 'Parse Users List'
      DECLARE @rowCnt int = 0,
              @index int = 1

      EXEC sp_xml_preparedocument @docHandle OUTPUT,
                                  @ImportUsers
      INSERT INTO @tblUsers
        SELECT
          *
        FROM OPENXML(@docHandle, '/importusers/data', 2)
        WITH
        (
        [existedUser] [bit],
        [FirstName] [varchar](200),
        [LastName] [varchar](200),
        [UserEmail] [varchar](200)
        ) xmlData
      EXEC sp_xml_removedocument @docHandle

      BEGIN TRAN ADM_Import_Users;

        DECLARE @roleId int
        SELECT
          @roleId = ADMRID
        FROM dbo.[ADM_Role]
        WHERE [RoleName] LIKE 'Regular';

        INSERT INTO dbo.[ADM_User] ([FName], [LName], [Email], [ADMOID], [ADMRID], [Status], [InsertedTS])
          SELECT
            iu.[FName],
            iu.[LName],
            iu.[Email],
            @ADMOID,
            @roleId,
            'Create',
            GETDATE()
          FROM @tblUsers iu
          LEFT JOIN dbo.[ADM_User] au
            ON LTRIM(iu.[Email]) = LTRIM(au.[Email])
          WHERE au.[Email] IS NULL
          AND [IsExisted] = 0

      COMMIT TRAN ADM_Import_Users;

      SELECT
        admu.[ADMUID],
        admu.[FName],
        admu.[LName],
        admu.[Email],
        admu.[UserName],
        admu.[ProviderKey],
        admu.[Status],
        admu.[InsertedTS],
        admu.[ModifiedTS],
        admu.[ADMOID],
        admo.[OrganizationName],
        admu.[ADMRID],
        admr.[RoleName]
      FROM [dbo].[ADM_User] admu WITH (NOLOCK)
      INNER JOIN @tblUsers tu
        ON admu.[Email] = tu.[Email]
      INNER JOIN [dbo].ADM_Organization admo WITH (NOLOCK)
        ON admu.ADMOID = admo.ADMOID
      INNER JOIN [dbo].ADM_Role admr WITH (NOLOCK)
        ON admu.ADMRID = admr.ADMRID
      WHERE tu.[IsExisted] = 0

    END
  END TRY
  BEGIN CATCH
    SELECT
      @ErrorMessage = 'ERROR: ' + ERROR_MESSAGE()

    IF EXISTS (SELECT
        [name]
      FROM sys.dm_tran_active_transactions
      WHERE name = 'ADM_Import_Users')
    BEGIN
      ROLLBACK TRAN ADM_Import_Users
    END

    EXEC [oepps].[dbo].[sp_DTA_EventLog_Insert_SP] @spName,
                                                   @ErrorMessage,
                                                   0,
                                                   @currentStep
    RAISERROR (@ErrorMessage, 16, 1)
  END CATCH
END