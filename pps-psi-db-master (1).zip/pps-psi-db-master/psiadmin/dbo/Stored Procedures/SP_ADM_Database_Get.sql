﻿-- ==============================================================================
-- Author:        Tuan Nha Nguyen
-- Create date: 09/30/2019
-- Description: 
-- Gets Databases Info
-- Modification: 10/12/2020 - Added verification step to check if @LoginADMUID has the permission to access the SP.
-- Modification: 10/16/2020 - Added @ADMOID as requirement in US692330.
-- Modification: 10/21/2020 - Refactored SP with updated test cases, removed checking permission.
-- ==============================================================================
/*********************************************************************
1.  On Organizations page: ADMOID is not empty, ADMUID is null 
•  If LoginADMUID is SuperAdmin || Support, return all database list on the server starts oepps (left side) 
•	If the ADMOID has the db name, IsSelected = true(right side) 
2.	On Users Page: ignore @ADMOID, ADMUID is not empty 
•	return all database list for the organization that user belongs on the server(right side) 
•	If the user has the db access, IsSelected = true(right side) 
3.	For the database dropdownlist on the top right of the page 
•	Should be same as #2 
**********************************************************************/
/*********************************************************************
  --Test Case 1: On Organization page: gets all dbs starting with oepps_ for SuperAdmin(1)/Support(2)
  Declare @LoginADMUID int = 1,
		@ADMOID int = 1
  EXEC sp_ADM_Database_Get @LoginADMUID, Null, @ADMOID
*********************************************************************************/
/*********************************************************************
  --Test Case 2: On Users page: get all dbs for the Organization that user belongs to (userId=53, role=4)
  Declare @LoginADMUID int = 53,
      @ADMUID int = 55
  EXEC sp_ADM_Database_Get @LoginADMUID, @ADMUID
*********************************************************************************/
/*********************************************************************
  --Test Case 3: On Organization page: Showing error if user is NOT SuperAdmin/Support and trying to get all DBs from server (not passing @ADMUID)
  Declare @LoginADMUID int = 53,
		@ADMOID int = 2
  EXEC sp_ADM_Database_Get @LoginADMUID, Null, @ADMOID
*********************************************************************************/

CREATE PROCEDURE [dbo].[sp_ADM_Database_Get] @LoginADMUID int = 0,
@ADMUID int = NULL,
@ADMOID int = NULL
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @accessRole int = 0,
          @ErrorMessage varchar(4000),
          @currentStep varchar(100),
          @uADMOID int

  BEGIN TRY
    IF @ADMOID IS NOT NULL -- On Organization page
    BEGIN
      SELECT
        @accessRole = [ADMRID]
      FROM [ADM_User] WITH (NOLOCK)
      WHERE [ADMUID] = @LoginADMUID
      IF (@accessRole = 1
        OR @accessRole = 2) -- @LoginADMUID is SuperAdmin or Support
      BEGIN
        SELECT
          sdb.[name] AS [DatabaseName],
          aod.[ADMOID],
          NULL AS [ADMUID],
          CASE
            WHEN [ADMOID] IS NULL THEN 0
            ELSE 1
          END AS IsSelected,
          NULL AS [PermissionBinaryNumber]
        FROM (SELECT
          [name]
        FROM sys.databases
        WHERE [name] LIKE 'oepps[_]%') AS sdb
        LEFT JOIN [ADM_Organization_Database] aod WITH (NOLOCK)
          ON sdb.[name] = LTRIM(RTRIM(aod.[DatabaseName]))
        WHERE (aod.[ADMOID] IS NULL)
        OR (aod.[ADMOID] = @ADMOID) -- To ensure NOT showing dbs already assigned to other Org. Discuss with Phil if the SuperAdmin is able to reassign DB.
      END
      ELSE
      BEGIN
        SET @currentStep = 'Validate Proper Role'
        SET @ErrorMessage = 'The user does not have proper role to review the result.'
        RAISERROR (@ErrorMessage, 16, 1)
      END
    END
    ELSE
    IF @ADMUID IS NOT NULL -- On Users page
    BEGIN
      SELECT
        sdb.[name] AS [DatabaseName],
        aod.[ADMOID],
        aud.[ADMUID],
        CASE
          WHEN [ADMUID] IS NULL THEN 0
          ELSE 1
        END AS IsSelected,
        aud.[PermissionBinaryNumber]
      FROM (SELECT
        [name]
      FROM sys.databases
      WHERE [name] LIKE 'oepps[_]%') AS sdb
      INNER JOIN [ADM_Organization_Database] aod WITH (NOLOCK)
        ON sdb.[name] = LTRIM(RTRIM(aod.[DatabaseName]))
      LEFT JOIN [ADM_User_Database] aud WITH (NOLOCK)
        ON sdb.[name] = LTRIM(RTRIM(aud.[DatabaseName]))
      WHERE ((aud.[ADMUID] IS NULL)
      OR (aud.[ADMUID] = @ADMUID))
      AND (aod.[ADMOID] = (SELECT
        au.[ADMOID]
      FROM [ADM_User] au WITH (NOLOCK)
      WHERE au.[ADMUID] = @ADMUID)
      )
    END
  END TRY
  BEGIN CATCH
    SELECT
      @ErrorMessage = 'ERROR: ' + ERROR_MESSAGE()
    EXEC [oepps].[dbo].[sp_DTA_EventLog_Insert_SP] 'sp_ADM_Database_Get',
                                                   @ErrorMessage,
                                                   0,
                                                   @currentStep
    RAISERROR (@ErrorMessage, 16, 1)
  END CATCH
END