﻿-- ==============================================================================
-- Author:        Tuan Nha Nguyen
-- Create date: 09/28/2019
-- Description: 
-- Gets user info 
-- Modification: 10/12/2020 - Added verification step to check if @LoginADMUID has the permission to access the SP.
-- Modification: 10/15/2020 - Made changes for pagination, sorting; added table alias for dynamic filters.
-- Modification: 10/27/2020 - Changed OptumId, OptumGuid to UserName and ProviderKey.
-- Modification: 11/19/2020 - Update Cast() in pagelength so Import Users function can get all records.
-- Modification: 10/20/2020 - Guangda: Added IsEnabled column.
-- ==============================================================================
/*********************************************************************
  --Test Case 1:
  DECLARE  @TotalCount int
  EXEC    [dbo].[sp_ADM_User_GetAll]
		@LoginADMUID = 1,
		@ADMUID = NULL,
		@PageStart = 0,
		@PageLength = 10,
		@Filters = N'',
		@ColumnToOrderBy = N'FName',
		@Descending = N'ASC',
		@TotalCount = @TotalCount OUTPUT
  SELECT	@TotalCount as N'TotalRecord'
*********************************************************************************/
/*********************************************************************
  --Test Case 2:
  DECLARE	@TotalCount int
  EXEC	[dbo].[sp_ADM_User_GetAll]
		@LoginADMUID = 1,
		@ADMUID = 2,
		@PageStart = 0,
		@PageLength = 10,
		@Filters = N'',
		@ColumnToOrderBy = N'FName',
		@Descending = N'ASC',
		@TotalCount = @TotalCount OUTPUT

  SELECT	@TotalCount as N'TotalRecord'
*********************************************************************************/
/*********************************************************************
  --Test Case 3:
  DECLARE	@TotalCount int
  EXEC	[dbo].[sp_ADM_User_GetAll]
		@LoginADMUID = 1,
		@ADMUID = NULL,
		@PageStart = 0,
		@PageLength = 10,
		@Filters = N'
  	<filter>
  	  <data>
  		<name>FName</name>
  		<value>Michael</value>
  		<type>string</type>
  	  </data>
  	  <data>
  		<name>LName</name>
  		<value>Ha%</value>
  		<type>string</type>
  	  </data>
  	  <data>
  		<name>Email</name>
  		<value>Michael@test.com</value>
  		<type>string</type>
  	  </data>
  	  <data>
  		<name>UserName</name>
  		<value>112233</value>
  		<type>string</type>
  	  </data>
  	  <data>
  		<name>OrganizationName</name>
  		<value>1</value>
  		<type>string</type>
  	  </data>
  	  <data>
  		<name>RoleName</name>
  		<value>4</value>
  		<type>string</type>
  	  </data>
  	  <data>
  		<name>Status</name>
  		<value>Created</value>
  		<type>string</type>
  	  </data>
  	</filter>',
		@ColumnToOrderBy = N'FName',
		@Descending = N'ASC',
		@TotalCount = @TotalCount OUTPUT

  SELECT	@TotalCount as N'TotalRecord'
*********************************************************************************/

CREATE PROCEDURE [dbo].[sp_ADM_User_GetAll] @LoginADMUID int = 0,
@ADMUID int = NULL,
@PageStart int = 0,
@PageLength int = 10,
@Filters varchar(max) = '',
@ColumnToOrderBy varchar(50) = 'FName',
@Descending varchar(4) = '',
@TotalCount int OUTPUT
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @hasPermission bit,
          @ErrorMessage varchar(4000),
          @currentStep varchar(100),
          @docHandle AS int,
          @sql varchar(max),
          @sqlFilter varchar(1000) = ''

  DECLARE @tblFilters TABLE (
    [ID] int IDENTITY (1, 1),
    [name] [varchar](50),
    [value] [varchar](100),
    [type] [varchar](50)
  );

  BEGIN TRY
    -- check if @LoginADMUID has proper role to access
    SET @hasPermission = dbo.udf_HasPSIAdminAccess(@LoginADMUID)
    IF (@hasPermission = 0)
    BEGIN
      SET @currentStep = 'Validate Proper Role'
      SET @ErrorMessage = 'The user does not have proper role to review the result.'
      RAISERROR (@ErrorMessage, 16, 1)
    END
    -- get filters
    IF (RTRIM(ISNULL(@Filters, '')) <> '')
    BEGIN
      SET @currentStep = 'Parse Filters'
      DECLARE @rowCnt int = 0,
              @index int = 1

      EXEC sp_xml_preparedocument @docHandle OUTPUT,
                                  @Filters
      INSERT INTO @tblFilters
        SELECT
          *
        FROM OPENXML(@docHandle, '/filter/data', 2)
        WITH
        (
        [name] [varchar](50),
        [value] [varchar](200),
        [type] [varchar](50)
        ) xmlData
      EXEC sp_xml_removedocument @docHandle
      UPDATE @tblFilters
      SET [value] = 'au.[' + LTRIM(RTRIM([name])) + '] LIKE ''%' + [value] + '%'''
      WHERE [name] NOT IN ('OrganizationName', 'RoleName')
      UPDATE @tblFilters
      SET [value] = 'au.[ADMOID]=' + [value]
      WHERE [name] LIKE 'OrganizationName'
      UPDATE @tblFilters
      SET [value] = 'au.[ADMRID]=' + [value]
      WHERE [name] LIKE 'RoleName'

      SELECT
        @rowCnt = COUNT(1)
      FROM @tblFilters
      WHILE @index <= @rowCnt
      BEGIN
        SELECT
          @sqlFilter = @sqlFilter + IIF(@sqlFilter = '', '', ' AND ')
        SELECT
          @sqlFilter = @sqlFilter + f.[value]
        FROM @tblFilters f
        WHERE [ID] = @index

        SELECT
          @index = @index + 1
      END
    END

    BEGIN
      DECLARE @sqlTotal varchar(max) = '',
              @sqlSelect varchar(max) = ''
      DECLARE @tmpTbl TABLE (
        rowCnt int
      )
      SET @currentStep = 'Build Query String'
      --TODO: How to identify if a user is Enabled? Will isEnabled field be added?

      SET @sqlSelect = '
		SELECT
		  au.[ADMUID],
		  au.[UserName],
		  au.[ProviderKey],
		  au.[FName],
		  au.[LName],
		  COALESCE(au.[FName], '''') + '' '' + COALESCE(au.[LName], '''') AS [Name],
		  au.[Email],
		  au.ADMOID,
		  ao.[OrganizationName],
		  au.[ADMRID],
		  ar.[RoleName],
		  au.[Status],
		  au.[IsEnabled]'
      SELECT
        @sql = '
		FROM [dbo].[ADM_User] au WITH (NOLOCK)
		INNER JOIN [dbo].[ADM_Organization] ao WITH (NOLOCK)
		  ON au.[ADMOID] = ao.[ADMOID]
		INNER JOIN [dbo].ADM_Role ar WITH (NOLOCK)
		  ON au.[ADMRID] = ar.[ADMRID]
		WHERE ao.[IsEnabled] = 1' + IIF(@ADMUID IS NULL, '', ' AND au.[ADMUID] = ' + CAST(@ADMUID AS varchar(10)))
      IF (@sqlFilter <> '')
        SELECT
          @sql = @sql + ' AND ' + @sqlFilter
      -- Get total records
      SET @sqlTotal = 'SELECT COUNT(1) ' + @sql
      INSERT @tmpTbl EXEC (@sqlTotal)
      SELECT
        @TotalCount = rowCnt
      FROM @tmpTbl

      SET @sql = @sqlSelect + @sql
      + ' ORDER BY ' + @ColumnToOrderBy + IIF(@Descending = '', ' ASC', ' ' + @Descending)

      IF (@PageStart < 0)
        SET @PageStart = 0

      SET @sql = @sql + ' OFFSET ' + CAST(@PageStart AS varchar(10)) + ' ROWS FETCH NEXT ' + CAST(@PageLength AS varchar(10)) + ' ROWS ONLY'
      EXEC (@sql)
    END

  END TRY
  BEGIN CATCH
    SELECT
      @ErrorMessage = 'ERROR: ' + ERROR_MESSAGE()
    EXEC [oepps].[dbo].[sp_DTA_EventLog_Insert_SP] 'sp_ADM_User_GetAll',
                                                   @ErrorMessage,
                                                   0,
                                                   @currentStep
    RAISERROR (@ErrorMessage, 16, 1)
  END CATCH
END