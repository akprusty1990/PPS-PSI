﻿-- =============================================
-- Author:    Guangda Li
-- Create date: 10/16/2020
-- Description:  Save database access info for selected user.
-- 1. Delete existing access info for selected user.
-- 2. Insert new access info for selected user.
-- =============================================
/*****************************************************************************
--Test Case 1 (insert valid record)
DECLARE @LoginADMUID int = 1,
    @ADMUID int = 3,
    @SelectedDB varchar(1000),
	@DatabaseName varchar(50) = 'oepps_bk',
    @IsInAccessibleDB BIT = 0
SET @SelectedDB=
N'<Database>
        <DatabaseName>oepps_bk</DatabaseName>
		<PermissionBinaryNumber>264960</PermissionBinaryNumber>
</Database>
';
EXEC [sp_ADM_UserAccess_Save] @LoginADMUID, @ADMUID, @SelectedDB, @DatabaseName, @IsInAccessibleDB
==================================================================
--Test Case 2 (missing @ADMUID)
DECLARE @LoginADMUID int = 1,
    @ADMUID int = null,
	@SelectedDB varchar(1000),
	@DatabaseName varchar(50) = 'oepps_bk',
    @IsInAccessibleDB BIT = 0
SET @SelectedDB=
N'<Database>
        <DatabaseName>oepps_bk</DatabaseName>
		<PermissionBinaryNumber>264960</PermissionBinaryNumber>
</Database>
';
EXEC [sp_ADM_UserAccess_Save] @LoginADMUID, @ADMUID, @SelectedDB, @DatabaseName, @IsInAccessibleDB
==================================================================
--Test Case 3 (missing selected database info)
DECLARE @LoginADMUID int = 1,
    @ADMUID int = 3,
	@SelectedDB varchar(1000),
	@DatabaseName varchar(50) = 'oepps_bk',
    @IsInAccessibleDB BIT = 0
SET @SelectedDB=
N'<Database>
        <DatabaseName>oepps_bk</DatabaseName>
		<PermissionBinaryNumber>264960</PermissionBinaryNumber>
</Database>
';
EXEC [sp_ADM_UserAccess_Save] @LoginADMUID, @ADMUID, @SelectedDB, @DatabaseName, @IsInAccessibleDB
--***************************************************************************/
CREATE PROCEDURE [dbo].[sp_ADM_UserAccess_Save] @LoginADMUID int,
@ADMUID int,
@SelectedDB varchar(1000),
@DatabaseName varchar(50),
@IsInAccessibleDB bit = 0

AS
BEGIN

  SET NOCOUNT ON;
  BEGIN TRY
    DECLARE @hasPermission bit,
            @ErrorMessage varchar(4000),
            @currentStep varchar(100)

    -- check if @LoginADMUID has proper role
    SET @hasPermission = dbo.udf_HasPSIAdminAccess(@LoginADMUID)
    IF (@hasPermission = 0)
    BEGIN
      SET @currentStep = 'Validate Proper Role'
      SET @ErrorMessage = 'The user does not have proper role to save the info.'
      RAISERROR (@ErrorMessage, 16, 1)
    END
    -- DO NOT PROCEED FURTHER IF ITS INACCESSIBLE DATABASE WE DELETE THIS RECORD FROM TABLE AND EXIT
	IF @IsInAccessibleDB = 1
	BEGIN
		DELETE FROM ADM_User_Database
        WHERE ADMUID = @ADMUID and DatabaseName = @DatabaseName
		RETURN;
	END
    -- valid param
    SET @currentStep = 'Check input xml is valid.'
    IF (RTRIM(ISNULL(@SelectedDB, '')) = '')
    BEGIN
      SET @ErrorMessage = 'Selected database can not be empty.'
      RAISERROR (@ErrorMessage, 16, 1)
    END

    BEGIN
      SET @currentStep = 'Parse xml and get data.'
      DECLARE @ixmlSelectedDB AS int
      SET @ixmlSelectedDB = NULL
      EXEC sp_xml_preparedocument @ixmlSelectedDB OUTPUT,
                                  @SelectedDB
      SELECT
        * INTO #Databases
      FROM OPENXML(@ixmlSelectedDB, '/Database', 2)
      WITH
      (
      [DatabaseName] [varchar](50),
      [PermissionBinaryNumber] int
      ) xmlData

      -- clean up xml
      EXEC sp_xml_removedocument @ixmlSelectedDB
      SET @SelectedDB = NULL

      --check user access 
      IF (ISNULL(@ADMUID, '') = ''
        OR EXISTS (SELECT
          *
        FROM #Databases
        WHERE ISNULL(DatabaseName, '') = ''
        OR ISNULL(PermissionBinaryNumber, 0) = 0)
        )
      BEGIN
        SET @ErrorMessage = 'Param ADMUID, DatabaseName, PermissionBinaryNumber are required.'
        RAISERROR (@ErrorMessage, 16, 1)
      END

      --save user access info
      BEGIN TRAN ADM_UserAccess_Save_Transaction
        SET @currentStep = 'Delete existing access info.'
        DELETE FROM ADM_User_Database
        WHERE ADMUID = @ADMUID and DatabaseName = @DatabaseName
        SET @currentStep = 'Insert new access info.'
        INSERT INTO ADM_User_Database ([ADMUID],
        [DatabaseName],
        [PermissionBinaryNumber],
        [InsertedTS])
          SELECT
            @ADMUID,
            [DatabaseName],
            [PermissionBinaryNumber],
            GETUTCDATE()
          FROM #Databases
      COMMIT TRAN ADM_UserAccess_Save_Transaction
    END
  END TRY

  BEGIN CATCH
    IF (ISNULL(@ErrorMessage, '') = '')
    BEGIN
      SELECT
        @ErrorMessage = @@ERROR
    END

    IF EXISTS (SELECT
        [name]
      FROM sys.dm_tran_active_transactions
      WHERE name = 'ADM_UserAccess_Save_Transaction')
    BEGIN
      ROLLBACK
    END

    EXEC [oepps].[dbo].[sp_DTA_EventLog_Insert_SP] 'PSIAdmin: ADM_UserAccess_Save',
                                                   @ErrorMessage,
                                                   @@TRANCOUNT,
                                                   @currentStep
    RAISERROR (@ErrorMessage, 16, 1)
  END CATCH
END