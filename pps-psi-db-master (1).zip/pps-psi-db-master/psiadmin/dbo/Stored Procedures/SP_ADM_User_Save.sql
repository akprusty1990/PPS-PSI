﻿
--===========================================================================
--Author: Amy Zhao
--Modified by : Guangda Li 
--Create date: 09/30/2020
--Description:  Save the user info
--    If the action is create, insert new user
--    else update the user
--Modification: 10/12/2020 - Check user OptumGuid on updating user info
--Modification: 10/18/2020 - Amy: change OptumGuid to ProviderKey
--Modifocation: 10/29/2020 - Guangda: call Sp_ADM_User_Get after save the user
--Modifocation: 11/02/2020 - Guangda: add LoginAMUID to check if user has proper role.
--Modifocation: 11/09/2020 - Guangda: add delete action to delate user info and user database.
--Modifocation: 11/20/2020 - Guangda: add IsEnabled column.
--===========================================================================
/*****************************************************************************
--Test Case 1 (insert)
DECLARE @LoginADMUID int = 1, 
@xmlUserInfo varchar(max)
SET @xmlUserInfo=
'<data>
                <FName>Adam</FName>
                <LName>Green</LName>
                <Email>Adam@test.com</Email>
                <ADMOID>1</ADMOID>
                <ADMRID>1</ADMRID>
                <IsEnabled>1<IsEnabled>
</data>
'
EXEC [sp_ADM_User_Save] @LoginADMUID, 'Create', @xmlUserInfo
===================================================
--Test Case 2 (update, user has ProviderKey)
DECLARE @LoginADMUID int = 1, 
@xmlUserInfo varchar(max)
SET @xmlUserInfo=
'<data>  
                <ADMUID>56</ADMUID>
                <ADMOID>2</ADMOID>
                <ADMRID>2</ADMRID>
                <IsEnabled>1<IsEnabled>
</data>
'
EXEC [sp_ADM_User_Save] @LoginADMUID, 'Update', @xmlUserInfo
===================================================
--Test Case 3 (missing param for create)
DECLARE @LoginADMUID int = 1, 
@xmlUserInfo varchar(max)
SET @xmlUserInfo=
'<data>
                <ADMUID>1</ADMUID>
                <ADMOID>3</ADMOID>
                <ADMRID>2</ADMRID>
</data>
'
EXEC [sp_ADM_User_Save] @LoginADMUID, 'Create', @xmlUserInfo
===================================================
--Test Case 4 (missing @action)
DECLARE @LoginADMUID int = 1, 
@xmlUserInfo varchar(max)
SET @xmlUserInfo=
'<data>
                <ADMUID>1</ADMUID>
                <ADMOID>3</ADMOID>
                <ADMRID>2</ADMRID>
                <IsEnabled>1<IsEnabled>
</data>
'
EXEC [sp_ADM_User_Save] @LoginADMUID, null, @xmlUserInfo
===================================================
--Test Case 5 (update, user ProviderKey is null or empty)
DECLARE @LoginADMUID int = 1, 
@xmlUserInfo varchar(max)
SET @xmlUserInfo=
'<data>
                <FName>Abbey</FName>
                <LName>Cox</LName>
                <Email>Abbey@test.com</Email>
                <ADMUID>1</ADMUID>
                <ADMOID>2</ADMOID>
                <ADMRID>2</ADMRID>
                <IsEnabled>1<IsEnabled>
</data>
'
EXEC [sp_ADM_User_Save] @LoginADMUID, 'Update', @xmlUserInfo
===================================================
--Test Case 6 (delete, user ADMUID is empty)
DECLARE @LoginADMUID int = 1, 
@xmlUserInfo varchar(max)
SET @xmlUserInfo=
'<data>
				<ADMUID></ADMUID>
</data>
'
EXEC [sp_ADM_User_Save] @LoginADMUID, 'Delete', @xmlUserInfo
===================================================
--Test Case 7 (delete)
DECLARE @LoginADMUID int = 1, 
@xmlUserInfo varchar(max)
SET @xmlUserInfo=
'<data>
				<ADMUID>54</ADMUID>
</data>
'
EXEC [sp_ADM_User_Save] @LoginADMUID, 'Delete', @xmlUserInfo
--***************************************************************************/
CREATE PROCEDURE [dbo].[sp_ADM_User_Save] @LoginADMUID int, @Action varchar(20), @UserInfoXml varchar(max)
AS
BEGIN

  SET NOCOUNT ON
  DECLARE @ADMUID int

  BEGIN TRY
    DECLARE @hasPermission bit
    DECLARE @ErrorMessage varchar(4000)
    DECLARE @currentStep varchar(100)

    -- check if @LoginADMUID has proper role
    SET @hasPermission = dbo.udf_HasPSIAdminAccess(@LoginADMUID)
    IF (@hasPermission = 0)
    BEGIN
      SET @currentStep = 'Validate Proper Role'
      SET @ErrorMessage = 'The user does not have proper role to save the info.'
      RAISERROR (@ErrorMessage, 16, 1)
    END

    -- valid param
    SET @currentStep = 'Check input xml is valid.'
    IF (RTRIM(ISNULL(@UserInfoXml, '')) = '')
    BEGIN
      SET @ErrorMessage = 'User info is empty.'
      RAISERROR (@ErrorMessage, 16, 1)
    END

    BEGIN
      SET @currentStep = 'Parse xml and get data.'
      DECLARE @ixmlUserInfo AS int
      SET @ixmlUserInfo = NULL
      EXEC sp_xml_preparedocument @ixmlUserInfo OUTPUT,
                                  @UserInfoXml

      SELECT
        * INTO #tmp
      FROM OPENXML(@ixmlUserInfo, '/data', 2)
      WITH
      (
      [ADMUID] int,
      [FName] [varchar](50),
      [LName] [varchar](50),
      [Email] [varchar](50),
      [ADMOID] [int],
      [ADMRID] [int],
      [IsEnabled] [bit]
      ) xmlData

      -- clean up xml
      EXEC sp_xml_removedocument @ixmlUserInfo
      SET @UserInfoXml = NULL

      IF (ISNULL(@Action, '') = '')
      BEGIN
        SET @ErrorMessage = 'Param action is required.'
        RAISERROR (@ErrorMessage, 16, 1)
      END

      -- get @ADMUID
      SELECT
        @ADMUID = ADMUID
      FROM #tmp

      BEGIN TRAN ADM_User_Save_Transaction
        IF (@Action = 'Create')
        BEGIN
          SET @currentStep = 'Validate the param.'
          IF (EXISTS (SELECT
              *
            FROM #tmp
            WHERE (ISNULL(Email, '') = '')
            OR ISNULL(ADMOID, 0) = 0
            OR ISNULL(ADMRID, 0) = 0)
            )
          BEGIN
            SET @ErrorMessage = 'Param email, ADMOID and ADMRID are required.'
            RAISERROR (@ErrorMessage, 16, 1)
          END
          SET @currentStep = 'Validate: email for current organization has be unique.'
          IF (EXISTS (SELECT
              *
            FROM ADM_User admu WITH (NOLOCK)
            INNER JOIN #tmp tmp
              ON admu.ADMOID = tmp.ADMOID
              AND admu.Email = tmp.Email)
            )
          BEGIN
            SET @ErrorMessage = 'The email address exists.'
            RAISERROR (@ErrorMessage, 16, 1)
          END

          SET @currentStep = 'Insert user info into.'
          INSERT INTO ADM_User ([FName],
          [LName],
          [Email],
          [ADMOID],
          [ADMRID],
          [Status],
          [IsEnabled],
          [InsertedTS])
            SELECT
              FName,
              LName,
              Email,
              ADMOID,
              ADMRID,
              @Action,
              IsEnabled,
              GETUTCDATE()
            FROM #tmp

          SET @ADMUID = @@IDENTITY
        END
        ELSE
        IF (@Action = 'Update')
        BEGIN
          SET @currentStep = 'Validate the param.'
          IF (NOT EXISTS (SELECT
              *
            FROM ADM_User WITH (NOLOCK)
            WHERE ISNULL(ADMUID, 0) = @ADMUID)
            )
          BEGIN
            SET @ErrorMessage = 'Either ADMUID is empty or the user does not exist.'
            RAISERROR (@ErrorMessage, 16, 1)
          END
          IF (EXISTS (SELECT
              *
            FROM #tmp
            WHERE ISNULL(ADMOID, 0) = 0
            OR ISNULL(ADMRID, 0) = 0)
            )
          BEGIN
            SET @ErrorMessage = 'Param ADMOID and ADMRID are required.'
            RAISERROR (@ErrorMessage, 16, 1)
          END

          IF ((SELECT
              [ProviderKey]
            FROM ADM_User WITH (NOLOCK)
            WHERE ADMUID = @ADMUID)
            IS NULL)
          BEGIN
            SET @currentStep = 'Update user info with Provider Key is empty.'
            UPDATE admu
            SET [FName] = tmp.FName,
                [LName] = tmp.LName,
                [Email] = tmp.Email,
                [ADMOID] = tmp.ADMOID,
                [ADMRID] = tmp.ADMRID,
                [Status] = @Action,
                [IsEnabled] = tmp.IsEnabled,
                [ModifiedTS] = GETUTCDATE()
            FROM ADM_User admu
            INNER JOIN #tmp tmp
              ON admu.ADMUID = tmp.ADMUID
          END
          ELSE
          BEGIN
            SET @currentStep = 'Update user info with ProviderKey is not empty.'
            UPDATE admu
            SET [ADMOID] = tmp.ADMOID,
                [ADMRID] = tmp.ADMRID,
                [Status] = @Action,
                [IsEnabled] = tmp.IsEnabled,
                [ModifiedTS] = GETUTCDATE()
            FROM ADM_User admu
            INNER JOIN #tmp tmp
              ON admu.ADMUID = tmp.ADMUID
          END
        END
        ELSE
        IF (@Action = 'Delete')
        BEGIN
          SET @currentStep = 'Validate the param.'
          IF (NOT EXISTS (SELECT
              *
            FROM ADM_User WITH (NOLOCK)
            WHERE ISNULL(ADMUID, 0) = @ADMUID)
            )
          BEGIN
            SET @ErrorMessage = 'Either ADMUID is empty or the user does not exist.'
            RAISERROR (@ErrorMessage, 16, 1)
          END

          SET @currentStep = 'Delete user database access info'
          DELETE FROM ADM_User_Database
          WHERE ADMUID = @ADMUID

          SET @currentStep = 'Delete user info.'
          DELETE FROM ADM_User
          WHERE ADMUID = @ADMUID
        END
      COMMIT TRAN ADM_User_Save_Transaction

      --get user info after successfully save user.
      EXEC [dbo].[SP_ADM_User_Get] @ADMUID = @ADMUID
    END
  END TRY

  BEGIN CATCH
    IF (ISNULL(@ErrorMessage, '') = '')
    BEGIN
      SELECT
        @ErrorMessage = @@ERROR
    END

    IF EXISTS (SELECT
        [name]
      FROM sys.dm_tran_active_transactions
      WHERE name = 'ADM_User_Save_Transaction')
    BEGIN
      ROLLBACK
    END

    EXEC [oepps].[dbo].[sp_DTA_EventLog_Insert_SP] 'PSIAdmin: ADM_User_Save',
                                                   @ErrorMessage,
                                                   @@TRANCOUNT,
                                                   @currentStep
    RAISERROR (@ErrorMessage, 16, 1)
  END CATCH
END