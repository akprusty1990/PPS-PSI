﻿-- ==========================================================
-- Author: Venkatesh
-- Modified by : Amy Zhao
-- Modified by : Guangda Li
-- Create date: 09/18/2020
-- Return user info including organization name and role name
-- Modification: 10/13/2020 - Added @LoginADMUID verification step.
-- Added parameter @ADMUID to get record for single user.
-- Modification: 10/20/2020 - Added IsEnabled column.
-- ==========================================================
/*********************************************************************
  --Test Case 1 (Invalid LoginADMUID)
  Declare @LoginADMUID int = 0,
        @ADMUID int = 1
  EXEC sp_ADM_User_Get @LoginADMUID, @ADMUID
**********************************************************************/
/*********************************************************************
  --Test Case 2 (@ADMUID is null)
  Declare @LoginADMUID int = 1,
		@ADMUID int = null
  EXEC sp_ADM_User_Get @LoginADMUID, @ADMUID
**********************************************************************/
/*********************************************************************
  --Test Case 3 (Get user record)
  Declare @LoginADMUID int = 1,
		@ADMUID int = 1
  EXEC sp_ADM_User_Get @LoginADMUID, @ADMUID 
**********************************************************************/
CREATE PROCEDURE [dbo].[SP_ADM_User_Get] @LoginADMUID int = 0,
@ADMUID int = NULL
AS
BEGIN

  SET NOCOUNT ON;
  DECLARE @hasPermission bit,
          @ErrorMessage varchar(4000),
          @currentStep varchar(100)

  BEGIN TRY

    -- Get User Records
    SET @currentStep = 'Get User Record'
    SELECT
      admu.[ADMUID],
      admu.[FName],
      admu.[LName],
      admu.[Email],
      admu.[UserName],
      admu.[ProviderKey],
      admu.[Status],
      admu.[InsertedTS],
      admu.[ModifiedTS],
      admu.[IsEnabled],
      admu.[ADMOID],
      admo.[OrganizationName],
      admu.[ADMRID],
      admr.[RoleName]
    FROM [dbo].[ADM_User] admu WITH (NOLOCK)
    INNER JOIN [dbo].ADM_Organization admo WITH (NOLOCK)
      ON admu.ADMOID = admo.ADMOID
    INNER JOIN [dbo].ADM_Role admr WITH (NOLOCK)
      ON admu.ADMRID = admr.ADMRID
    WHERE admu.[ADMUID] = @ADMUID
    OR @ADMUID IS NULL

  END TRY
  BEGIN CATCH
    SELECT
      @ErrorMessage = 'ERROR: ' + ERROR_MESSAGE()
    EXEC [oepps].[dbo].[sp_DTA_EventLog_Insert_SP] 'sp_ADM_User_Get',
                                                   @ErrorMessage,
                                                   0,
                                                   @currentStep
    RAISERROR (@ErrorMessage, 16, 1)
  END CATCH
END