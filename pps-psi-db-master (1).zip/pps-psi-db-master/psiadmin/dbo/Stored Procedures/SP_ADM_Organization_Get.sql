﻿-- ==========================================================
-- Author: Amy Zhao
-- Create date: 09/28/2020
-- Return organization info
-- ==========================================================
/************************************************************
EXEC [dbo].[SP_ADM_Organization_Get] ''
*************************************************************/
CREATE PROCEDURE [dbo].[SP_ADM_Organization_Get] @LoginADMUID int
AS
BEGIN

	SET NOCOUNT ON;
	SELECT
		admo.ADMOID
		, admo.OrganizationName
	FROM 
		[dbo].[ADM_Organization] admo WITH(NOLOCK) 

END



