﻿CREATE TABLE [dbo].[ADM_Organization](
	[ADMOID] [int] IDENTITY(1,1) NOT NULL,
	[OrganizationName] [nvarchar](200) NULL,
	[IsEnabled] [bit] NULL,
	[InsertedTS] [datetime] NULL,
	[ModifiedTS] [datetime] NULL,
 CONSTRAINT [PK_ADM_Organization] PRIMARY KEY CLUSTERED 
(
	[ADMOID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
