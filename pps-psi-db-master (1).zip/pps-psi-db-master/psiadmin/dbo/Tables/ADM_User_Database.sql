﻿CREATE TABLE [dbo].[ADM_User_Database](
	[ADMUID] [int] NOT NULL,
	[DatabaseName] [varchar](50) NOT NULL,
	[PermissionBinaryNumber] [int] NOT NULL,
	[InsertedTS] [datetime] NULL,
 CONSTRAINT [PK_ADM_User_Database_1] PRIMARY KEY CLUSTERED 
(
	[ADMUID] ASC,
	[DatabaseName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

