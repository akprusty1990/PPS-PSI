﻿CREATE TABLE [dbo].[ADM_User](
	[ADMUID] [int] IDENTITY(1,1) NOT NULL,
	[ADMOID] [int] NULL,
	[ADMRID] [smallint] NULL,
	[FName] [varchar](200) NULL,
	[LName] [varchar](200) NULL,
	[Email] [varchar](200) NULL,
	[UserName] [varchar](100) NULL,
	[ProviderKey] [UNIQUEIDENTIFIER] NULL,
	[Status] [varchar](20) NULL,
	[InsertedTS] [datetime] NULL,
	[ModifiedTS] [datetime] NULL,
	[IsEnabled] [bit] DEFAULT 1 NOT NULL,
 CONSTRAINT [PK_ADM_User] PRIMARY KEY CLUSTERED 
(
	[ADMUID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]



