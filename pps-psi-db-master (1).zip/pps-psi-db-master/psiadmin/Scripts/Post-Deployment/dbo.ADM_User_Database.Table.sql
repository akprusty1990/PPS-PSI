﻿INSERT [dbo].[ADM_User_Database] ([ADMUID], [DatabaseName], [PermissionBinaryNumber], [InsertedTS]) VALUES (54, N'OEPPS_bk', 32, CAST(N'2020-10-20T00:54:11.747' AS DateTime))
INSERT [dbo].[ADM_User_Database] ([ADMUID], [DatabaseName], [PermissionBinaryNumber], [InsertedTS]) VALUES (55, N'OEPPS_2', 4, CAST(N'2020-10-20T00:54:11.747' AS DateTime))
INSERT [dbo].[ADM_User_Database] ([ADMUID], [DatabaseName], [PermissionBinaryNumber], [InsertedTS]) VALUES (55, N'OEPPS_4', 8, CAST(N'2020-10-20T00:54:11.747' AS DateTime))
INSERT [dbo].[ADM_User_Database] ([ADMUID], [DatabaseName], [PermissionBinaryNumber], [InsertedTS]) VALUES (55, N'OEPPS_7', 16, CAST(N'2020-10-20T00:54:11.747' AS DateTime))
