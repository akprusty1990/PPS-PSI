﻿INSERT [dbo].[ADM_Organization_Database] ([ADMOID], [DatabaseName], [InsertedTS]) VALUES (1, N'OEPPS_2', CAST(N'2020-09-30T14:44:25.840' AS DateTime))
INSERT [dbo].[ADM_Organization_Database] ([ADMOID], [DatabaseName], [InsertedTS]) VALUES (1, N'OEPPS_4', CAST(N'2020-09-25T00:00:00.000' AS DateTime))
INSERT [dbo].[ADM_Organization_Database] ([ADMOID], [DatabaseName], [InsertedTS]) VALUES (1, N'OEPPS_6', CAST(N'2020-10-20T00:00:00.000' AS DateTime))
INSERT [dbo].[ADM_Organization_Database] ([ADMOID], [DatabaseName], [InsertedTS]) VALUES (2, N'OEPPS_bk', CAST(N'2020-10-20T00:00:00.000' AS DateTime))
