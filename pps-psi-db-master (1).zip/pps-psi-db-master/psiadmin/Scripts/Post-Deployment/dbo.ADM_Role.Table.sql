﻿INSERT [dbo].[ADM_Role] ([ADMRID], [RoleName], [InsertedTS]) VALUES (1, N'SuperAdmin', CAST(N'2020-09-25T00:39:04.600' AS DateTime))
INSERT [dbo].[ADM_Role] ([ADMRID], [RoleName], [InsertedTS]) VALUES (2, N'Support', CAST(N'2020-09-25T00:39:04.600' AS DateTime))
INSERT [dbo].[ADM_Role] ([ADMRID], [RoleName], [InsertedTS]) VALUES (3, N'Admin', CAST(N'2020-09-25T00:39:04.600' AS DateTime))
INSERT [dbo].[ADM_Role] ([ADMRID], [RoleName], [InsertedTS]) VALUES (4, N'Regular', CAST(N'2020-09-25T00:39:04.600' AS DateTime))
