﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
TRUNCATE TABLE [dbo].[ADM_Organization_Database];
TRUNCATE TABLE [dbo].[ADM_User_Database];
TRUNCATE TABLE [dbo].[ADM_Role];
TRUNCATE TABLE [dbo].[ADM_Organization];
TRUNCATE TABLE [dbo].[ADM_User];

:r dbo.ADM_Organization_Database.Table.sql
:r dbo.ADM_User_Database.Table.sql
:r dbo.ADM_Role.Table.sql
:r dbo.ADM_Organization.Table.sql
:r dbo.ADM_User.Table.sql