﻿SET IDENTITY_INSERT [dbo].[ADM_Organization] ON 
INSERT [dbo].[ADM_Organization] ([ADMOID], [OrganizationName], [IsEnabled], [InsertedTS], [ModifiedTS]) VALUES (1, N'EasyGroup', 1, CAST(N'2020-09-25T00:30:37.397' AS DateTime), NULL)
INSERT [dbo].[ADM_Organization] ([ADMOID], [OrganizationName], [IsEnabled], [InsertedTS], [ModifiedTS]) VALUES (2, N'TMC', 1, CAST(N'2020-09-25T00:30:37.397' AS DateTime), NULL)
INSERT [dbo].[ADM_Organization] ([ADMOID], [OrganizationName], [IsEnabled], [InsertedTS], [ModifiedTS]) VALUES (3, N'Humana', 1, CAST(N'2020-09-25T00:30:37.397' AS DateTime), NULL)
INSERT [dbo].[ADM_Organization] ([ADMOID], [OrganizationName], [IsEnabled], [InsertedTS], [ModifiedTS]) VALUES (4, N'Kaiser', 1, CAST(N'2020-09-25T00:30:37.397' AS DateTime), NULL)
SET IDENTITY_INSERT [dbo].[ADM_Organization] OFF
