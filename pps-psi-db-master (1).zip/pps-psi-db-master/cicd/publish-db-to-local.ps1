﻿param(
    [string]$connectionString,
    [string]$dbName,
    [string]$dacpacLocation,
    [int]$commandTimeout,
    [bool]$blockOnDataLoss,
    [Parameter(Mandatory=$false)]
    [string]$ddoDropObjectsNotInSource    = 'true',
    [Parameter(Mandatory=$false)]
    [string]$ddoAllowIncompatiblePlatform = 'false',
    [Parameter(Mandatory=$false)]
    [string]$ddoIgnorePermissions         = 'false',
    [Parameter(Mandatory=$false)]
    [string]$ddoIgnoreRoleMembership      = 'false',
    [Parameter(Mandatory=$false)]
    [string]$ddoIgnoreUserSettingsObjects = 'false'
)

Add-Type -Path "C:\Program Files (x86)\Microsoft SQL Server\140\DAC\bin\Microsoft.SqlServer.Dac.dll" 


$dacService = New-Object Microsoft.SqlServer.dac.dacservices ($connectionString)

$dacPackage = [Microsoft.SqlServer.Dac.DacPackage]::Load($dacpacLocation)

$deployOptions = New-Object Microsoft.SqlServer.Dac.DacDeployOptions
$deployOptions.BlockOnPossibleDataLoss = $blockOnDataLoss
$deployOptions.CommandTimeout =$commandTimeout
$deployOptions.AllowIncompatiblePlatform = $ddoAllowIncompatiblePlatform
$deployOptions.DropObjectsNotInSource    = $ddoDropObjectsNotInSource
$deployOptions.IgnorePermissions         = $ddoIgnorePermissions
$deployOptions.IgnoreRoleMembership      = $ddoIgnoreRoleMembership
$deployOptions.IgnoreUserSettingsObjects = $ddoIgnoreUserSettingsObjects

$dacService.deploy($dacPackage, $dbName, $true, $deployOptions)
