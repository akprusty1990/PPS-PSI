﻿CREATE TYPE [dbo].[tvp_IdList] AS TABLE (
    [Id] BIGINT NULL);

