﻿CREATE TYPE [dbo].[tvp_ClaimData] AS TABLE (
    [TCSID]        INT           NULL,
    [DTAEID]       INT           NOT NULL,
    [PEID]         VARCHAR (10)  NULL,
    [CBlockName]   VARCHAR (50)  NULL,
    [ClaimInput]   VARCHAR (MAX) NULL,
    [ClaimOutput]  VARCHAR (MAX) NULL,
    [ClaimData]    VARCHAR (MAX) NULL,
    [TransferFlag] BIT           NULL,
    [ClaimNum]     BIGINT        NULL,
    [InsertedTS]   DATETIME      NULL);

