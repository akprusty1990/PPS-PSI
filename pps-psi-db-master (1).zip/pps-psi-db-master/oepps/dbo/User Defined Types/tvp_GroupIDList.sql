﻿CREATE TYPE [dbo].[tvp_GroupIDList] AS TABLE (
    [GroupId] VARCHAR(256) NULL);
