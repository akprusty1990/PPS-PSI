﻿







CREATE VIEW [dbo].[vw_DTA_WorkflowInfo]
AS
SELECT wf.[DTAWFID], 
		wft.[DTAWFTID], 
		t.[DTATID], 
		t.[LUTTTID], 
		t.[DTAFID], 
		t.[DTAMID], 
        t.[DTAPID], 
		s.[DTASID], 
		e.[DTAEID], 
		wf.[WorkflowName], 
		t.[TaskName], 
		tt.[TaskType],
		mi.[LayoutName], 
		p.[ProcessInfoName],
		wf.[status],
		wf.[ScheduleStatus],
		s.[ScheduleDate],
		sr.[DTASRID],
		e.[StartTime],
		e.[EndTime],
		t.[ExecuteOrder],
		wf.ModifiedTS
FROM    [dbo].[DTA_Workflow] wf WITH (NOLOCK)
		LEFT JOIN [dbo].[DTA_WorkflowTask] wft WITH (NOLOCK) ON wf.DTAWFID = wft.[DTAWFID]
		LEFT JOIN [dbo].[dta_Task] t WITH (NOLOCK) ON wft.[DTATID] = t.[DTATID]
		LEFT JOIN [dbo].[LUT_TaskType] tt WITH (NOLOCK) ON t.LUTTTID = tt.LUTTTID
		LEFT JOIN [dbo].[DTA_FileInfo] fi WITH (NOLOCK) ON t.[DTAFID] = fi.[DTAFID] 
		LEFT JOIN [dbo].[DTA_MappingInfo] mi WITH (NOLOCK) ON t.[DTAMID] = mi.[DTAMID]
		LEFT JOIN [dbo].[DTA_ProcessInfo] p WITH (NOLOCK) ON t.[DTAPID] = p.[DTAPID]
		LEFT JOIN [dbo].[DTA_Schedule] s WITH (NOLOCK) ON wft.[DTAWFTID] = s.[DTAWFTID]
		LEFT JOIN [dbo].[DTA_ScheduleRecur] sr WITH (NOLOCK) ON s.[DTASRID] = sr.[DTASRID]
		LEFT JOIN [dbo].[DTA_Execution] e WITH (NOLOCK) ON s.[DTASID] = e.[DTASID] 
                                    



GO