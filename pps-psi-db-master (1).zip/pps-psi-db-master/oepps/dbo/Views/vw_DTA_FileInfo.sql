﻿


CREATE VIEW [dbo].[vw_DTA_FileInfo]
AS
SELECT
    [dbo].[DTA_FileInfo].[DTAFID],
    LTRIM(RTRIM([dbo].[ADM_OEPPS_Server].[WatchFolder])) + '\OPTDB\' + LTRIM(RTRIM(REPLACE(REPLACE([dbo].[ADM_OEPPS_Folder].[FolderName], CHAR(13), ''), CHAR(10), '')))
    + '\' + LTRIM(RTRIM([dbo].[DTA_FileInfo].[FileName])) AS FileLocation
FROM [dbo].[ADM_OEPPS_Folder]
INNER JOIN [dbo].[ADM_OEPPS_Server]
    ON [dbo].[ADM_OEPPS_Folder].[ADMOSID] = [dbo].[ADM_OEPPS_Server].[ADMOSID]
INNER JOIN [dbo].[DTA_FileInfo]
    ON [dbo].[ADM_OEPPS_Folder].[ADMOFID] = [dbo].[DTA_FileInfo].[ADMOFID]
WHERE (NOT ([dbo].[ADM_OEPPS_Server].[WatchFolder] IS NULL))
AND (NOT ([dbo].[ADM_OEPPS_Folder].[FolderName] IS NULL))
AND (NOT ([dbo].[DTA_FileInfo].[FileName] IS NULL))




GO