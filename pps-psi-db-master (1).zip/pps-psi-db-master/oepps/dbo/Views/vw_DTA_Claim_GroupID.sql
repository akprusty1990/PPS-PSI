﻿
-- ============================================================================        
-- Author:  Amy Zhao
-- Modified by        
-- Create date: 06/15/2020        
-- Description: This indexed view helps to improve performance while searching claims.
-- Modification: 09/01/2020 - Add column DTAEID
-- =============================================================================     
CREATE VIEW [dbo].[vw_DTA_Claim_GroupID]
AS
SELECT
    DTACID,
    GroupID,
    DTAEID,
    ModifiedTS
FROM dbo.DTA_Claim WITH (NOLOCK)
GO



