﻿-- ============================================================================        
-- Author:  Amy Zhao 
-- Modified by        
-- Create date: 06/01/2020        
-- Description: The view returns the count of GroupID after grouping it. It helps to get the total count while
-- searching and deleting claims.
-- =============================================================================     
CREATE VIEW [dbo].[vw_DTA_Claim_GroupIDTotal]
AS
SELECT
    GroupID,
    COUNT_BIG(*) AS GroupCount
FROM dbo.DTA_Claim WITH (NOLOCK)
GROUP BY GroupID
GO
