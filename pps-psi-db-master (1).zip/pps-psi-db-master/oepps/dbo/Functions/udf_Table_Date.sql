﻿-- ============================================================================        
-- Author:  Joe Lango
-- Create date: 09/08/2020        
-- Description: The function returns a table containing dates and key date parts between @startDate and @endDate
-- Original date calculation logic courtesy of:
--		https://www.sqlteam.com/forums/topic.asp?TOPIC_ID=61519
-- 
	/*
		Function: dbo.udf_Table_Date

		This function returns a date table containing all dates
		from @FIRST_DATE through @LAST_DATE inclusive.
		@FIRST_DATE must be less than or equal to @LAST_DATE.
		The valid date range is 1754-01-01 through 9997-12-31.
		If any input parameters are invalid, the fuction will produce
		an error.

		Column Descriptions
		------------------------------------------------------------------
		DATE_ID               
			Unique ID = Days since 1753-01-01
		DATE                            
			Date at Midnight(00:00:00.000)
		YEAR                            
			Year number in format YYYY, Example = 2005
		MONTH                           
			Month number in format MM, Example = 11
		DAY_OF_YEAR                     
			Day of Year number in format DDD, Example = 362
		DAY_OF_MONTH                    
			Day of Month number in format DD, Example = 31
		DAY_OF_WEEK                     
			Day of week number, Sun=1, Mon=2, Tue=3, Wed=4, Thu=5, Fri=6, Sat=7
	*/

/*******************************************************************************
-- Test cases --
-- valid
SELECT * FROM dbo.udf_Table_Date('2020-08-07 04:00:00', '2020-12-07 04:00:00');
-- invalid - generates error message
SELECT * FROM dbo.udf_Table_Date('2020-08-07 04:00:00', '2020-07-07 04:00:00');
*********************************************************************/

CREATE FUNCTION dbo.udf_Table_Date (
	@FIRST_DATE		datetime,
	@LAST_DATE		datetime
)

RETURNS  @DATE table (
	[DATE_ID] int PRIMARY KEY CLUSTERED
	, [DATE] datetime NOT NULL
	, [YEAR] smallint NOT NULL
	, [MONTH] tinyint NOT NULL
	, [DAY_OF_YEAR] smallint NOT NULL
	, [DAY_OF_MONTH] smallint NOT NULL
	, [DAY_OF_WEEK] tinyint NOT NULL 
) 
AS

BEGIN
	DECLARE
		@ErrorMessage varchar(400)
		, @START_DATE datetime
		, @END_DATE datetime
		, @LOW_DATE datetime
		, @start_no int
		, @end_no int
	;

	--@FIRST_DATE must not be before 1754-01-01
	IF  @FIRST_DATE < '17540101' BEGIN
		RETURN;
	END

	--@LAST_DATE must not be after 9997-12-31
	IF  @LAST_DATE > '99971231' BEGIN
		RETURN;
	END
	
	--@START_DATE = @FIRST_DATE at midnight
	SELECT @START_DATE = DATEADD(dd, DATEDIFF(dd, 0, @FIRST_DATE), 0);
	--@END_DATE = @LAST_DATE at midnight
	SELECT @END_DATE = DATEADD(dd, DATEDIFF(dd, 0, @LAST_DATE), 0);
	--@LOW_DATE = earliest possible SQL Server datetime
	SELECT @LOW_DATE = CONVERT(datetime, '17530101');

	-- Find the number of days from 1753-01-01 to @START_DATE and @END_DATE
	SELECT @start_no = DATEDIFF(dd, @LOW_DATE, @START_DATE)
		, @end_no = DATEDIFF(dd, @LOW_DATE, @END_DATE)
	;

	-- Declare number tables
	DECLARE @num1 table (
		NUMBER int not null primary key clustered
	);
	DECLARE @num2 table (
		NUMBER int not null primary key clustered
	);
	DECLARE @num3 table (
		NUMBER int not null primary key clustered
	);

	-- Find rows needed in number tables
	DECLARE	@rows_needed int
		, @rows_needed_root int
	;
	SELECT @rows_needed = @end_no - @start_no + 1;
	SELECT @rows_needed = 
		CASE
			WHEN @rows_needed < 10 THEN 10
			ELSE @rows_needed
		END
	;
	SELECT @rows_needed_root = CONVERT(int, CEILING(SQRT(@rows_needed)));

	-- Load number 0 to 15
	INSERT INTO @num1 (NUMBER)
	VALUES 
	(0),(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13),(14),(15)
	;

	-- Load table with numbers zero thru square root of the number of rows needed + 1
	INSERT INTO @num2 (NUMBER)
	SELECT
		NUMBER = a.NUMBER + (16 * b.NUMBER) + (256 * c.NUMBER)
	FROM
		@num1 a 
		CROSS JOIN @num1 b 
		CROSS JOIN @num1 c
	WHERE
		a.NUMBER + (16 * b.NUMBER) + (256 * c.NUMBER) < @rows_needed_root
	ORDER BY 1
	;

	-- Load table with the number of rows needed for the date range
	INSERT INTO @num3 (NUMBER)
	SELECT NUMBER = a.NUMBER + (@rows_needed_root * b.NUMBER)
	FROM @num2 a
		CROSS JOIN @num2 b
	WHERE
		a.NUMBER + (@rows_needed_root * b.NUMBER) < @rows_needed
	ORDER BY 1
	;

	-- Load Date table
	INSERT INTO @DATE
	SELECT
		a.[DATE_ID]
		, a.[DATE]
		, [YEAR] = DATEPART(year, a.[DATE])
		, [MONTH] = DATEPART(month, a.[DATE])
		, [DAY_OF_YEAR] = DATEDIFF(dd, DATEADD(yy, DATEDIFF(yy, 0, a.[DATE]), 0), a.[DATE]) + 1
		, [DAY_OF_MONTH] = DATEPART(day, a.[DATE])
		, [DAY_OF_WEEK] = (DATEDIFF(dd, '17530107', a.[DATE]) % 7) + 1
	FROM (
		-- Derived table is all dates needed for date range
		SELECT
			[DATE_ID] = aa.[NUMBER]
			, [DATE] = DATEADD(dd, aa.[NUMBER], @LOW_DATE)
		FROM (
			SELECT NUMBER = NUMBER + @start_no 
			FROM @num3
			WHERE NUMBER + @start_no <= @end_no
		) aa
	) a
	ORDER BY
		a.[DATE_ID]
	;
	RETURN;
END