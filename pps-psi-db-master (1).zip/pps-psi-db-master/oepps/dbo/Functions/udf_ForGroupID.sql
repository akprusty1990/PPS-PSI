
-- ============================================================================        
-- Author:  Amy Zhao 
-- Modified by        
-- Create date: 06/01/2020        
-- Description: The function returns the concatenated ASCII values of each character in the input string 
--   
-- =============================================================================       
-- print [dbo].[udf_ForGroupID] (123456789)
--
-- =============================================================================       
CREATE FUNCTION [dbo].[udf_ForGroupID] (@input varchar(50))
RETURNS TABLE
AS
    RETURN
    (
    SELECT (SELECT
            ASCII(SUBSTRING(a.input, v.number, 1))
        FROM (SELECT
            @input input) a
        JOIN (SELECT
            ROW_NUMBER() OVER (ORDER BY LUTCID) AS number
        FROM LUT_Claim) v
            ON v.number <= LEN(a.input)
        FOR xml PATH (''))
        [output]
    )
