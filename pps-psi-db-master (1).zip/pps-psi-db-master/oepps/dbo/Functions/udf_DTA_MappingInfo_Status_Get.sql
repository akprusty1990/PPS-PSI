﻿
-- ============================================================================        
-- Author:  Alex Chern (copied from sqlservercentral)      
-- Modified by        
-- Create date: 03/26/2020        
-- Description: The function returns 1 if Mapping Info is used by scheduled workflow. Otherwise it returns 0.    
--   
-- =============================================================================       
-- print [dbo].[udf_DTA_MappingInfo_Status_Get] (1503)
--
-- =============================================================================       
CREATE FUNCTION [dbo].[udf_DTA_MappingInfo_Status_Get] 
( 
    @DTAMID int 
) 
RETURNS bit 
BEGIN 

	IF EXISTS(SELECT TOP 1 *
				FROM [dbo].[vw_DTA_WorkflowInfo]
				WHERE [DTAMID] = @DTAMID AND @DTAMID <> 0 AND ([status] <> 'Not Run' OR [ScheduleStatus] <> 'Unscheduled'))

		RETURN 1

	RETURN 0

END