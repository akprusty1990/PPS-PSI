﻿-- ============================================================================        
-- Author:  Chinnana Raja    
-- Modified by : Chinnana Raja   
-- Modified by: Callie Ju
-- Create date: 06/24/2019   
-- Modified Date: 10/21/2019
-- Modified Date: 11/20/2019
-- Modified Date: 03/03/2019
-- Description:         
-- This function helps to buid the dynamic query for sp_ClaimSearchDynamic_Get  and sp_OEPPS_Claims_Get
-- 09/23/2019 - Updated the NOT EQUAL TO and DOES NOT CONTAIN logic for criteria JSON Search = 3
-- 09/26/2019 - Added code to handle EMPTY and BLANK values
-- 10/10/2019 - Added open and close brackets to group the conditions together.
-- 10/21/2019 - Added case for CipherDate and CipherText
-- 11/20/2019 - Added code to handle criteria JSON Search = 4(Array of arrays)
-- 03/03/2020 - Added case for Date VariableType where IsForSearch = 1
-- 04/13/2020 - Added null checks for CipherText VariableType [JK]
/*
isForSearch = 1 -> Column search on the table DTA_Claim.
isForSearch = 2 -> JSON Search for scalar value on the column DTA_ClaimData.ClaimData. Function used: JSON_VALUE
isForSearch = 3 -> JSON Search for the value inside the JSON array on the column DTA_ClaimData.ClaimData. Function used: OPENJSON
isForSearch = 4 -> JSON Search for the value inside the nested JSON array on the column DTA_ClaimData.ClaimData. Function used: OPENJSON is used twice to access the nested array.

When the search value is empty or all zeros. Records with NULL values are handled as mentioned below.
EQUAL				-> Include NULL records
NOT EQUAL			-> Exclude NULL records
CONTAINS			-> Include NULL records
NOT CONTAINS		-> Exclude NULL records
IN					-> Include NULL records

When the search value is not empty or not zero. Records with NULL values are handled as mentioned below.
EQUAL				-> Exclude NULL records
NOT EQUAL			-> Include NULL records
CONTAINS			-> Exclude NULL records
NOT CONTAINS		-> Include NULL records
IN					-> Exclude NULL records

SELECT * FROM dbo.udf_ClaimFilterDynamic(4545)
*/
-- =============================================================================       
CREATE FUNCTION [dbo].[udf_ClaimFilterDynamic](@DTACFID int)
RETURNS TABLE 
AS 
RETURN
(

  WITH CTE
  AS (SELECT
    cf.DTACFID,
    cf.LUTCNDID,
    cfd.DTACFDID,
    CASE
      WHEN co.ComparisonOperator = 'contains' THEN CASE WHEN cv.IsForSearch = 2 THEN  IIF(cfd.VariableValue not like '%[^0|^$]%','(JSON_VALUE(cd.ClaimData, ''$.' + cv.EzgWSField  + ''')  IS NULL OR ','(') + ' JSON_VALUE(cd.ClaimData, ''$.' + cv.EzgWSField  + ''')  like ''%' + cfd.VariableValue + '%'')' 
														WHEN cv.IsForSearch = 3 THEN IIF(cfd.VariableValue not like '%[^0|^$]%', --CONDITION IS TRUE IF SEARCH VALUE IS ZERO OR EMPTY. IF TRUE, Include records only with NULL values
														'((ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''') FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') WITH ([' + cv.EzgWSField + '] nvarchar(' + CAST(cv.VarLength AS VARCHAR(14)) + ') ''$.' + RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) + ''') ' +
														' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''') not like ''%[^|]%'' ) 
														OR (ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''') FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') WITH ([' + cv.EzgWSField + '] nvarchar(' + CAST(cv.VarLength AS VARCHAR(14)) + ') ''$.' + RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) + ''') ' +
														' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''')  like ''%'+ cfd.VariableValue +'%''))', 
														'(ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''') FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') WITH ([' + cv.EzgWSField + '] nvarchar(' + CAST(cv.VarLength AS VARCHAR(14)) + ') ''$.' + RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) + ''') ' +
														' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''')  like ''%'+ cfd.VariableValue +'%'') ')
														WHEN cv.IsForSearch = 4 THEN  IIF(cfd.VariableValue not like '%[^0|^$]%',--CONDITION IS TRUE IF SEARCH VALUE IS ZERO OR EMPTY. IF TRUE, Include records only with NULL values
														'((ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''')  '+
														' FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') [' + cv.EzgWSField +'] OUTER APPLY OPENJSON ([' + cv.EzgWSField +'].value, ''$.'+ RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) +''') WITH ([' + cv.EzgWSField +'] nvarchar('+ CAST(cv.VarLength AS VARCHAR(14)) +') ''$'')  ' +
														' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''') not like ''%[^|]%'' ) 
														OR (ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''')  '+
														' FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') [' + cv.EzgWSField +'] OUTER APPLY OPENJSON ([' + cv.EzgWSField +'].value, ''$.'+ RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) +''') WITH ([' + cv.EzgWSField +'] nvarchar('+ CAST(cv.VarLength AS VARCHAR(14)) +') ''$'')  ' +
														' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''') like ''%|'+ cfd.VariableValue +'|%''))'
														,'(ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''')  '+
														' FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') [' + cv.EzgWSField +'] OUTER APPLY OPENJSON ([' + cv.EzgWSField +'].value, ''$.'+ RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) +''') WITH ([' + cv.EzgWSField +'] nvarchar('+ CAST(cv.VarLength AS VARCHAR(14)) +') ''$'')  ' +
														' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''') like ''%|'+ cfd.VariableValue +'|%'') ')
														WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERTEXT' THEN IIF(cfd.VariableValue not like '%[^0|^$]%', '(c.[' + cv.VariableName + '] IS NULL OR ', '(' ) + 'ISNULL(CONVERT(varchar(MAX), DecryptByKey(c.[' + cv.VariableName + '])), '''')  like ''%' + cfd.VariableValue + '%'')'
														ELSE   IIF(cfd.VariableValue not like '%[^0|^$]%', '(c.[' + cv.VariableName + '] IS NULL OR ', '(' ) + ' c.[' + cv.VariableName + '] like ''%' + cfd.VariableValue + '%'')' 
													 END
	  --SEARCH VALUE IS NOT ZEROS OR NOT EMPTY(Include records with NULL values)
      WHEN co.ComparisonOperator = '!contains'  AND  cfd.VariableValue like '%[^0|^$]%' THEN CASE WHEN cv.IsForSearch = 2 THEN '(ISNULL(JSON_VALUE(cd.ClaimData, ''$.' + cv.EzgWSField  + '''),'''') '  + ' not like ''%' + cfd.VariableValue + '%'') '
														 WHEN cv.IsForSearch = 3 THEN '(ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''') FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') WITH ([' + cv.EzgWSField + '] nvarchar(' + CAST(cv.VarLength AS VARCHAR(14)) + ') ''$.' + RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) + ''') ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''') not like ''%'+ cfd.VariableValue +'%'') '
														 WHEN cv.IsForSearch = 4 THEN '(ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''')  '+
															' FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') [' + cv.EzgWSField +'] OUTER APPLY OPENJSON ([' + cv.EzgWSField +'].value, ''$.'+ RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) +''') WITH ([' + cv.EzgWSField +'] nvarchar('+ CAST(cv.VarLength AS VARCHAR(14)) +') ''$'')  ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''')  not like ''%'+ cfd.VariableValue +'%'') '
														 WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERTEXT' THEN '(ISNULL(CONVERT(varchar(MAX), DecryptByKey(c.[' + cv.VariableName + '])), '''')'  + ' not like ''%' + cfd.VariableValue + '%'') '
														 ELSE '(ISNULL(c.[' + cv.VariableName + '],'''')' + ' not like ''%' + cfd.VariableValue + '%'') '
													  END 
	  --SEARCH VALUE IS ZERO OR EMPTY(Exclude records with NULL values)
      WHEN co.ComparisonOperator = '!contains' AND  cfd.VariableValue not like '%[^0|^$]%' THEN CASE WHEN cv.IsForSearch = 2 THEN '(JSON_VALUE(cd.ClaimData, ''$.' + cv.EzgWSField  + ''') '  + ' not like ''%' + cfd.VariableValue + '%'') '
														 WHEN cv.IsForSearch = 3 THEN '(ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''') FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') WITH ([' + cv.EzgWSField + '] nvarchar(' + CAST(cv.VarLength AS VARCHAR(14)) + ') ''$.' + RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) + ''') ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''') not like ''%'+ cfd.VariableValue +'%'' ' + 
															' AND ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''') FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') WITH ([' + cv.EzgWSField + '] nvarchar(' + CAST(cv.VarLength AS VARCHAR(14)) + ') ''$.' + RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) + ''') ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''')  like ''%[^|]%'') '
														 WHEN cv.IsForSearch = 4 THEN '(ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''')  '+
															' FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') [' + cv.EzgWSField +'] OUTER APPLY OPENJSON ([' + cv.EzgWSField +'].value, ''$.'+ RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) +''') WITH ([' + cv.EzgWSField +'] nvarchar('+ CAST(cv.VarLength AS VARCHAR(14)) +') ''$'')  ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''')  not like ''%'+ cfd.VariableValue +'%'' ' +
															' AND ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''')  '+
															' FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') [' + cv.EzgWSField +'] OUTER APPLY OPENJSON ([' + cv.EzgWSField +'].value, ''$.'+ RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) +''') WITH ([' + cv.EzgWSField +'] nvarchar('+ CAST(cv.VarLength AS VARCHAR(14)) +') ''$'')  ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''')  like ''%[^|]%'' )'
														 WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERTEXT' THEN '(CONVERT(varchar(MAX), DecryptByKey(c.[' + cv.VariableName + ']))'  + ' not like ''%' + cfd.VariableValue + '%'') '
												  ELSE '(c.[' + cv.VariableName + ']' + ' not like ''%' + cfd.VariableValue + '%'') '
													  END 
      WHEN co.ComparisonOperator = 'in' THEN CASE WHEN cv.IsForSearch = 2 THEN '((JSON_VALUE(cd.ClaimData, ''$.' + cv.EzgWSField  + ''')  IS NULL  AND ''' + REPLACE(cfd.VariableValue,'''','') + ''' not like ''%[^0|^$]%'') OR JSON_VALUE(cd.ClaimData, ''$.' + cv.EzgWSField  + ''') '  
												  WHEN cv.IsForSearch = 3 OR cv.IsForSearch = 4 THEN '(([' + cv.EzgWSField + '] IS NULL AND ''' + REPLACE(cfd.VariableValue,'''','') + ''' not like ''%[^0|^$]%'') OR [' + cv.EzgWSField + '] ' 
												  WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERTEXT' THEN '(ISNULL(CONVERT(varchar(MAX), DecryptByKey(c.[' + cv.VariableName + '])), '''')'
												  WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERDATE' THEN '(CONVERT(date, DecryptByKey(c.[' + cv.VariableName + ']))'
												  WHEN cv.IsForSearch = 1 AND cv.VariableType = 'DATE' THEN '(CONVERT(date, c.[' + cv.VariableName + '])'
												  ELSE '((c.[' + cv.VariableName + '] IS NULL AND ''' + REPLACE(cfd.VariableValue,'''','''''') + ''' not like ''%[^0|^$]%'') OR  c.[' + cv.VariableName + '] ' 
											   END + co.ComparisonOperator + ' (' + IIF(cfd.VariableValue = '','''''', cfd.VariableValue) + '))'
	  --SEARCH VALUE IS NOT ZEROS OR NOT EMPTY(Include records with NULL values)
	  WHEN co.ComparisonOperator = '<>' AND  cfd.VariableValue like '%[^0|^$]%' THEN CASE WHEN cv.IsForSearch = 2 THEN '(ISNULL(JSON_VALUE(cd.ClaimData, ''$.' + cv.EzgWSField  + '''),'''') '  + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''') '
												  WHEN cv.IsForSearch = 3 THEN '(ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''') FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') WITH ([' + cv.EzgWSField + '] nvarchar(' + CAST(cv.VarLength AS VARCHAR(14)) + ') ''$.' + RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) + ''') ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''') not like ''%|'+ cfd.VariableValue +'|%'') '
												  WHEN cv.IsForSearch = 4 THEN '(ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''')  '+
															' FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') [' + cv.EzgWSField +'] OUTER APPLY OPENJSON ([' + cv.EzgWSField +'].value, ''$.'+ RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) +''') WITH ([' + cv.EzgWSField +'] nvarchar('+ CAST(cv.VarLength AS VARCHAR(14)) +') ''$'')  ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''')  not like ''%|'+ cfd.VariableValue +'|%'') '
												  WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERTEXT' THEN '(ISNULL(CONVERT(varchar(MAX), DecryptByKey(c.[' + cv.VariableName + '])), '''')'  + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''') '
												  WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERDATE' THEN '(CONVERT(date, DecryptByKey(c.[' + cv.VariableName + ']))'  + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''') '
												  WHEN cv.IsForSearch = 1 AND cv.VariableType = 'DATE' THEN '(CONVERT(date, c.[' + cv.VariableName + '])'  + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''') '
												  ELSE '(ISNULL(c.[' + cv.VariableName + '],'''') ' + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''') '
											   END 
	  --SEARCH VALUE IS ZERO OR EMPTY(Exclude records with NULL values)							  
	  WHEN co.ComparisonOperator = '<>' AND  cfd.VariableValue not like '%[^0|^$]%' THEN CASE WHEN cv.IsForSearch = 2 THEN '(JSON_VALUE(cd.ClaimData, ''$.' + cv.EzgWSField  + ''') '  + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''')'
												  WHEN cv.IsForSearch = 3 THEN '(ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''') FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') WITH ([' + cv.EzgWSField + '] nvarchar(' + CAST(cv.VarLength AS VARCHAR(14)) + ') ''$.' + RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) + ''') ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''')  like ''%[^|]%'') '
												  WHEN cv.IsForSearch = 4 THEN '(ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''')  '+
															' FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') [' + cv.EzgWSField +'] OUTER APPLY OPENJSON ([' + cv.EzgWSField +'].value, ''$.'+ RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) +''') WITH ([' + cv.EzgWSField +'] nvarchar('+ CAST(cv.VarLength AS VARCHAR(14)) +') ''$'')  ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''')  like ''%[^|]%'' ) '
												  WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERTEXT' THEN '(CONVERT(varchar(MAX), DecryptByKey(c.[' + cv.VariableName + ']))'  + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''') '
												  WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERDATE' THEN '(CONVERT(date, DecryptByKey(c.[' + cv.VariableName + ']))'  + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''') '												  
												  WHEN cv.IsForSearch = 1 AND cv.VariableType = 'DATE' THEN '(CONVERT(date, c.[' + cv.VariableName + '])'  + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''') '
												  ELSE '(c.[' + cv.VariableName + '] ' + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''') '
											   END 
      WHEN co.ComparisonOperator = '=' THEN  CASE WHEN cv.IsForSearch = 2 THEN IIF(cfd.VariableValue not like '%[^0|^$]%', '(JSON_VALUE(cd.ClaimData, ''$.' + cv.EzgWSField  + ''')  IS NULL OR ', '(') + ' JSON_VALUE(cd.ClaimData, ''$.' + cv.EzgWSField  + ''') ' + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''')'
												   WHEN cv.IsForSearch = 3 THEN IIF(cfd.VariableValue not like '%[^0|^$]%',
															'((ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''') FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') WITH ([' + cv.EzgWSField + '] nvarchar(' + CAST(cv.VarLength AS VARCHAR(14)) + ') ''$.' + RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) + ''') ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''')  not like ''%[^|]%'' ) OR
															([' + cv.EzgWSField + '] '+ co.ComparisonOperator + ' ''' + cfd.VariableValue + '''))',
															'([' + cv.EzgWSField + '] '+ co.ComparisonOperator + ' ''' + cfd.VariableValue + ''')')
												   WHEN cv.IsForSearch = 4 THEN IIF(cfd.VariableValue not like '%[^0|^$]%',
															'((ISNULL(STUFF(''|'' + (SELECT ''|'' + COALESCE([' + cv.EzgWSField + '], '''')  '+
															' FROM OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') [' + cv.EzgWSField +'] OUTER APPLY OPENJSON ([' + cv.EzgWSField +'].value, ''$.'+ RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) +''') WITH ([' + cv.EzgWSField +'] nvarchar('+ CAST(cv.VarLength AS VARCHAR(14)) +') ''$'')  ' +
															' FOR XML PATH('''') ), 1, 1, '''') + ''|'' ,'''') not like ''%[^|]%'' ) 
															OR ([' + cv.EzgWSField + '] '+ co.ComparisonOperator + ' ''' + cfd.VariableValue + '''))',
															'([' + cv.EzgWSField + '] '+ co.ComparisonOperator + ' ''' + cfd.VariableValue + ''')')
												   WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERTEXT' THEN '(ISNULL(CONVERT(varchar(MAX), DecryptByKey(c.[' + cv.VariableName + '])), '''') ' + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''')'
												   WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERDATE' THEN '(CONVERT(date, DecryptByKey(c.[' + cv.VariableName + '])) ' + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''')'												  
												   WHEN cv.IsForSearch = 1 AND cv.VariableType = 'DATE' THEN '(CONVERT(date, c.[' + cv.VariableName + ']) ' + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''')'
												   ELSE IIF(cfd.VariableValue not like '%[^0|^$]%', '(c.[' + cv.VariableName + '] IS NULL OR ', '(') + ' c.[' + cv.VariableName + '] ' + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''')'
											END 
	  ELSE CASE WHEN cv.IsForSearch = 2 THEN '(JSON_VALUE(cd.ClaimData, ''$.' + cv.EzgWSField  + ''') ' 
				WHEN cv.IsForSearch = 3  OR cv.IsForSearch = 4 THEN '([' + cv.EzgWSField + '] ' 
				WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERTEXT' THEN '(CONVERT(varchar(MAX), DecryptByKey(c.[' + cv.VariableName + ']))'
				WHEN cv.IsForSearch = 1 AND cv.VariableType = 'CIPHERDATE' THEN '(CONVERT(date, DecryptByKey(c.[' + cv.VariableName + ']))'
				WHEN cv.IsForSearch = 1 AND cv.VariableType = 'DATE' THEN '(CONVERT(date,c.['+ cv.VariableName + '])'												  
				ELSE '(c.[' + cv.VariableName + '] ' 
		   END + co.ComparisonOperator + ' ''' + cfd.VariableValue + ''') '
    END comparison,
    CASE
	  WHEN  cv.IsForSearch = 3 AND co.ComparisonOperator NOT IN ('contains','!contains','<>') THEN 'OUTER APPLY OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') WITH ([' + cv.EzgWSField +'] nvarchar('+ CAST(cv.VarLength AS VARCHAR(14)) +') ''$.'+ RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) +''') '
	  WHEN  cv.IsForSearch = 4 AND co.ComparisonOperator NOT IN ('contains','!contains','<>')THEN 'OUTER APPLY OPENJSON (cd.[ClaimData], ''$.'+ LEFT(cv.EzgWSField, len(cv.EzgWSField) - charindex('.',reverse(cv.EzgWSField),1)) +''') [' + cv.EzgWSField +'] OUTER APPLY OPENJSON ([' + cv.EzgWSField +'].value, ''$.'+ RIGHT(cv.EzgWSField,charindex('.',reverse(cv.EzgWSField),1)-1) +''') WITH ([' + cv.EzgWSField +'] nvarchar('+ CAST(cv.VarLength AS VARCHAR(14)) +') ''$'') '
	  ELSE ''
    END additionalJoins, cv.IsForSearch
  FROM dbo.DTA_ClaimFilter cf
  INNER JOIN dbo.DTA_ClaimFilterDetail cfd
    ON cf.DTACFID = cfd.DTACFID
  INNER JOIN dbo.LUT_ClaimVariable cv
    ON cv.LUTCVID = cfd.LUTCVID
  INNER JOIN dbo.LUT_ComparisonOperator co
    ON co.LUTCOID = cfd.LUTCOID
  WHERE CF.DTACFID = @DTACFID)
SELECT
     '(' + STUFF((SELECT
      CAST(' ' + cop.ConditionalOperator AS CHAR(5)) + c.comparison
    FROM cte c
    INNER JOIN dbo.LUT_ConditionalOperator cop
      ON cop.LUTCNDID = c.LUTCNDID AND c.IsForSearch = 1
    WHERE (DTACFID = cf.DTACFID)
    FOR XML PATH (''), TYPE)
    .value('(./text())[1]', 'VARCHAR(MAX)')
	    , 1, 5, '') + ')' 'ClaimFilters',
		     '(' + STUFF((SELECT
      CAST(' ' + cop.ConditionalOperator AS CHAR(5)) + c.comparison
    FROM cte c
    INNER JOIN dbo.LUT_ConditionalOperator cop
      ON cop.LUTCNDID = c.LUTCNDID AND c.IsForSearch > 1
    WHERE (DTACFID = cf.DTACFID)
    FOR XML PATH (''), TYPE)
    .value('(./text())[1]', 'VARCHAR(MAX)')
	    , 1, 5, '') + ')' 'ClaimDataFilters',
	 (SELECT DISTINCT ISNULL(c.additionalJoins, '') 
FROM cte c 
FOR XML PATH('')) 'AdditionalJoins'
  FROM CTE cf
  GROUP BY cf.DTACFID
 
)
