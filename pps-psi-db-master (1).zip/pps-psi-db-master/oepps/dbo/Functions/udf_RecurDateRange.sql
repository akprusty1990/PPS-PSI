﻿-- ============================================================================        
-- Author:  Joe Lango
-- Create date: 08/21/2020        
-- Description: The function returns a table containing dates between @startDate and @endDate that match the @interval .
--		this uses the udf_Table_Date user function
-- 
/*******************************************************************************
-- Test cases --
-- monthly
SELECT * FROM dbo.udf_RecurDateRange('2020-08-07 04:00:00', '2020-12-07 04:00:00', 'Monthly')
-- weekly
SELECT * FROM dbo.udf_RecurDateRange('2020-08-07 04:00:00', '2020-12-07 04:00:00', 'Weekly')
-- daily
SELECT * FROM dbo.udf_RecurDateRange('2020-08-07 04:00:00', '2020-12-07 04:00:00', 'Daily')
*********************************************************************/


CREATE FUNCTION dbo.udf_RecurDateRange(
@startDate datetime
,@endDate datetime
,@interval varchar(20)
)
RETURNS @date table (
	[DATE_WITH_TIME] [datetime]	not null
)
AS

BEGIN
	if(@interval = 'monthly') BEGIN
		-- run this for monthly
		INSERT INTO @date
		SELECT [DATE] + CAST(CAST(@startDate AS TIME) AS DATETIME)
		FROM dbo.udf_Table_Date (@startDate, @endDate)
		WHERE [DAY_OF_MONTH] = DATEPART(d, @startDate)
		;
	END
	ELSE IF @interval = 'weekly' BEGIN
		--run this for weekly
		INSERT INTO @date
		SELECT [DATE] + CAST(CAST(@startDate AS TIME) AS DATETIME)
		FROM dbo.udf_Table_Date (@startDate, @endDate)
		WHERE [DAY_OF_WEEK] = DATEPART(dw, @startDate)
		;
	END
	ELSE IF @interval = 'daily' BEGIN
		-- run this for daily
		INSERT INTO @date
		SELECT [DATE] + CAST(CAST(@startDate AS TIME) AS DATETIME)
		FROM dbo.udf_Table_Date (@startDate, @endDate)
		;
	END

	RETURN;
END