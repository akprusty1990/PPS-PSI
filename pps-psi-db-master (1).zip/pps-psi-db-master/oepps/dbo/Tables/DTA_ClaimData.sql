﻿CREATE TABLE [dbo].[DTA_ClaimData] (
    [DTACDID]              BIGINT        IDENTITY (1, 1) NOT NULL,
    [DTACID]               BIGINT        NOT NULL,
    [CBlockName]           VARCHAR (50)  NULL,
    [ClaimInput]           VARCHAR (MAX) NULL,
    [ClaimOutput]          VARCHAR (MAX) NULL,
    [ClaimData]            VARCHAR (MAX) NULL,
    [InsertedTS]           DATETIME      NOT NULL,
    [ClaimNum]             BIGINT        NULL,
    [ModifiedTS]           DATETIME      NULL,
    [DTAEID]               INT           CONSTRAINT [DF_DTA_ClaimData_DTAEID] DEFAULT ((0)) NOT NULL,
    [InpatientOutlierPay]  AS            (CONVERT([numeric](10,2),CONVERT([float],json_value([ClaimData],'$.Output.Price.Drg.Claim.addon'))/(100))),
    [InpatientTotalReimb]  AS            (CONVERT([numeric](10,2),CONVERT([float],json_value([ClaimData],'$.Output.Price.Drg.Claim.total'))/(100))) PERSISTED,
    [TotalCharge]          AS            (CONVERT([numeric](10,2),CONVERT([float],json_value([ClaimData],'$.Input.PatientClaim.tot_chg'))/(100))) PERSISTED,
    [DrgCode]              AS            (CONVERT([int],json_value([ClaimData],'$.Output.Group.Drg.Claim.drg'))) PERSISTED,
    [OutpatientOutlierPay] AS            (CONVERT([numeric](10,2),CONVERT([float],json_value([ClaimData],'$.Output.Price.Apc.Claim.addon'))/(100))),
    [ApgOutlierPay]        AS            (CONVERT([numeric](10,2),CONVERT([float],json_value([ClaimData],'$.Output.Price.Apg.Claim.addon'))/(100))),
    [IrfOutlierPay]        AS            (CONVERT([numeric](10,2),CONVERT([float],json_value([ClaimData],'$.Output.Price.Irf.Claim.addon'))/(100))),
    [OutpatientTotalReimb] AS            (CONVERT([numeric](10,2),CONVERT([float],json_value([ClaimData],'$.Output.Price.Apc.Claim.tot_reimb'))/(100))),
    [ApgTotalReimb]        AS            (CONVERT([numeric](10,2),CONVERT([float],json_value([ClaimData],'$.Output.Price.Apg.Claim.tot_reimb'))/(100))),
    [IrfTotalReimb]        AS            (CONVERT([numeric](10,2),CONVERT([float],json_value([ClaimData],'$.Output.Price.Irf.Claim.totreimb'))/(100))),
    [PhysicianTotalReimb]  AS            (CONVERT([numeric](10,2),CONVERT([float],json_value([ClaimData],'$.Output.Price.Physician.Claim.tot_reimb'))/(100))),
    [SnfTotalReimb]        AS            (CONVERT([numeric](10,2),CONVERT([float],json_value([ClaimData],'$.Output.Price.Snf.Claim.total'))/(100))),
    CONSTRAINT [PK_DTA_ClaimData] PRIMARY KEY CLUSTERED ([DTACID] ASC)
) ON [PRIMARY];












GO



GO
CREATE NONCLUSTERED INDEX [idx_DTACID]
    ON [dbo].[DTA_ClaimData]([DTACID] ASC)


GO
CREATE NONCLUSTERED INDEX [idx_DTA_ClaimData_TotalCharge]
    ON [dbo].[DTA_ClaimData]([TotalCharge] ASC)


GO
CREATE NONCLUSTERED INDEX [idx_DTA_ClaimData_InpatientTotalReimb]
    ON [dbo].[DTA_ClaimData]([InpatientTotalReimb] ASC)


GO
CREATE NONCLUSTERED INDEX [idx_DTA_ClaimData_DrgCode]
    ON [dbo].[DTA_ClaimData]([DrgCode] ASC)

