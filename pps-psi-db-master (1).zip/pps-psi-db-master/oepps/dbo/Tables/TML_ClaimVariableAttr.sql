﻿CREATE TABLE [dbo].[TML_ClaimVariableAttr] (
    [TMLCVAID]       INT          NOT NULL,
    [TMLCVID]        INT          NULL,
    [AttributeName]  VARCHAR (50) NULL,
    [AttributeValue] VARCHAR (50) NULL,
    [Enabled]        BIT          NULL,
    [InsertedTS]     DATETIME     NULL,
    [ModifiedTS]     DATETIME     NULL,
    CONSTRAINT [PK_TML_ClaimVariableAttr] PRIMARY KEY CLUSTERED ([TMLCVAID] ASC)
);

