﻿CREATE TABLE [dbo].[LUT_ReportVariable] (
    [LUTRVID]      INT          NOT NULL,
    [LUTRID]       INT          NOT NULL,
    [ColumnTitle]  VARCHAR (50) NULL,
    [DisplayTitle] VARCHAR (50) NULL,
    [HeaderClass]  VARCHAR (50) NULL,
    [ColumnType]   VARCHAR (50) NULL,
    [ColumnAlign]  VARCHAR (50) NULL,
    [DisplayOrder] INT          NULL,
    [InsertedTS]   DATETIME     NULL,
    [ModifiedTS]   DATETIME     NULL,
    [Enabled]      BIT          NULL,
    CONSTRAINT [PK_LUT_ReportVariable] PRIMARY KEY CLUSTERED ([LUTRVID] ASC)
);

