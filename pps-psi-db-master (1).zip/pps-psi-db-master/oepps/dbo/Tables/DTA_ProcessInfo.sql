﻿CREATE TABLE [dbo].[DTA_ProcessInfo] (
    [DTAPID]                  INT          IDENTITY (1, 1) NOT NULL,
    [ProcessInfoName]         VARCHAR (50) NULL,
    [ADMOFID_RatePath]        INT          NULL,
    [ADMOFID_UserPath]        INT          NULL,
    [ADMOFID_SystemPath]      INT          NULL,
    [ADMOFID_Optimizer64Path] INT          NULL,
    [Ecb.opcode1]			  CHAR(2)	   NULL,
	[Ecb.pattype]			  CHAR(2)	   NULL,
	[Ecb.code_class]		  CHAR(2)	   NULL,
	[Pcb1.accept_if] 		  CHAR(2)	   NULL,
	[Ecb.opcode3]			  CHAR(2)	   NULL,
	[Ecb.pyr_altlook_sw]	  CHAR(1)	   NULL,
	[Ecb.map_override_id]     VARCHAR(20)  NULL,
	[Ecb.hac_override_id]     VARCHAR(10)  NULL,
	[Ecb.ace_override_id]     VARCHAR(20)  NULL,
	[Ecb.apc_override_id]     VARCHAR(20)  NULL,
	[IsDefault]               BIT          NULL,
	[InsertedTS]			  DATETIME	   CONSTRAINT [Data_InsertedTS_DTAPID] DEFAULT (getdate()) NULL,
	[ModifiedTS]			  DATETIME     NULL,
	[Pcb1.facility]           VARCHAR(16)  NULL,
	[Pcb1.npi]                VARCHAR(10)  NULL,
	[Pcb1.taxonomy]           VARCHAR(10)  NULL,
	[Pcb1.paysrc]             VARCHAR(13)  NULL,
	[Pcb2.icd.hmo_risk]       CHAR(1)      NULL
    CONSTRAINT [PK_DTA_ProcessInfo] PRIMARY KEY CLUSTERED ([DTAPID] ASC)
);

