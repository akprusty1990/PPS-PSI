﻿CREATE TABLE [dbo].[ADM_Permission](
	[ADMPID] [int] NOT NULL,
	[PermissionName] [varchar](50) NOT NULL,
	[PermissionBinaryNumber] [int] NOT NULL,
	[AccessType] [varchar](50) NOT NULL,
	[PermissionCategory] [varchar](50) NOT NULL,
	[DisplayOrder] [int] NOT NULL,
 CONSTRAINT [PK_ADM_Permission] PRIMARY KEY CLUSTERED 
(
	[ADMPID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]



