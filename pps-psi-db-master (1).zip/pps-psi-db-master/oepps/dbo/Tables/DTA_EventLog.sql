﻿CREATE TABLE [dbo].[DTA_EventLog](
	[DTAELID]           BIGINT        IDENTITY(1,1) NOT NULL,
	[LoginUser]         VARCHAR(100)  NULL,
    [TypeEnum]          SMALLINT      NULL,
    [ApplicationEnum]   SMALLINT      NULL,
    [SourceEnum]        SMALLINT      NULL,
    [SourceName]        VARCHAR(100)  NULL,
    [Description]       VARCHAR(1000) NULL,
    [DescriptionDetail] VARCHAR(MAX)  NULL,
    [Data]              VARCHAR(MAX)  NULL,
    [InsertedTS]        DATETIME      CONSTRAINT [Data_InsertedTS_EventLog] DEFAULT (getdate())NULL,
	CONSTRAINT [PK_DTA_EventLog] PRIMARY KEY CLUSTERED ([DTAELID] ASC)
);
