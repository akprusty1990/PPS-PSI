﻿CREATE TABLE [dbo].[DTA_WorkflowTaskRelation] (
    [DTAWFTRID]  INT      IDENTITY (1, 1) NOT NULL,
    [DTAWFTID]   INT      NOT NULL,
    [DTAPWFTID]  INT      NULL,
    [DTAPEID]    INT      NULL,
    [InsertedTS] DATETIME NULL,
    [ModifiedTS] DATETIME NULL,
    CONSTRAINT [PK_DTA_WorkflowTaskRelation] PRIMARY KEY CLUSTERED ([DTAWFTRID] ASC)
);

