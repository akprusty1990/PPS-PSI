﻿CREATE TABLE [dbo].[TML_ProcessInfoVariable] (
    [TMLPVID]        INT            NOT NULL IDENTITY,
    [LUTCVID]        INT            NULL,
    [ParentTMLPVID]  INT            NULL,
    [FieldType]      VARCHAR (50)   NULL,
    [FieldTextName]  VARCHAR (100)  NULL,
    [FieldTextValue] VARCHAR (100)  NULL,
    [EventTMLPVID]   INT            NULL,
    [EventValue]     VARCHAR (100)  NULL,
    [DisplayOrder]   INT            NULL,
    [Enabled]        BIT            NULL,
    [InsertedTS]     DATETIME       CONSTRAINT [DF_TML_ProcessInfoVariable_InsertedTS] DEFAULT (getdate()) NULL,
    [ModifiedTS]     DATETIME       NULL,
    CONSTRAINT [PK_TML_ProcessInfoVariable] PRIMARY KEY CLUSTERED ([TMLPVID] ASC)
);