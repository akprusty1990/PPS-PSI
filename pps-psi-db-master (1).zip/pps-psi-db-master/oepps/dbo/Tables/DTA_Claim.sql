﻿CREATE TABLE [dbo].[DTA_Claim] (
    [DTACID]            BIGINT          IDENTITY (1, 1) NOT NULL,
    [DTAOCID]           BIGINT          NULL,
    [DTAPCID]           INT             NULL,
    [ClaimNum]          BIGINT          NULL,
    [InsertedTS]        DATETIME        CONSTRAINT [Data_insertedTS] DEFAULT (getutcdate()) NULL,
    [Source]            VARCHAR (10)    NULL,
    [DTAEID]            INT             CONSTRAINT [DF_DTA_Claim_DTAEID] DEFAULT ((0)) NOT NULL,
    [Pcb1.med_num]      VARBINARY (MAX) NULL,
    [Oepps.member_id]   VARBINARY (MAX) NULL,
    [Pcb1.ctr_num]      VARBINARY (MAX) NULL,
    [Pcb1.hplan_id]     VARBINARY (MAX) NULL,
    [Pcb1.npi]          VARCHAR (10)    NULL,
    [Pcb1.taxonomy]     VARCHAR (10)    NULL,
    [Pcb1.paysrc]       VARCHAR (13)    NULL,
    [Pcb1.from_date]    VARBINARY (MAX) NULL,
    [Pcb1.thru_date]    VARBINARY (MAX) NULL,
    [Pcb1.birth_date]   VARBINARY (MAX) NULL,
    [Pcb1.admit_date]   VARBINARY (MAX) NULL,
    [Ecb.prcr_type]     VARCHAR (2)     NULL,
    [Ecb.func_rtn_code] VARCHAR (2)     NULL,
    [Pcb1.facility]     VARCHAR (16)    NULL,
    [Oepps.claim_id]    VARBINARY (MAX) NULL,
    [Oepps.fname]       VARBINARY (MAX) NULL,
    [Oepps.mname]       VARBINARY (MAX) NULL,
    [Oepps.lname]       VARBINARY (MAX) NULL,
    [StatusMsg]         VARCHAR (256)   NULL,
    [StatusCode]        INT             NULL,
    [IsLatest]          INT             NULL,
    [Oob1.opt_rtn_code] VARCHAR (2)     NULL,
    [HasEdits]          BIT             NULL,
    [ModifiedTS]        DATETIME        CONSTRAINT [DF_DTA_Claim_ModifiedTS] DEFAULT (getutcdate()) NULL,
    [DTAPID]            INT             NULL,
    [FileName]          VARCHAR (512)   NULL,
    [GroupID]           VARCHAR (256)   NULL,
    [PartitionDate]     DATE            CONSTRAINT [DF_DTA_Claim_PartitionDate] DEFAULT(DATEADD(DAY, 1, EOMONTH(GETUTCDATE(), -1))) NOT NULL,
    CONSTRAINT [PK_DTA_Claim] PRIMARY KEY CLUSTERED ([DTACID] ASC, [PartitionDate] ASC) ON [PSIPartitionS] ([PartitionDate])
) ON [PSIPartitionS] ([PartitionDate]);

GO
CREATE NONCLUSTERED INDEX [idx_DTACID]
    ON [dbo].[DTA_Claim]([DTACID] ASC)
    ON [PSIPartitionS] ([PartitionDate]);

