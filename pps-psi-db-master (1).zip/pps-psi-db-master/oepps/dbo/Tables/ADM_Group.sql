﻿CREATE TABLE [dbo].[ADM_Group](
	[ADMGID] [smallint] IDENTITY(1,1) NOT NULL,
	[GroupName] [varchar](200) NOT NULL,
	[GroupDescr] [varchar](200) NULL,
	[PermissionBinaryNumber] [int] NULL,
	[IsDefault] [bit] NULL,
	[Enabled] [bit] NULL,
	[InsertedTS] [datetime] NULL CONSTRAINT [DF_ADM_Group_InsertedTS]  DEFAULT (getdate()),
	[ModifiedTS] [datetime] NULL,
 CONSTRAINT [PK_ADM_Group] PRIMARY KEY CLUSTERED 
(
	[ADMGID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

