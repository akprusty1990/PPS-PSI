﻿CREATE TABLE [dbo].[TML_ClaimVariable] (
    [TMLCVID]        INT            NOT NULL,
    [LUTCID]         INT            NULL,
    [LUTCVID]        INT            NULL,
    [ParentTMLCVID]  INT            NULL,
    [FieldType]      VARCHAR (50)   NULL,
    [FieldTextName]  VARCHAR (50)   NULL,
    [FieldTextValue] VARCHAR (1000) NULL,
    [UILength]       INT            NULL,
    [UIUsage]        VARCHAR (50)   NULL,
    [SectionColumns] SMALLINT       NULL,
    [DisplayType]    VARCHAR (20)   NULL,
    [DisplayOrder]   INT            NULL,
    [Enabled]        BIT            NULL,
    [InsertedTS]     DATETIME       CONSTRAINT [DF_TML_ClaimVariable_InsertedTS] DEFAULT (getdate()) NULL,
    [ModifiedTS]     DATETIME       NULL,
    CONSTRAINT [PK_TML_ClaimVariable] PRIMARY KEY CLUSTERED ([TMLCVID] ASC)
);

