﻿CREATE TABLE [dbo].[DTA_Execution] (
    [DTAEID]				INT				IDENTITY (1, 1) NOT NULL,
    [DTASID]				INT				NOT NULL,
    [Status]				VARCHAR (20)	NULL,
    [StartTime]				DATETIME		NULL,
    [EndTime]				DATETIME		NULL,
    [NumOfClaims]			INT				NULL,
    [InitiatedBy]			VARCHAR (50)	NULL,
    [RecordsPerSecond]		INT				NULL,
    [NumReturnCodes]		INT				NULL,
    [NumEdits]				INT				NULL,
    [NumBatches]			INT				 NULL,
    [NumCompletedBatches]	INT				NULL,
    [StatusCode]			INT				NULL,
	[StatusMsg]				VARCHAR(1024)	NULL,
	[NumOfClaimStatusCodes]	INT				NULL,
    CONSTRAINT [PK_DTA_Execution] PRIMARY KEY CLUSTERED ([DTAEID] ASC),
    CONSTRAINT [FK_DTA_Schedular_DTA_Execution] FOREIGN KEY ([DTASID]) REFERENCES [dbo].[DTA_Schedule] ([DTASID]) ON DELETE CASCADE ON UPDATE CASCADE
);

