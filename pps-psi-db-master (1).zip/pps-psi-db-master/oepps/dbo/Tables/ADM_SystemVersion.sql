﻿CREATE TABLE [dbo].[ADM_SystemVersion](
	[ADMSVID] [int] IDENTITY(1,1) NOT NULL,
	[OEPPSVersion] [varchar](50) NULL,
	[PSIVersion] [varchar](50) NULL,
	[DBVersion] [varchar](50) NULL,
	[WebAPIVersion] [varchar](50) NULL,
	[InsertedTS] [datetime] CONSTRAINT [InsertedTS_Default]  DEFAULT (getdate()) NOT NULL,
	CONSTRAINT [PK_ADM_SystemVersion] PRIMARY KEY CLUSTERED ([ADMSVID] ASC)
);

GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Application version' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ADM_SystemVersion', @level2type=N'COLUMN',@level2name=N'PSIVersion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Database version' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ADM_SystemVersion', @level2type=N'COLUMN',@level2name=N'DBVersion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'OEPPS version' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ADM_SystemVersion', @level2type=N'COLUMN',@level2name=N'OEPPSVersion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Web API version' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ADM_SystemVersion', @level2type=N'COLUMN',@level2name=N'WebAPIVersion'
GO