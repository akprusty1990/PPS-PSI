﻿CREATE TABLE [dbo].[LUT_Claim] (
    [LUTCID]       INT           NOT NULL IDENTITY,
    [pattype]      CHAR (2)      NULL,
    [Section]      VARCHAR (2)   NULL,
    [Value]        CHAR (2)      NULL,
    [ShortName]    VARCHAR (10)  NULL,
    [LongName]     VARCHAR (200) NULL,
    [DisplayOrder] TINYINT       NULL,
    [InsertedTS]   DATETIME      CONSTRAINT [DF_LUT_Claim_InsertedTS] DEFAULT (getdate()) NULL,
    [ModifiedTS]   DATETIME      NULL,
    [Enabled]      BIT           NULL,
    CONSTRAINT [PK_LUT_Claim] PRIMARY KEY CLUSTERED ([LUTCID] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CF=Common Field; PT = Pricer Type; GT=Grouper Type; ET=Editor;', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'LUT_Claim', @level2type = N'COLUMN', @level2name = N'Section';

