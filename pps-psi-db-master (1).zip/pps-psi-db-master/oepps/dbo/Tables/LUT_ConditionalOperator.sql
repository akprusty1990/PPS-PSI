﻿CREATE TABLE [dbo].[LUT_ConditionalOperator] (
    [LUTCNDID]            INT          IDENTITY (1, 1) NOT NULL,
    [ConditionalOperator] VARCHAR (3)  NOT NULL,
    [Description]         VARCHAR (20) NULL,
    CONSTRAINT [PK_LUT_ConditionalOperator] PRIMARY KEY CLUSTERED ([LUTCNDID] ASC)
);

