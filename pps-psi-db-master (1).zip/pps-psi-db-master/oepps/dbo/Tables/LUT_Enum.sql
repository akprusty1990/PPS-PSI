﻿CREATE TABLE [dbo].[LUT_Enum](
	[LUTEID]          INT          NOT NULL,
	[EnumName]        VARCHAR(50)  NULL,
    [EnumValue]       SMALLINT     NULL,
    [EnumDescription] VARCHAR(100) NULL,
	CONSTRAINT [PK_LUT_Enum] PRIMARY KEY CLUSTERED ([LUTEID] ASC)
);
