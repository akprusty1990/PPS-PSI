﻿CREATE TABLE [dbo].[LUT_ComparisonOperator] (
    [LUTCOID]            INT          IDENTITY (1, 1) NOT NULL,
    [ComparisonOperator] VARCHAR (20) NOT NULL,
    [Description]        VARCHAR (50) NULL,
    [VariableType]       VARCHAR (10) NULL,
    CONSTRAINT [PK_LUT_ComparisonOperator] PRIMARY KEY CLUSTERED ([LUTCOID] ASC)
);

