﻿CREATE TABLE [dbo].[LUT_Report] (
    [LUTRID]            INT          NOT NULL,
    [ReportTableName]   VARCHAR (50) NOT NULL,
    [ReportDisplayName] VARCHAR (50) NULL,
    CONSTRAINT [PK_LUT_Report] PRIMARY KEY CLUSTERED ([LUTRID] ASC)
);

