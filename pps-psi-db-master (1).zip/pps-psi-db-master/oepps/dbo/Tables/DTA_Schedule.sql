﻿CREATE TABLE [dbo].[DTA_Schedule] (
    [DTASID]         INT           IDENTITY (1, 1) NOT NULL,
    [DTAWFTID]       INT           NOT NULL,
    [ScheduleType]   VARCHAR (50)  NULL,
    [ScheduleDate]   DATETIME2 (0) NULL,
    [ScheduleTime]   TIME (7)      NULL,
    [Frequency]      VARCHAR (50)  NULL,
    [RecursiveEvery] VARCHAR (50)  NULL,
    [InsertedTS]     DATETIME      NULL,
    [ModifiedBy]     VARCHAR (50)  NULL,
    [Action] VARCHAR(20)		   NULL, 
    [ModifiedTS] DATETIME		   NULL, 
	[DTASRID] INT				   NULL,
    CONSTRAINT [PK_DTA_Schedule] PRIMARY KEY CLUSTERED ([DTASID] ASC),
    CONSTRAINT [FK_DTA_Schedule_DTA_WorkflowTask] FOREIGN KEY ([DTAWFTID]) REFERENCES [dbo].[DTA_WorkflowTask] ([DTAWFTID]),
	CONSTRAINT [FK_DTA_Schedule_DTA_ScheduleRecur] FOREIGN KEY ([DTASRID]) REFERENCES dbo.DTA_ScheduleRecur([DTASRID])
);

