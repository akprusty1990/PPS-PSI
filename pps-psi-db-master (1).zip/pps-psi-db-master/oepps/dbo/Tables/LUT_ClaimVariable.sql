﻿CREATE TABLE [dbo].[LUT_ClaimVariable] (
    [LUTCVID]              INT            NOT NULL,
    [LUTCID]               INT            NULL,
    [SEQ]                  VARCHAR (10)   NULL,
    [VariableName]         VARCHAR (100)  NOT NULL,
    [VariableDescr]        VARCHAR (MAX)  NULL,
    [VariableType]         VARCHAR (12)   NULL,
    [VariableUsage]        VARCHAR (50)   NULL,
    [VariableLeftCount]    SMALLINT       NULL,
    [VariableRightCount]   SMALLINT       NULL,
    [VariableFormat]       VARCHAR (256)  NULL,
    [VariableEventHandler] VARCHAR (1000) NULL,
    [VarType]              VARCHAR (3)    NULL,
    [VarLength]            INT            NULL,
    [EzgWSField]           VARCHAR (500)  NULL,
    [LabelOnUI]            VARCHAR (200)  NULL,
    [DefaultValue]         VARCHAR (50)   NULL,
    [VariableSize]         SMALLINT       NULL,
    [StartPosition]        SMALLINT       NULL,
    [IsRequired]           BIT            NULL,
    [RegexExpression]      VARCHAR (1000) NULL,
    [RangeMin]             FLOAT (53)     NULL,
    [RangeMax]             FLOAT (53)     NULL,
    [StringLength]         INT            NULL,
    [VariableUsageBinary]  SMALLINT       NULL,
    [Enabled]              BIT            NULL,
    [InsertedTS]           DATETIME       NULL,
    [ModifiedTS]           DATETIME       NULL,
    [IsForSearch]          TINYINT        NULL,
    [MaxOccurrence]        TINYINT        NULL,
    CONSTRAINT [PK_LUT_ClaimVariable] PRIMARY KEY CLUSTERED ([LUTCVID] ASC)
);










GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'The column is from CBlock.xml', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'LUT_ClaimVariable', @level2type = N'COLUMN', @level2name = N'VarType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'0 or NULL = Not filterable; 1 = Filterable on a DTA_Claim column; 2 = Filterable within DTA_ClaimData ClaimData JSON as a single variable; 3 = Filterable within DTA_ClaimData ClaimData JSON as an array variable; 4 = Fitlerable within DTA_ClaimData ClaimData JSON as an array within an array variable
', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'LUT_ClaimVariable', @level2type = N'COLUMN', @level2name = N'IsForSearch';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Used in Mapping Layout page, show valriables with MaxOccurrence values != 0. NULL means the value repeats once; 0 means the value is not mappable; otherwise a number represents the number of times that field repeats
', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'LUT_ClaimVariable', @level2type = N'COLUMN', @level2name = N'MaxOccurrence';

