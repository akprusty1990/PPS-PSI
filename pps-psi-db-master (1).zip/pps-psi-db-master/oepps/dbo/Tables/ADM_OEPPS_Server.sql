﻿CREATE TABLE [dbo].[ADM_OEPPS_Server] (
    [ADMOSID]       INT           NOT NULL,
    [ServerName]    VARCHAR (500) NOT NULL,
    [WatchFolder]   VARCHAR (125) NOT NULL,
    [OptimizerPath] VARCHAR (125) NULL,
    [DataPath]      VARCHAR (125) NULL,
    [IsEnabled]     BIT           NOT NULL,
	[AppVersion]	VARCHAR(50)	  NULL,
    [InsertedTS]    DATETIME      CONSTRAINT [DF_ADM_OEPPS_Server_InsertedTS] DEFAULT (getdate()) NOT NULL,
	[ModifiedTS]	DATETIME	  NULL,
    CONSTRAINT [PK_ADM_OEPPS_Server] PRIMARY KEY CLUSTERED ([ADMOSID] ASC)
);

GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'OEPPS Application Version' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ADM_OEPPS_Server', @level2type=N'COLUMN',@level2name=N'AppVersion'
GO