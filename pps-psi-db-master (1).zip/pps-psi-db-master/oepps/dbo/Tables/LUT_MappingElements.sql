﻿CREATE TABLE [dbo].[LUT_MappingElements] (
    [LUTMEID]            INT          NOT NULL,
    [Name]               VARCHAR (15) NULL,
    [Type]               VARCHAR (1)  NULL,
    [ParentLutmeid]      INT          NULL,
    [DefaultValue]       VARCHAR (10) NULL,
    [Sequence]           SMALLINT     NULL,
    [Occur]              SMALLINT     NULL,
    [UISequence]         SMALLINT     NULL,
    [ClaimVarColumnName] VARCHAR (20) NULL,
    [UILabel]            VARCHAR (30) NULL,
    [DisplayOnly]        BIT          NULL,
    [VariableType]       VARCHAR (50) NULL,
    CONSTRAINT [PK_LUT_MappingElements] PRIMARY KEY CLUSTERED ([LUTMEID] ASC)
);









