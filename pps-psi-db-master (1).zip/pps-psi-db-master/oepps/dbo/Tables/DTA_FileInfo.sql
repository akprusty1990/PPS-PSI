﻿CREATE TABLE [dbo].[DTA_FileInfo] (
    [DTAFID]     INT           IDENTITY (1, 1) NOT NULL,
    [ADMOFID]    INT           NOT NULL,
    [FileName]   VARCHAR (500) NOT NULL,
    [InsertedTS] DATETIME      CONSTRAINT [DF_DTA_FileInfo_InsertedTS] DEFAULT (getdate()) NULL,
    CONSTRAINT [PK_DTA_FileInfo] PRIMARY KEY CLUSTERED ([DTAFID] ASC),
    CONSTRAINT [FK_DTA_FileInfo_ADM_OEPPS_Folder] FOREIGN KEY ([ADMOFID]) REFERENCES [dbo].[ADM_OEPPS_Folder] ([ADMOFID])
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DTA_FileInfo_ADMOFID_FileName_Unique]
    ON [dbo].[DTA_FileInfo]([ADMOFID] ASC, [FileName] ASC);

