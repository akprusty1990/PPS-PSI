﻿CREATE TABLE [dbo].[DTA_ClaimFilterDetail] (
    [DTACFDID]      INT           IDENTITY (1, 1) NOT NULL,
    [DTACFID]       INT           NULL,
    [DisplayOrder]  TINYINT       NULL,
    [LUTCVID]       INT           NULL,
    [LUTCOID]       INT           NULL,
    [VariableValue] VARCHAR (MAX) NULL,
    [ModifiedTS]    DATETIME2 (7) CONSTRAINT [DF_DTA_ClaimFilterDetail_ModifiedTS] DEFAULT (getutcdate()) NULL,
    CONSTRAINT [PK_DTA_ClaimFilterDetail] PRIMARY KEY CLUSTERED ([DTACFDID] ASC)
);

