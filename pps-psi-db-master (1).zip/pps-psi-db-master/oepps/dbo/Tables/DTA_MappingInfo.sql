﻿CREATE TABLE [dbo].[DTA_MappingInfo] (
    [DTAMID]     INT           IDENTITY (1, 1) NOT NULL,
    [LayoutName] VARCHAR (100) NULL,
    [Content]    VARCHAR (MAX) NULL,
    [InsertedTS] DATETIME      NULL,
    [ModifiedTS] DATETIME      NULL,
    CONSTRAINT [PK_DTA_MappingInfo] PRIMARY KEY CLUSTERED ([DTAMID] ASC)
);



