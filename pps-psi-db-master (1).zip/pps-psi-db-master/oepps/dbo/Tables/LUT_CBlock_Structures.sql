﻿CREATE TABLE [dbo].[LUT_CBlock_Structures] (
    [LUTCBSID]           INT          NOT NULL,
    [BlockName]          VARCHAR (20) NULL,
    [StructureName]      VARCHAR (20) NULL,
    [StructureNameForUI] VARCHAR (20) NULL,
    [MaxOccurrence]      INT          NULL,
    CONSTRAINT [PK_LUT_CBlock_Structures] PRIMARY KEY CLUSTERED ([LUTCBSID] ASC)
);





