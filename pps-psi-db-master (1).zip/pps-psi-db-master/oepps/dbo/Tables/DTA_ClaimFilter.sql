﻿CREATE TABLE [dbo].[DTA_ClaimFilter] (
    [DTACFID]    INT           IDENTITY (1, 1) NOT NULL,
    [FilterName] VARCHAR (50)  NULL,
    [LUTCNDID]   VARCHAR (3)   NULL,
    [Source]     VARCHAR (MAX) NULL,
    [ModifiedTS] DATETIME2 (7) CONSTRAINT [DF_DTA_ClaimFilter_ModifiedTS] DEFAULT (getutcdate()) NULL,
    CONSTRAINT [PK_DTA_ClaimFilter] PRIMARY KEY CLUSTERED ([DTACFID] ASC)
);

