﻿CREATE TABLE [dbo].[LUT_StatusCode] (
    [StatusCode]  INT           NOT NULL,
    [Description] VARCHAR (200) NOT NULL,
    [Level]       VARCHAR (10)  NOT NULL,
    CONSTRAINT [PK_LUT_StatusCode] PRIMARY KEY CLUSTERED ([StatusCode] ASC)
);

