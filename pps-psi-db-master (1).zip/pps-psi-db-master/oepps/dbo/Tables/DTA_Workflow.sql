﻿CREATE TABLE [dbo].[DTA_Workflow] (
    [DTAWFID]        INT           IDENTITY (1, 1) NOT NULL,
    [WorkflowName]   VARCHAR (100) NULL,
    [InsertedTS]     DATETIME      CONSTRAINT [DTA_Workflow_insertedTS] DEFAULT (getdate()) NULL,
    [ModifiedTS]     DATETIME      NULL,
    [Status]         VARCHAR (20)  NULL,
    [ModifiedBy]     VARCHAR (50)  NULL,
    [ScheduleStatus] VARCHAR (20)  NULL,
    CONSTRAINT [PK_DTA_Workflow] PRIMARY KEY CLUSTERED ([DTAWFID] ASC),
    CONSTRAINT [UC_WorkflowName] UNIQUE NONCLUSTERED ([WorkflowName] ASC),
    CONSTRAINT [UQ_WorkflowName] UNIQUE NONCLUSTERED ([WorkflowName] ASC)
);

