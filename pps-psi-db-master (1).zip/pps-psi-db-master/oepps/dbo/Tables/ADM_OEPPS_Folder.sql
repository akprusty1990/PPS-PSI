﻿CREATE TABLE [dbo].[ADM_OEPPS_Folder] (
    [ADMOFID]    INT            NOT NULL IDENTITY,
    [ADMOSID]    INT            NOT NULL,
    [FolderName] VARCHAR (100) NULL,
    [FolderType] VARCHAR (50)   NOT NULL,
    [InsertedTS] DATETIME       CONSTRAINT [DF_ADM_OEPPS_Folder_InsertedTS] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_ADM_OEPPS_Folder] PRIMARY KEY CLUSTERED ([ADMOFID] ASC),
    CONSTRAINT [FK_ADM_OEPPS_Folder_ADM_OEPPS_Server] FOREIGN KEY ([ADMOSID]) REFERENCES [dbo].[ADM_OEPPS_Server] ([ADMOSID])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Watch|Data|Optimizer', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ADM_OEPPS_Folder', @level2type = N'COLUMN', @level2name = N'FolderType';

