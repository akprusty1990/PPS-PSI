﻿CREATE TABLE [dbo].[DTA_Task] (
    [DTATID]           INT           IDENTITY (1, 1) NOT NULL,
    [LUTTTID]          INT           NOT NULL,
    [TaskName]         VARCHAR (100) NULL,
    [TaskPurpose]      VARCHAR (50)  NOT NULL,
    [ImportFileLayout] VARCHAR (100) NOT NULL,
    [InsertedTS]       DATETIME      CONSTRAINT [DTA_Task_insertedTS] DEFAULT (getdate()) NULL,
    [ExecuteOrder]     INT           NULL,
    [DTAFID]           INT           NULL,
    [DTAMID]           INT           NULL,
    [TMPDTAWFID]       BIGINT        NULL,
    [ModifiedTS]       DATETIME      NULL,
    [DTAPID]           INT           NULL,
    [DTACFID]          INT           NULL,
    CONSTRAINT [PK_DTA_Task] PRIMARY KEY CLUSTERED ([DTATID] ASC),
    CONSTRAINT [FK_DTA_Task_LUT_TaskName] FOREIGN KEY ([LUTTTID]) REFERENCES [dbo].[LUT_TaskType] ([LUTTTID])
);



