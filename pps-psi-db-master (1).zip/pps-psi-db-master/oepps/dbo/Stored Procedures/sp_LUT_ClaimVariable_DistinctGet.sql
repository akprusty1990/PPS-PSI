﻿-- ========================================================================================
-- Author:		Callie Ju
-- Create date: 04/09/2020
-- Description:	Get a distinct list of claim variables baesd on VariableName and IsForSearch
--              with Min(LUTCVID)
-- Test case: 
-- EXEC [dbo].[sp_LUT_ClaimVariable_DistinctGet] 
-- ========================================================================================
CREATE PROCEDURE [dbo].[sp_LUT_ClaimVariable_DistinctGet]
AS
BEGIN
  
    SET NOCOUNT ON;

    WITH CTE
    AS (SELECT
        [VariableName],
        [IsForSearch],
        MIN([LUTCVID]) AS LUTCVID
    FROM [dbo].[LUT_ClaimVariable] WITH (NOLOCK)
    WHERE [IsForSearch] > 0
    GROUP BY [VariableName],
             [IsForSearch])
    SELECT
        cv.*
    FROM [dbo].[LUT_ClaimVariable] cv WITH (NOLOCK)
    INNER JOIN CTE WITH (NOLOCK)
        ON CTE.[LUTCVID] = cv.[LUTCVID]
    ORDER BY cv.[LabelOnUI]

END