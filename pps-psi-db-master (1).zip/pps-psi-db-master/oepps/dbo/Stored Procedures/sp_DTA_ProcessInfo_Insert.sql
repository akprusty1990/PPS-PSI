﻿

-- ===========================================================================
-- Author:  	Jaya Krishna
-- Create date: 10/16/2019
-- Description:	This sp creates new ProcessInfo with name = @procInfoName
--============================================================================
/*****************************************************************************
--Test Case
--EXEC sp_DTA_ProcessInfo_Insert 'testprocess'
--***************************************************************************/


CREATE PROCEDURE [dbo].[sp_DTA_ProcessInfo_Insert] @procInfoName varchar(50) = NULL

AS
BEGIN

	DECLARE @numRec int;
	DECLARE @currentStep varchar(100)
	SET NOCOUNT ON

	SET @currentStep = 'Validate input parameters.'
	SELECT
		@numRec = COUNT(*)
	FROM dbo.DTA_ProcessInfo
	WHERE [ProcessInfoName] = RTrim(LTrim(@procInfoName));


	BEGIN TRY
		DECLARE @ErrorMessage1 varchar(4000)
		
		IF (RTRIM(@procInfoName) = '')
		BEGIN
			SET @ErrorMessage1 = 'ERROR: Configuration name cannot be empty.'
			RAISERROR (@ErrorMessage1, 16, 1)
		END

		IF (@numRec > 0)
		BEGIN
			SET @ErrorMessage1 = 'ERROR: A configuration with this name already exists.'
			RAISERROR (@ErrorMessage1, 16, 1)
		END

		IF @numRec = 0
		BEGIN TRANSACTION DTA_ProcessInfo_Insert_Tran
			SET @currentStep = 'Insert new process info.'
			INSERT INTO DTA_ProcessInfo ([ProcessInfoName], [InsertedTS], [ModifiedTS])
			VALUES (Rtrim(Ltrim(@procInfoName)), GETDATE(), NULL)

		COMMIT TRANSACTION DTA_ProcessInfo_Insert_Tran

	END TRY

	BEGIN CATCH
		IF (ISNULL(@ErrorMessage1, '') = '')
		BEGIN
			SELECT
				@ErrorMessage1 = 'ERROR: Processing Option could not be saved.'
		END

		IF EXISTS (SELECT [name] FROM sys.dm_tran_active_transactions WHERE name = 'DTA_ProcessInfo_Insert_Tran')
		BEGIN
			ROLLBACK
		END
		
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_ProcessInfo_Insert', @ErrorMessage1, @@TRANCOUNT, @currentStep
		RAISERROR (@ErrorMessage1, 16, 1)
	END CATCH
END
