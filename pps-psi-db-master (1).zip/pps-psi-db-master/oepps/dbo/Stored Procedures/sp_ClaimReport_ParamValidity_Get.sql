﻿-- ===========================================================================
-- Author:          Callie Ju
-- Create date:     09/14/2020
-- Description:     check if DTACFID and DTAEID exist
-- Expected Output: Should be 1(true) if any of below scenario. Else, it should be 0(false)
----(1) DTACFID and DTAEID both exist
----(2) DTACFID exists, DTAEID = 0
-- ===========================================================================
/*****************************************************************************
DECLARE @flag bit
EXEC sp_ClaimReport_ParamValidity_Get 0, 0, @flag OUTPUT
PRINT @flag
*****************************************************************************/
CREATE PROCEDURE [dbo].[sp_ClaimReport_ParamValidity_Get] 
	@DTACFID INT = 0, 
	@DTAEID INT = 0, 
	@flag bit OUTPUT
AS
BEGIN
	
	SET NOCOUNT ON;
	-- check mandatory DTACFID is valid or not
	IF (ISNULL(@DTACFID, 0)=0 or 
		(SELECT COUNT(1)
		FROM [dbo].[DTA_ClaimFilter]
		WHERE DTACFID = @DTACFID) = 0)
	BEGIN
		SET @flag = 0
	END

	ELSE
		IF (ISNULL(@DTAEID, 0)=0 or 
			(SELECT COUNT(1)
			FROM [dbo].[DTA_Execution]
			WHERE DTAEID = @DTAEID) > 0)
		BEGIN
			SET @flag = 1
		END
		ELSE SET @flag = 0

END