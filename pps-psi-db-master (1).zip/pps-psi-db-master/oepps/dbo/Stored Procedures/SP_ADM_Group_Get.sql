﻿-- =============================================
-- Author: Chinnana Raja
-- Modified by : 
-- Create date: 10/08/2019
-- Modified date: 
-- Description:  Gets the list of groups  associated to the user

-- =============================================
/*****************************************************************************
--Test Case:
--EXEC SP_ADM_Group_Get 'ms\cchinnan'
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_ADM_Group_Get] @LoginUser varchar(500)
AS
BEGIN

    SET NOCOUNT ON;

    DECLARE @hasError bit,
            @loginData xml

    -- get haserror
    SELECT
        @hasError = HasError,
        @loginData = CAST(LoginData AS xml)
    FROM DTA_LoginSession
    WHERE LoginUser = @LoginUser

    -- check error
    IF (@HasError = 1)
    BEGIN
        RAISERROR ('INGX:', 16, 1)
    END
    ELSE
    BEGIN

        DECLARE @xml xml

        SELECT
            @xml = CAST(logindata AS xml)
        FROM DTA_LoginSession
        WHERE LoginUser = @LoginUser

        SELECT
            * INTO #ADM_Group
        FROM ADM_Group
        WHERE [Enabled] = 1
        AND GroupName IN (SELECT
            Tbl.Col.value('(.)[1]', 'varchar(200)')
        FROM @xml.nodes('//LoginSession//Groups//group') Tbl (Col))

        -- get there are valid groups
        IF (EXISTS (SELECT
                *
            FROM #ADM_Group)
            )
        BEGIN
            SELECT
                *
            FROM #ADM_Group
        END
        ELSE-- else get the default group
        BEGIN
            SELECT
                *
            FROM ADM_Group
            WHERE IsDefault = 1
            AND [Enabled] = 1
        END
    END
END
