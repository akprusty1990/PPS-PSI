﻿
-- ===============================================================================        
-- Author:  Anusha Subashini  
-- Create date: 04/02/2018    
-- Modified By: Chinnana Raja
-- Modified Date: 07/18/2019
-- Description: This SP is called when user click on expansion icon from 
-- Search Workflow page and gets nformation needed on UI from task details level
-- Modification: refactored Status per US463368 
-- Modification: SP returns only records for schedules/executions that are the closest to current time. (Alex Chern US481214 )
-- Modification: Added the column NumOfRuns based on the number of workflow execution(Chinnana Raja US549610 )
-- Modification: Add Begin and End statement for IF-ELSE block
-- ================================================================================        
/**********************************************************************************        
exec [sp_TaskDetails_Get] 7585, 0
***********************************************************************************/

CREATE PROCEDURE [dbo].[sp_TaskDetails_Get] @DTAWFID int, @nNumOfRuns int
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @currDate datetime2(0) = GETUTCDATE()
    DECLARE @DTAEID int = 0
    DECLARE @tblRun TABLE (
        [Name] varchar(100),
        Run int,
        DTAWFID int,
        DTASID int,
        DTAWFTID int,
        [Status] varchar(20),
        StartTime datetime,
        EndTime datetime,
        NumOfClaims int,
        RecordsPerSecond int,
        NumEdits int,
        NumReturnCodes int,
        ScheduleDate datetime,
        ModifiedTS datetime
    )
    INSERT INTO @tblRun
        SELECT
            [Name],
            Run,
            DTAWFID,
            DTASID,
            DTAWFTID,
            [Status],
            StartTime,
            EndTime,
            NumOfClaims,
            RecordsPerSecond,
            NumEdits,
            NumReturnCodes,
            ScheduleDate,
            ModifiedTS
        FROM dbo.fnWorkflowRunInfo(@DTAWFID)
        WHERE RunSum = 0;


    IF (0 = @nNumOfRuns)
    BEGIN
        --comment begins:
        --below code is for temp fix, needs to be refined later
        IF EXISTS (SELECT
                [DTATID],
                MAX([StartTime]) StartTime
            FROM [dbo].[vw_DTA_WorkflowInfo] WITH (NOLOCK)
            WHERE [DTAWFID] = @DTAWFID
            AND [StartTime] <= @currDate
            AND NOT [StartTime] IS NULL
            GROUP BY [DTATID])
        BEGIN
            SELECT
                vw.[TaskName] AS TaskName,
                vw.[TaskType],
                e.[Status] AS [Status],
                e.[DTAEID],
                e.[StartTime] AS StartTime,
                e.[EndTime] AS EndTime,
                CAST(d.Runs AS varchar(20)) AS NumOfRuns,
                e.[NumOfClaims] AS NumofClaims,
                e.[RecordsPerSecond] AS PerSecond,
                e.[NumEdits] AS WithEdits,
                e.[NumReturnCodes] AS WithReturnCodes,
                vw.[ExecuteOrder],
                e.[NumOfClaimStatusCodes]
            FROM [dbo].[vw_DTA_WorkflowInfo] vw WITH (NOLOCK)
            INNER JOIN [dbo].[DTA_Execution] e WITH (NOLOCK)
                ON vw.[DTAEID] = e.[DTAEID]
            INNER JOIN (SELECT
                [DTATID],
                MAX([StartTime]) StartTime
            FROM [dbo].[vw_DTA_WorkflowInfo] WITH (NOLOCK)
            WHERE [DTAWFID] = @DTAWFID
            AND [StartTime] <= @currDate
            AND NOT [StartTime] IS NULL
            GROUP BY [DTATID]) t
                ON vw.[DTATID] = t.[DTATID]
                AND vw.[StartTime] = t.[StartTime]
            INNER JOIN (SELECT DISTINCT
                DTAWFID,
                [status],
                CASE [status]
                    WHEN 'Reverting' THEN COUNT(1) - 1
                    WHEN 'Not Run' THEN 0
                    ELSE COUNT(1)
                END 'Runs'
            FROM [dbo].[vw_DTA_WorkflowInfo] vw WITH (NOLOCK)
            WHERE vw.DTAEID IS NOT NULL
            GROUP BY vw.DTAWFID,
                     vw.DTAWFTID,
                     vw.[status]) d
                ON d.[DTAWFID] = @DTAWFID
            ORDER BY [ExecuteOrder]
        END
        ELSE
        BEGIN
            SELECT DISTINCT
                vw.[TaskName] AS TaskName,
                vw.[TaskType],
                NULL AS [Status],
                NULL AS DTAEID,
                NULL AS StartTime,
                NULL AS EndTime,
                '' AS NumOfRuns,
                NULL AS NumofClaims,
                NULL AS PerSecond,
                NULL AS WithEdits,
                NULL AS WithReturnCodes,
                [ExecuteOrder],
                0 AS NumOfClaimStatusCodes
            FROM [dbo].[vw_DTA_WorkflowInfo] vw WITH (NOLOCK)
            WHERE [DTAWFID] = @DTAWFID
            AND NOT [DTATID] IS NULL
            ORDER BY [ExecuteOrder];
        END
    -- comment ends
    END
    ELSE
    BEGIN
        SELECT
            A.[Name] AS TaskName,
            D.[TaskType] AS TaskType,
            A.[Status] AS [Status],
            E.[DTAEID],
            A.[StartTime] AS StartTime,
            A.[EndTime] AS EndTime,
            CAST(@nNumOfRuns AS varchar(20)) AS NumOfRuns,
            A.[NumOfClaims] AS NumofClaims,
            A.[RecordsPerSecond] AS PerSecond,
            A.[NumEdits] AS WithEdits,
            A.[NumReturnCodes] AS WithReturnCodes,
            C.[ExecuteOrder],
            E.[NumOfClaimStatusCodes]
        FROM @tblRun A
        INNER JOIN dbo.[DTA_WorkflowTask] B WITH (NOLOCK)
            ON A.Run = @nNumOfRuns
            AND A.DTAWFTID = B.DTAWFTID
        INNER JOIN dbo.[DTA_Task] C WITH (NOLOCK)
            ON B.DTATID = C.DTATID
        INNER JOIN dbo.[LUT_TaskType] D WITH (NOLOCK)
            ON C.LUTTTID = D.LUTTTID
        INNER JOIN dbo.[DTA_Execution] E WITH (NOLOCK)
            ON A.DTASID = E.DTASID;
    END
END