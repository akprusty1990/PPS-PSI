﻿
-- =============================================  
-- Author:    Anusha  
-- Create date: 04/02/2018  
-- Description:  This SP is used only for trigger-based import. 
-- This  Stored Procedure is used for inserting data to below tables when file is dropped into OEPPS
-- 1. [dbo].[DTA_FileInfo]
-- Check if the  @fileName and @folderName exists in table  [dbo].[DTA_FileInfo]
--		if no, insert a new one
--      if yes, get DTAFID
-- 2. [dbo].[DTA_MappingInfo]  
-- Check if the  @LayoutName and @mappingInfor exists in table  [dbo].[dta_mappinginfo]
--		if no, insert a new one
--		if yes, get DTAMID
-- 3. [dbo].[DTA_Workflow]
--		to determine workflow name the SP takes file name and prefix it with "TRG-". The result length shouldn't be more then 30 chars.
--		In case Workflow name length exceed 30 chars the SP truncate the value.  
-- 4. [dbo].[DTA_Task] 
-- 5. [dbo].[DTA_WorkflowTask] 
-- 6. [dbo].[DTA_Schedule] 
-- =============================================  
-- Changes made to make @taskPurpose and @taskName in proper case.
/*************************************************************************************  
Select * from [dbo].[dta_fileinfo]
exec sp_OEPPS_Get_IDs_For_Import  'maping info', 'Layout  05252018','C:\Optum\FileWatch\FolderForClientC\Location7.txt'
exec sp_OEPPS_Get_IDs_For_Import  'maping info', 'Layout  05252018','C:\Optum\FileWatch\FolderForClientD\Location7.txt'
**************************************************************************************/
CREATE PROCEDURE [dbo].[sp_OEPPS_Get_IDs_For_Import] ( @AppID INT, @AcctID INT, @mappingInfor varchar(max),
	@LayoutName varchar(100), @FilePath varchar(500))
AS
BEGIN
  DECLARE @DTAFID int,
          @DTAMID int,
          @DTATID int,
          @DTAWFID int,
          @DTAWFTID int,
		  @ADMOFID int, 
          @workflowName varchar(100),
          @fileName varchar(500),
          @folderName varchar(500),
          @temp varchar(500),
		  @nameIncrement varchar(5),
		  @taskName varchar(10) = 'TRG-Import',
		  @taskTypeId int = 2,
		  @taskPurpose varchar(10) = 'Production',
		  @status varchar(15) = 'Not Run',
		  @scheduleStatus varchar(10) = 'Scheduled'


  BEGIN TRY
	DECLARE @currentStep varchar(100)
	DECLARE @errorMessage varchar (4000)
    SET NOCOUNT ON
    SET @fileName = REVERSE(SUBSTRING(REVERSE(@FilePath), 0, CHARINDEX('\', REVERSE(@FilePath))))
    SET @temp = SUBSTRING(@FilePath, 1, LEN(@FilePath) - CHARINDEX('\', REVERSE(@FilePath)))
    SET @folderName = REVERSE(SUBSTRING(REVERSE(@temp), 0, CHARINDEX('\', REVERSE(@temp))))
	
	--Insert ADM_OEPPS_Folder----------------------------------------------------------------------------
	SET @currentStep = 'Insert ADM_OEPPS_Folder.'
    SELECT @ADMOFID = [ADMOFID]
	FROM [dbo].[ADM_OEPPS_Folder]
	WHERE [FolderName] = @folderName

	IF @ADMOFID IS NULL
	BEGIN
		SELECT @ADMOFID = MAX([ADMOFID]) + 1
		FROM [dbo].[ADM_OEPPS_Folder]

		INSERT INTO [dbo].[ADM_OEPPS_Folder] (
			[ADMOFID], 
			[ADMOSID], 
			[FolderName], 
			[FolderType], 
			[InsertedTS])
		VALUES
			(@ADMOFID, 
			'1',	-- For now just hardcode ADMOSID
			@folderName, 
			'Watch',	-- For now just hardcode FolderType 
			GETUTCDATE())
	END
	
	--Insert DTA_FileInfo----------------------------------------------------------------------------
	SET @currentStep = 'Insert DTA_FileInfo.'
	SELECT	@DTAFID = [DTAFID]
	FROM [dbo].[ADM_OEPPS_Folder] f (nolock)
		INNER JOIN [dbo].[DTA_FileInfo] fi (nolock)
		ON f.[ADMOFID] = fi.[ADMOFID]
	WHERE [FileName] = @fileName
		AND [FolderName] = @folderName

    IF @DTAFID IS NULL
    BEGIN

      INSERT INTO [dbo].[DTA_FileInfo] (
		[ADMOFID], 
		[FileName], 
		[InsertedTS])
      SELECT
         [ADMOFID],
         @fileName,
         GETUTCDATE()
      FROM [dbo].[ADM_OEPPS_Folder] (nolock)
      WHERE [FolderName] = @folderName

      SET @DTAFID = SCOPE_IDENTITY()

    END

    --Insert DTA_MappingInfo----------------------------------------------------------------------------
	SET @currentStep = 'Insert DTA_MappingInfo.'
    SELECT @DTAMID = [DTAMID]
    FROM [dbo].[DTA_MappingInfo] (nolock)
    WHERE [LayoutName] = RTRIM(LTRIM(@LayoutName))
		AND [Content] = RTRIM(LTRIM(@mappingInfor))

    IF @DTAMID IS NULL
    BEGIN
		INSERT INTO [dbo].[DTA_MappingInfo]
		([LayoutName], [Content])
        VALUES (@LayoutName, @mappingInfor);
		SET @DTAMID = SCOPE_IDENTITY()
    END

	-- Determine workflow name

	SET @currentStep = 'Determine workflow name.'
    SET @workflowName = 'TRG-' + @fileName

    IF (LEN(@workflowName) > 30)
      SET @workflowName = SUBSTRING(@workflowName, 1, 30)

	-- Find existing workflow
	SET @currentStep = 'Find existing workflow.'
	SELECT TOP 1 @DTAWFID = [DTAWFID], @DTAWFTID = [DTAWFTID]
	FROM [dbo].[vw_DTA_WorkflowInfo]
	WHERE [WorkflowName] LIKE @workflowName + '[[]%]'
		AND [LUTTTID] = @taskTypeId
		AND [TaskName] = @taskName
		AND [DTAFID] = @DTAFID
		AND [DTAMID] = @DTAMID

	-- Workflow is not found
	IF @DTAWFID IS NULL
	BEGIN
		-- Find workflow with the same name pattern and determine next name increment. 
		SELECT @nameIncrement = MAX(CAST(SUBSTRING([WorkflowName], CHARINDEX('[', [WorkflowName], 1) + 1, CHARINDEX(']', [WorkflowName], 1) - CHARINDEX('[', [WorkflowName], 1) - 1) AS int)) + 1
		FROM [dbo].[vw_DTA_WorkflowInfo] 
		WHERE [WorkflowName] LIKE @workflowName + '[[]%]'
				AND [LUTTTID] = @taskTypeId
				AND [TaskName] = @taskName

		SET @workflowName = RTRIM(LTRIM(@workflowName)) + '[' + ISNULL(@nameIncrement, '1') + ']'

		-- Create new workflow
		SET @currentStep = 'Create new workflow.'
		INSERT INTO [dbo].[DTA_Workflow] ([WorkflowName],
			[ModifiedTS],
			[Status],
			[ScheduleStatus])
		VALUES (@workflowName, 
			NULL, 
			@status,
			@scheduleStatus)

		SET @DTAWFID = SCOPE_IDENTITY()

		-- Create task for new workflow
		SET @currentStep = 'Create task for new workflow.'
		INSERT INTO [dbo].[DTA_Task] ([LUTTTID],
			[TaskName],
			[TaskPurpose], 
			[ImportFileLayout],
			[InsertedTS],
			[ExecuteOrder],
			[DTAFID],
			[DTAMID])
		SELECT
			@taskTypeId,
			@taskName,
			@taskPurpose,
			'1',
			GETUTCDATE(),
			1,
			@DTAFID,
			@DTAMID

		SET @DTATID = SCOPE_IDENTITY();

    --Insert data Into [dbo].[DTA_WorkflowTask] Table  

	SET @currentStep = 'Insert into DTA_WorkflowTask.'
		INSERT INTO [dbo].[DTA_WorkflowTask] ([DTAWFID],
			[DTATID],
			[InsertedTS])
		VALUES (@DTAWFID, 
			@DTATID, 
			GETUTCDATE())

		SET @DTAWFTID = SCOPE_IDENTITY()

	END  -- New workflow with new task is created


    --Insert data Into [dbo].[DTA_Schedule] Table  
	SET @currentStep = 'Insert into DTA_Schedule.'
	INSERT INTO [dbo].[DTA_Schedule] ([DTAWFTID],
		[ScheduleType],
		[ScheduleDate],
		[ScheduleTime],
		[Frequency],
		[InsertedTS])
	VALUES (@DTAWFTID, 
		'One', 
		GETUTCDATE(), 
		NULL, 
		1, 
		GETUTCDATE())

  END TRY
  BEGIN CATCH
		SET @errorMessage = ERROR_MESSAGE();
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_OEPPS_Get_IDs_For_Import', @errorMessage, @@TRANCOUNT, @currentStep
		RAISERROR (@errorMessage, 16, 1)
  END CATCH

END

GO
