﻿-- ===========================================================================
-- Author:          Callie Ju
-- Create date:     08/13/2020
-- Description:     
-- return DRG detail for inpatient claims based on DTAEID and DTACFID
-- call sp_ClaimSearchDynamic_Get with parameters
-- ===========================================================================
/*****************************************************************************
--Test Case:
--exec [dbo].[sp_ClaimReport_DRG_Get] @DTACFID=4460
*****************************************************************************/
CREATE PROCEDURE [dbo].[sp_ClaimReport_DRG_Get]  @DTAEID int = 0, @DTACFID INT = 0
AS
BEGIN

       SET NOCOUNT ON;

       CREATE TABLE #tempClaim
       (
             [DTACID] BIGINT NOT NULL,
             [Ecb.prcr_type] VARCHAR(2) NULL,
             [Oob1.opt_rtn_code] VARCHAR(2) NULL
       )
      
	   DECLARE @claimTotalCount INT = 10;
	   SET @claimTotalCount = (
			SELECT COUNT(1)
			FROM [dbo].[vw_DTA_Claim_GroupIDTotal] WITH (NOLOCK))

       DECLARE @dynamicSQL varchar(max)='';
       EXEC sp_ClaimSearchDynamic_Get @DTAEID=@DTAEID,@DTACFID= @DTACFID,@IsReport =1,@DynamicSQL=@dynamicSQL OUTPUT 
        
          IF(@dynamicSQL <> '')
          BEGIN
                INSERT INTO #tempClaim
                EXEC (@dynamicSQL) 
          END

       SELECT
             ReportDetail.*,
             cdata.[ClaimData]
       FROM [dbo].[DTA_ClaimData] cdata WITH(NOLOCK) 
       INNER JOIN (
             SELECT TOP (10)
                    MIN(cd.[DTACID]) AS [ReportId],
                    CAST([DrgCode] AS VARCHAR(5)) AS [DrgCode],
                    COUNT(cd.[DTACID]) AS [GroupIDCount],
                    ISNULL(CONVERT(numeric(15, 2), AVG([InpatientTotalReimb])), 0.00) AS [AverageTotalPay],
                    ISNULL(MIN([InpatientTotalReimb]), 0.00) AS [MinTotalPay],
                    ISNULL(MAX([InpatientTotalReimb]), 0.00) AS [MaxTotalPay]
             FROM [dbo].[DTA_ClaimData] cd WITH (NOLOCK)
             INNER JOIN #tempClaim tp 
                    ON tp.[DTACID] = cd.[DTACID]
             WHERE [DrgCode] IS NOT NULL AND (tp.[Oob1.opt_rtn_code] = '00' OR tp.[Oob1.opt_rtn_code] is NULL)
             GROUP BY [DrgCode] 
             ORDER BY [GroupIDCount] DESC
       ) AS ReportDetail
       ON cdata.[DTACID] = ReportDetail.[ReportId]
       ORDER BY [GroupIDCount] DESC

END