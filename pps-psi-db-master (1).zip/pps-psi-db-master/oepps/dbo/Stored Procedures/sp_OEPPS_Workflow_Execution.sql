﻿-- =============================================
-- Author:		Alex Chern
-- Create date: 07/16/2018
-- Description:	This Stored Procedure is called from OEPPS. It creates records in DTA_Execution table based on scheduled time in
--				DTA_Schedule, returns data nesessary for OEPPS to perform its job. If some data is missing for any task then no 
--				tasks for the workflow are going to be scheduled for execution. 
-- Modify By :   David Pinho 
-- Modify Date:  1/08/2019
-- Modificatuon: Refactored stored procedure and added Action Column
-- Modification: 03/02/2020 - Include new override ID fields added to Process Info table - JK
-- Modification: 09/18/2020 - Include contract fields (facility, npi, taxonomy etc.,) in tmpProcessInfo table and the result. - JK
-- =============================================
/*******************************************************************************
EXEC [dbo].[sp_OEPPS_Workflow_Execution] 1, 1
*********************************************************************/
CREATE PROCEDURE [dbo].[sp_OEPPS_Workflow_Execution] @AppID INT, @AcctID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @tmpProcessInfo TABLE
	(
		[DTAPID] INT NOT NULL,
		[ADMOFID] INT NULL,
		[ProcessInfoName] varchar(50) NULL,
		[ADMOFID_UserPath] varchar(6000) NULL,
		[ADMOFID_SystemPath] varchar(6000) NULL,
		[ADMOFID_RatePath] varchar(6000) NULL,
		[ADMOFID_Optimizer64Path] varchar(6000) NULL,
		[Ecb.opcode1] char(2),
		[Ecb.pattype] char(2) NULL,
		[Ecb.code_class] char(2) NULL,
		[Pcb1.accept_if] char(2) NULL,
		[Ecb.opcode3] char(2) NULL,
		[Ecb.pyr_altlook_sw] char(1) NULL,
		[Ecb.map_override_id] varchar(20) NULL,
		[Ecb.hac_override_id] varchar(10) NULL,
		[Ecb.ace_override_id] varchar(20) NULL,
		[Ecb.apc_override_id] varchar(20) NULL,
		[Pcb1.facility]       VARCHAR(16) NULL,
	    [Pcb1.npi]            VARCHAR(10) NULL,
	    [Pcb1.taxonomy]       VARCHAR(10) NULL,
	    [Pcb1.paysrc]         VARCHAR(13) NULL,
	    [Pcb2.icd.hmo_risk]   CHAR(1)     NULL,
		[IsDefault] BIT NULL
	)

	-- Save current date
	DECLARE @date DATETIME2(0) = CAST(GETUTCDATE() AS DATETIME2(0))
	DECLARE @currentStep varchar(100)
	DECLARE @errorMessage varchar (4000)

	BEGIN TRY
		--Get Workflow id and schedule date of next scheduled Workflow that is not current running.
		SET @currentStep = 'Get info for next scheduled workflow.'
		DECLARE @dtawfid INT;
		DECLARE @scheduleDate DATETIME2;
		SELECT TOP(1) @dtawfid = wt.[DTAWFID], @scheduleDate = s.ScheduleDate
							FROM [dbo].[DTA_Schedule] s (NOLOCK)
							INNER JOIN [dbo].[DTA_WorkflowTask] wt (NOLOCK)
								ON  s.[DTAWFTID] = wt.[DTAWFTID]
							INNER JOIN  [dbo].DTA_Workflow w (NOLOCK)
								ON w.DTAWFID = wt.DTAWFID
							WHERE
								s.[ScheduleDate] <= @date
								AND s.[Action] IS NULL
								AND ISNULL(s.[ScheduleType], '') <> 'recurring'
								AND w.[Status] IN ('Completed', 'Failed', 'Not Run')
							ORDER BY s.ScheduleDate ASC

		--If no WorkFlow Id is found go directly to the return query
		IF @dtawfid IS NOT NULL
		BEGIN
			-- Gather all ProcessInfo  
			SET @currentStep = 'Gather all process info.'
			INSERT INTO @tmpProcessInfo
			EXEC [dbo].[sp_DTA_ProcessInfo]

			--Create Exection for scheduled workflow
			SET @currentStep = 'Create new execution for scheduled workflow.'
			INSERT INTO [dbo].[DTA_Execution] 	
			(
			  [DTASID],
			  [Status],
			  [StartTime],
			  [InitiatedBy]
			)
			SELECT s.[DTASID], 'In Progress', @date, s.[ModifiedBy]
			FROM [dbo].[DTA_Schedule] s (NOLOCK)
			INNER JOIN [dbo].[DTA_WorkflowTask] wt (NOLOCK)
				ON s.DTAWFTID = wt.DTAWFTID
			INNER JOIN [dbo].[DTA_Task] t (NOLOCK)
				ON  t.[DTATID] = wt.[DTATID] 
			WHERE wt.DTAWFID = @dtawfid AND s.ScheduleDate = @scheduleDate
			ORDER BY t.ExecuteOrder


			--Mark executed workflow to In Progress
			SET @currentStep = 'Update workflow status to In Progress.'
			UPDATE [dbo].[DTA_Workflow]
			SET [Status] = 'In Progress',
			ScheduleStatus= 'Scheduled'
			WHERE [DTAWFID] = @dtawfid

			--Mark executed schedule's action to 'PickedUp'
			SET @currentStep = 'Mark schedule action to PickedUp.'
			UPDATE s SET [Action] = 'Picked Up', [ModifiedTS] = CAST(@date AS DATETIME)
			FROM [dbo].[DTA_Schedule] s
			INNER JOIN [dbo].[DTA_WorkflowTask] wt (NOLOCK) 
			ON wt.[DTAWFTID] = s.[DTAWFTID] 
			WHERE wt.DTAWFID = @dtawfid AND s.ScheduleDate = @scheduleDate

			--Mark all schedules skipped that are before PickedUp Schedule Time and Workflow is running.
			SET @currentStep = 'Mark action to Skipped for schedules before PickedUp Schedule Time and Workflow is running..'
			UPDATE s SET [Action] = 'Skipped', [ModifiedTS] = CAST(@date AS DATETIME)
			FROM [dbo].[DTA_Schedule] s
			INNER JOIN [dbo].[DTA_WorkflowTask] wt (NOLOCK) 
				ON wt.[DTAWFTID] = s.[DTAWFTID] 
			INNER JOIN  [dbo].DTA_Workflow w (NOLOCK)
				ON w.DTAWFID = wt.DTAWFID
			WHERE s.[Action] IS NULL AND s.[ScheduleDate] <= @scheduleDate	AND w.[Status]	NOT IN ('Completed', 'Failed', 'Not Run')
		END
		-- Get executed schedule detail information to return.
		SET @currentStep = 'Get executed schedule detail information to return.'
		SELECT 
			wt.[DTAWFID], 
			e.DTAEID, 
			'0001 ' AS PEID, 
			f.[FileLocation],
			m.[Content] AS MappingContent, 
			wt.[DTATID], 
			wt.[DTAWFTID], 
			s.[DTASID],
			t.[LUTTTID],
			t.[ExecuteOrder],
			p.[ADMOFID_RatePath],
			p.[ADMOFID_UserPath],
			p.[ADMOFID_SystemPath],
			p.[ADMOFID_Optimizer64Path],
			'"' + p.[Ecb.opcode1] + '"' AS '"Input":~"EzgControl":~"opcode1":',
			'"' + p.[Ecb.pattype] + '"'  AS '"Input":~"EzgControl":~"pattype":',
			'"' + p.[Ecb.code_class] + '"'  AS '"Input":~"EzgControl":~"code_class":',
			'"' + p.[Pcb1.accept_if] + '"'  AS '"Input":~"EzgControl":~"accept_if":',
			'"' + p.[Ecb.opcode3] + '"'  AS '"Input":~"EzgControl":~"acegrouponly":',
			'"' + p.[Ecb.pyr_altlook_sw] + '"'  AS '"Input":~"EzgControl":~"pyr_altlook_sw":',
			'"' + p.[Ecb.map_override_id] + '"'  AS '"Input":~"EzgControl":~"map_override_id":',
			'"' + p.[Ecb.hac_override_id] + '"'  AS '"Input":~"EzgControl":~"hac_override_id":',
			'"' + p.[Ecb.ace_override_id] + '"'  AS '"Input":~"EzgControl":~"ace_override_id":',
			'"' + p.[Ecb.apc_override_id] + '"'  AS '"Input":~"EzgControl":~"apc_override_id":',
			'"' + p.[Pcb1.facility] + '"'  AS '"Input":~"PatientClaim":~"facility":',
			'"' + p.[Pcb1.npi] + '"'  AS '"Input":~"PatientClaim":~"npi":',
			'"' + p.[Pcb1.taxonomy] + '"'  AS '"Input":~"PatientClaim":~"taxonomy":',
			'"' + p.[Pcb1.paysrc] + '"'  AS '"Input":~"PatientClaim":~"paysrc":',
			'"' + IIF(p.[Pcb2.icd.hmo_risk] = '0', '', p.[Pcb2.icd.hmo_risk]) + '"'  AS '"Input":~"PatientClaim":~"InpatientClaim":~"hmo_risk":'
		FROM [dbo].[DTA_Schedule] s (NOLOCK)
		INNER JOIN [dbo].[DTA_WorkflowTask] wt (NOLOCK)
			ON s.[DTAWFTID] = wt.[DTAWFTID]
		INNER JOIN [dbo].[DTA_Task] t (NOLOCK)
			ON t.[DTATID] = wt.[DTATID] 
		INNER JOIN [dbo].[DTA_Execution] e (NOLOCK)
			ON s.[DTASID] = e.[DTASID]
		LEFT JOIN [dbo].[vw_DTA_FileInfo] f (NOLOCK)
			ON t.[DTAFID] = f.[DTAFID]
		LEFT JOIN [dbo].[DTA_MappingInfo] m (NOLOCK)
			ON t.[DTAMID] = m.[DTAMID]
		LEFT JOIN @tmpProcessInfo p
			ON t.[DTAPID] = p.[DTAPID]
		WHERE wt.DTAWFID = @dtawfid AND s.ScheduleDate = @scheduleDate
		ORDER BY t.ExecuteOrder

	END TRY
	BEGIN CATCH
		SET @errorMessage = ERROR_MESSAGE();
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_OEPPS_Workflow_Execution', @errorMessage, @@TRANCOUNT, @currentStep
		RAISERROR (@errorMessage, 16, 1)
	END CATCH
END

GO


