﻿-- ==========================================================================
-- Author:        Callie Ju
-- Create date:	  09/14/2020
-- Description:  
-- Get column definitions of report table based on LUTRID
-- ===========================================================================
/*****************************************************************************
--Test Case:
--EXEC sp_LUT_ReportVariable_Get 2
*****************************************************************************/
CREATE PROCEDURE [dbo].[sp_LUT_ReportVariable_Get] @LUTRID int
AS
BEGIN

	SET NOCOUNT ON;

    SELECT [LUTRVID]
	,rv.[LUTRID]
	,[ColumnTitle]
	,[DisplayTitle]
	,[HeaderClass]
	,[ColumnType]
	,[ColumnAlign]
	,[ReportDisplayName]
	FROM [dbo].[LUT_ReportVariable] rv WITH(NOLOCK)
	inner join [dbo].[LUT_Report] r WITH(NOLOCK) on rv.[LUTRID] = r.[LUTRID]
	WHERE rv.[LUTRID] = @LUTRID
	ORDER BY rv.[DisplayOrder]

END