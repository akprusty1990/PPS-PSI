﻿

-- ===============================================================================        
-- Author:          David Pinho
-- Create date:		10/25/2018    
-- Modified By: Chinnana Raja
-- Modified Date: 07/18/2019
-- Description:		Gets Filtered, Paginated and Sorted version of workflow search info.
-- Modification: Added the column NumOfRuns based on the number of workflow execution(Chinnana Raja US549610 )
-- Modification: Added nolock to avoid dead lock (JK - 03/10/2020)
-- ================================================================================        
/**********************************************************************************        
exec [sp_WorkflowSearchDynamic_Get] 0, 10, '[Name] LIKE ''%this%''', 'StartTime', 'DESC'

***********************************************************************************/

/****** Object:  StoredProcedure [dbo].[sp_WorkflowSearchDynamic_Get]    Script Date: 4/18/2018 10:31:03 AM ******/
CREATE PROCEDURE [dbo].[sp_WorkflowSearchDynamic_Get] @PageStart int = 0,
@PageLength int = 10,
@Filters varchar(max) = '1=1',
@ColumnToOrderBy varchar(50) = 'EndTime',
@Descending varchar(4) = ''
AS

BEGIN

  DECLARE @sql varchar(MAX)

  SET @sql = 'SET NOCOUNT ON;

	DECLARE @MAX_DATE datetime2(7) = CAST(''12/31/9999'' AS datetime2(7))
	DECLARE @MIN_DATE datetime2(7) = CAST(''1/1/1753'' AS datetime2(7))

	DECLARE @NumberOfRec int;

	DECLARE @result TABLE
	([Name] varchar(100),
	  [NumOfRuns]  varchar(20),
	  [DTAWFID] int,
	  [Status] varchar(20),
	  [StartTime] datetime2(7),
	  [EndTime] datetime2(7),
	  [NumOfClaims] int,
	  [PerSecond] int,
	  [WithEdits] int,
	  [WithReturnCodes] int,
	  [NumOfRec] int,
	  [ScheduleDate] datetime2(7),
	  [ModifiedTS] datetime2(7)
	);
	
	WITH ce	-- determine workflows that have records in DTA_Execution 
	AS
	(SELECT DISTINCT w.[DTAWFID], w.[StartTime], w.[ScheduleDate], MAX(w.[EndTime]) EndTime, d.Runs
	FROM
		[dbo].[vw_DTA_WorkflowInfo] w WITH (NOLOCK)
		INNER JOIN
		(SELECT b.*, MAX(c.[ScheduleDate]) ScheduleDate
		FROM
		(SELECT [DTAWFID], MAX([StartTime]) StartTime
		FROM [dbo].[vw_DTA_WorkflowInfo] WITH (NOLOCK)
		WHERE ISNULL(DTAEID, 0) > 0
		GROUP BY DTAWFID) b
		INNER JOIN vw_DTA_WorkflowInfo c WITH (NOLOCK)
		ON b.[DTAWFID] = c.[DTAWFID]
		AND b.[StartTime] = c.[StartTime]
		GROUP BY b.[DTAWFID], b.[StartTime]) a 
		ON w.[DTAWFID] = a.[DTAWFID]
		AND w.[StartTime] = a.[StartTime]
		AND w.[ScheduleDate] = a.[ScheduleDate]
		INNER JOIN
		(SELECT DISTINCT DTAWFID,[status],
		CASE [status] WHEN ''Reverting'' THEN count(1)- 1 when ''Not Run'' THEN 0 else count(1) end ''Runs''
		FROM [dbo].[vw_DTA_WorkflowInfo] vw WITH (NOLOCK)
		WHERE vw.DTAEID IS NOT NULL
		GROUP BY vw.DTAWFID,vw.DTAWFTID, vw.[status] ) d
		ON w.[DTAWFID] = d.[DTAWFID]
	GROUP BY w.[DTAWFID], w.[StartTime], w.[ScheduleDate], d.Runs)

	INSERT INTO @result
	SELECT 
		vw.[WorkflowName],
		CAST(max(ce.Runs) as varchar(20)),
		vw.[DTAWFID],
		vw.[Status],
		MIN(e.[StartTime]),
		MAX(e.[EndTime]),
		SUM(ISNULL(e.[NumOfClaims], 0)),
		AVG(ISNULL(e.[RecordsPerSecond], 0)),
		SUM(ISNULL(e.[NumEdits], 0)),
		SUM(ISNULL(e.[NumReturnCodes], 0)),
		@NumberOfRec AS [NumOfRec],
		vw.[ScheduleDate],
		vw.[ModifiedTS]
	FROM [dbo].[vw_DTA_WorkflowInfo] vw WITH (NOLOCK)
		INNER JOIN [dbo].[DTA_Execution] e WITH (NOLOCK)
		ON vw.[DTAEID] = e.[DTAEID]
		INNER JOIN ce
		ON vw.DTAWFID = ce.DTAWFID
			AND vw.[ScheduleDate] = ce.[ScheduleDate]
	GROUP BY vw.[WorkflowName],
		vw.[DTAWFID],
		vw.[Status],
		vw.[ScheduleDate],
		vw.[ModifiedTS]
	UNION
	SELECT DISTINCT 
		[WorkflowName],
		'''',
		[DTAWFID],
		[Status],
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		@NumberOfRec,
		MIN(ISNULL([ScheduleDate], @MIN_DATE)),
		[ModifiedTS]
	FROM [dbo].[vw_DTA_WorkflowInfo] WITH (NOLOCK)
	WHERE [DTAWFID] NOT IN (SELECT DISTINCT [DTAWFID] FROM ce)
	GROUP BY [WorkflowName], [DTAWFID], [Status], [ModifiedTS]

	SELECT *
	INTO #output
	FROM @result
	WHERE ' + @Filters + '

	SET @NumberOfRec = (SELECT COUNT(1) FROM #output)
	
	UPDATE #output
	SET [NumOfRec] = @NumberOfRec

	SELECT [Name],
	  [NumOfRuns],
	  [DTAWFID],
	  [Status],
	  [StartTime],
	  [EndTime],
	  [NumOfClaims],
	  [PerSecond],
	  [WithEdits],
	  [WithReturnCodes],
	  [NumOfRec]
	FROM #output
	ORDER BY ' + QUOTENAME(@ColumnToOrderBy) + ' ' + @Descending + ', [DTAWFID] desc ' + 
    'OFFSET ' + CAST(@PageStart AS varchar(14)) + ' ROWS' +
    ' FETCH NEXT ' + CAST(@PageLength AS varchar(3)) + ' ROWS ONLY 
	
	DROP TABLE #output'
	
  EXEC (@sql)

END




