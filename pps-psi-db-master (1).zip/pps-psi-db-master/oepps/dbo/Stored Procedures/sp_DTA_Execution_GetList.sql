﻿-- ====================================================================
-- Author:		Callie Ju
-- Create date: 11/18/2019
-- Modified date: 06/05/2020
-- Description:	Get a list of Execution Ids with TaskName associated
-- Modification: 03/06/2020 - Need to retrive all when execution name is not provided,
-- Modification: 06/05/2020 - Changed date formatting to 'MM-dd-yyyy hh:mm:ss' in execution name - JK
-- and exclude Export task type: LUTTTID = 1
-- Test case: 
-- EXEC [dbo].[sp_DTA_Execution_GetList] ''
-- ====================================================================
CREATE PROCEDURE [dbo].[sp_DTA_Execution_GetList] @executionName VARCHAR(100) = ''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	WITH CTE AS
	(
		SELECT e.[DTAEID]
			 , t.[TaskName] + ' ' + CONVERT(varchar, e.[EndTime], 110) + ' ' + CONVERT(varchar, e.[EndTime], 108) as [ExecutionName]
			 , e.[EndTime] 
		FROM [dbo].[DTA_Execution] e WITH(NOLOCK)
		inner join [dbo].[DTA_Schedule] s WITH(NOLOCK) on e.[DTASID] = s.[DTASID]
		inner join [dbo].[DTA_WorkflowTask] wt WITH(NOLOCK) on wt.[DTAWFTID] = s.[DTAWFTID]
		inner join [dbo].[DTA_Task] t WITH(NOLOCK) on t.[DTATID] = wt.[DTATID]
		WHERE e.[Status] = 'Completed' AND t.[LUTTTID] <> 1 -- exclude export tasks
	)

	SELECT CTE.[DTAEID], CTE.[ExecutionName]
	FROM CTE
	WHERE CTE.[ExecutionName] LIKE + '%' + @executionName + '%' 
	ORDER BY CTE.[EndTime] DESC, [ExecutionName]
	
END