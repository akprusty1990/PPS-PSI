﻿-- =============================================
-- Author:        Callie Ju
-- Create date:	  05/28/2020
-- Description:  
-- Get DTA_ClaimData detail for given DTACID
-- =============================================
/*****************************************************************************
--Test Case:
--EXEC sp_DTA_ClaimData_Get 1
*****************************************************************************/
CREATE PROCEDURE [dbo].[sp_DTA_ClaimData_Get] @DTACID bigint
AS
BEGIN

	SET NOCOUNT ON;
	
	SELECT *
	FROM [dbo].[DTA_ClaimData] WITH (NOLOCK)
	WHERE [DTACID] = @DTACID

END