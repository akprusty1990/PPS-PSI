﻿-- =============================================
-- Author:		Anusha Subashini
-- Create date: 07/02/2018
-- Description:	 To keep processing as simple as possible, 
-- the temporary tables that OEPPS writes to should be dynamic where when 
-- new columns are added or removed, OEPPS does not need to be updated.
-- =============================================
CREATE PROCEDURE [dbo].[sp_Schema_Get]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

		SELECT TOP 0 * FROM dbo.TMP_ClaimData;
		SELECT TOP 0 * FROM dbo.TMP_Claim;
END
