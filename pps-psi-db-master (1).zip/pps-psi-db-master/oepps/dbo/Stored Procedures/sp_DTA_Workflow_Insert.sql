﻿CREATE PROCEDURE [dbo].[sp_DTA_Workflow_Insert] @WorkflowName varchar(100) = NULL

AS
BEGIN

	DECLARE @numRec int;
	SET NOCOUNT ON

	SELECT
		@numRec = COUNT(*)
	FROM dbo.DTA_Workflow
	WHERE [WorkflowName] = RTrim(LTrim(@WorkflowName));


	BEGIN TRY
		DECLARE @ErrorMessage1 varchar(4000)
		DECLARE @currentStep varchar(100)
		
		SET @currentStep = 'Validate workflow name.'
		IF (RTRIM(@WorkflowName) = '')
		BEGIN
			SET @ErrorMessage1 = 'ERROR: Workflow name cannot be empty.'
			RAISERROR (@ErrorMessage1, 16, 1)
		END

		IF (@numRec > 0)
		BEGIN
			SET @ErrorMessage1 = 'ERROR: A workflow with this name already exists.'
			RAISERROR (@ErrorMessage1, 16, 1)
		END
		IF @numRec = 0
			BEGIN TRANSACTION
			SET @currentStep = 'Insert new workflow into DTA_Workflow..'
			INSERT INTO DTA_Workflow ([WorkflowName],
			[ModifiedTS],
			[Status],
			[ScheduleStatus])
				VALUES (Rtrim(Ltrim(@WorkflowName)), NULL,'Not Run', 'Unscheduled') 
				
		COMMIT

	END TRY
	BEGIN CATCH
		SELECT
			@ErrorMessage1 AS 'ERROR_MESSAGE'
		
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_Workflow_Insert', @ErrorMessage1, @@TRANCOUNT, @currentStep
		RAISERROR (@ErrorMessage1, 16, 1)
	END CATCH

END
