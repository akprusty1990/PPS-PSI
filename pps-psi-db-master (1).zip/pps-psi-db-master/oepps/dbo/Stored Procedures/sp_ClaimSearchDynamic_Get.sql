﻿-- =============================================
-- Author:      David Pinho
-- Create date: 10/30/2018
-- Modified by: Chinnana Raja
-- Modified date: 08/06/2019
-- Description:    
-- Gets a filtered, sorted and paginated list of the most recent processing of each claim in DTA_Claim by WorkFlowTaskId:
-- 1. Filter the claims dynamically, since we will be adding the abilitiy to change the displayed columns on the Claims Search page.
-- 2. Assign the TotalClaims to equal the number of filtered claims.
-- 3. Order and paginate the filtered claims dynamically.
-- Modification: 07/26/2019 - Updated the default filter condition to select all claims
-- Modification: 08/06/2019 - Updated the length of the dynamic query string to varchar(max) 
-- Modification: 07/01/2019 - Include encryption part - Callie
-- Modification: 06/15/2020 - Get latest claim based on the the value of GroupID. Claim history will no longer be tracked by DTAOCID.
-- Modification: 06/29/2020 - Replaced the CTE for determining the TotalCount with the CROSS JOIN
-- Modification: 07/14/2020 - Remove Dependencies/References to DTAOCID and IsLatest
-- Modification: 09/01/2020 - Filtering and sorting logic is seperated to improve performance
--                          - Process, Delete, Report functionalites call this SP to get the dyanmic SQL
-- =============================================
/*****************************************************************************
--Test Case:
--EXEC sp_ClaimSearchDynamic_Get 0, 0, 10, '1=1', 'Pcb1.from_date', 'DESC'

exec [sp_ClaimSearchDynamic_Get] @PageStart=0,@PageLength=10,
--@Filters=N'[Pcb1.from_date] LIKE ''%521340%''',
@ColumnToOrderBy=N'Pcb1.from_date',@Descending=N'DESC', @DTACFID = 0

*****************************************************************************/

CREATE PROCEDURE [dbo].[sp_ClaimSearchDynamic_Get] @DTAEID int = 0,
@PageStart int = 0,
@PageLength int = 10,
@Filters varchar(max) = '',
@ColumnToOrderBy varchar(50) = 'DTACID',
@Descending varchar(4) = '',
@DTACFID int = 0,
@IsReport bit = 0,
@IsProcess bit = 0,
@IsDelete bit = 0,
@DynamicSQL varchar(max) = '' OUTPUT WITH RECOMPILE
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @sql varchar(max);
    DECLARE @totalCount bigint;
    DECLARE @comparison int = 1;
    DECLARE @isLatest bit = 0;
    DECLARE @isDynamicSQL bit = 0;
    DECLARE @additionalJoins varchar(max) = '';
    DECLARE @claimFilters varchar(max) = '';
    DECLARE @claimDataFilters varchar(max) = '';
    DECLARE @concatFilters varchar(max) = '';
    DECLARE @variableType varchar(100);
    DECLARE @selectColumn varchar(200);
    DECLARE @sortColumn varchar(200);

    OPEN SYMMETRIC KEY SQLSymmetricKey256
    DECRYPTION BY CERTIFICATE PSICERTIFICATE;

    --Return DynamicSQL for Process/Delete/Report functionality.
    SET @isDynamicSQL = IIF(@IsReport = 1 OR @IsProcess = 1 OR @IsDelete = 1, 1, 0)

    --If DTAEID available, join for determining latest claim is not required.
    SET @isLatest = IIF(ISNULL(@DTAEID, 0) > 0 OR (@isProcess = 1 AND @Filters LIKE '%#tmp_ParentExecutionList%'), 0, 1)

    IF (@DTACFID > 0)
    BEGIN
        SELECT
            @comparison = LUTCNDID
        FROM DTA_ClaimFilter
        WHERE DTACFID = @DTACFID
        SELECT
            @additionalJoins = AdditionalJoins,
            @claimFilters = ClaimFilters,
            @claimDataFilters = ClaimDataFilters
        FROM dbo.udf_ClaimFilterDynamic(@DTACFID)
    END

    SET @selectColumn = IIF(@isDynamicSQL = 0 OR @isProcess = 1, 'c.DTACID', '')--Columns for Claim Search and Process
    + IIF(@isReport = 1 AND @comparison = 1, ' c.DTACID, rep.[Ecb.prcr_type], rep.[Oob1.opt_rtn_code] ', '')--Columns for Report (Satisfy All conditon)
    + IIF(@isReport = 1 AND @comparison = 2, ' c.DTACID, [Ecb.prcr_type], [Oob1.opt_rtn_code] ', '')--Columns for Report (Satisfy Any condition)
    + IIF(@isDelete = 1, 'c.GroupID', '')--Columns for Delete

    IF (@comparison = 1)
    BEGIN
        --append the filters for the table DTA_Claim
        IF (ISNULL(@claimFilters, '') <> ''
            AND ISNULL(@Filters, '') <> '')
        BEGIN
            SET @Filters = @Filters + ' AND ' + @claimFilters + ' '
        END
        ELSE
        BEGIN
            SET @Filters = @Filters + ISNULL(@claimFilters, '')
        END
        --If exists, append the condition for DTAEID.
        IF (ISNULL(@DTAEID, 0) > 0)
        BEGIN
            SET @Filters = IIF(ISNULL(@Filters, '') <> '', @Filters + ' AND DTAEID = ' + CAST(@DTAEID AS varchar(14)), ' DTAEID = ' + CAST(@DTAEID AS varchar(14)))
        END
        SET @sql = ' 
        SELECT DISTINCT '
        + @selectColumn
        + ' FROM ( SELECT DTACID' + IIF(@IsDelete = 1,', GroupID','') + ' FROM DTA_Claim c with (nolock) ' + IIF(@Filters <> '', 'WHERE ' + @Filters, '') +
        IIF(@isLatest = 0, ' ) c ',
        ' ) c INNER JOIN (SELECT lc.DTACID, ROW_NUMBER() OVER(partition by lc.GroupID Order By lc.ModifiedTS DESC, lc.DTACID DESC) AS rn
	    FROM vw_DTA_Claim_GroupID  lc with (nolock)) latestClaim on latestClaim.rn = 1 AND latestClaim.DTACID = c.DTACID ')
        + IIF(@claimDataFilters <> '',
        ' INNER JOIN (SELECT  cd.DTACID from DTA_ClaimData cd with (nolock) ' + @additionalJoins + ' WHERE ' + @claimDataFilters + ') fcd ON fcd.DTACID = c.DTACID ',
        '')
        + IIF(@isReport = 1, ' INNER JOIN DTA_Claim rep on rep.DTACID = c.DTACID ', '')
    END
    IF (@comparison = 2)
    BEGIN
        --append the filters for the table DTA_Claim and DTA_ClaimData
        SET @concatFilters = IIF(ISNULL(@claimFilters, '') <> '' AND ISNULL(@claimDataFilters, '') <> ''
        , '(' + @claimFilters + ' OR ' + @claimDataFilters + ')', ISNULL(@claimFilters, '') + ISNULL(@claimDataFilters, ''))

        SET @sql = ' 
	    SELECT DISTINCT ' +
        +@selectColumn
        + ' FROM ' +
        IIF(@isLatest = 1,
        '(SELECT lc.DTACID, ROW_NUMBER() OVER(partition by lc.GroupID Order By lc.ModifiedTS DESC, lc.DTACID DESC) AS rn
	     FROM vw_DTA_Claim_GroupID  lc with (nolock)) claim '
        , 'vw_DTA_Claim_GroupID claim ')
        + 'INNER JOIN DTA_Claim c with (nolock) ON c.DTACID = claim.DTACID '
        + IIF(ISNULL(@claimDataFilters, '') <> '', 'INNER JOIN DTA_ClaimData cd with (nolock) ON cd.DTACID = claim.DTACID ', '') +
        +@additionalJoins
        + ' WHERE '
        + IIF(@isLatest = 1, 'claim.rn = 1 AND ', '')
        + IIF(@isLatest = 0 AND ISNULL(@DTAEID, 0) > 0, 'claim.DTAEID = ' + CAST(@DTAEID AS varchar(14)) + ' AND ', '') 
        + '( ' + IIF(@Filters <> '', @Filters + ' AND ' + @concatFilters, @concatFilters) + ')'
    END

    IF (@isDynamicSQL = 1)
    BEGIN
        SET @DynamicSQL = @sql
    END
    ELSE
    BEGIN
        CREATE TABLE #TotalClaims (
            DTACID bigint NOT NULL PRIMARY KEY
        )
        CREATE TABLE #FilteredClaims (
            DTACID bigint NOT NULL PRIMARY KEY,
            RowID int
        )
        --Get all the claims satisfying the filter criteria
        INSERT INTO #TotalClaims (DTACID)
        EXEC (@sql)

        SELECT
            @variableType = VariableType
        FROM LUT_ClaimVariable
        WHERE VariableName = @ColumnToOrderBy

        --Determine columns required for default or custom sorting.
        --Add decrypt logic based on the VariableType.
        IF (@ColumnToOrderBy = 'longname')
        BEGIN
            SET @sortColumn = 'DTACID, ' + QUOTENAME('ecb.prcr_type')
            SET @ColumnToOrderBy = QUOTENAME(@ColumnToOrderBy) + ' ' + @Descending + ', c.DTACID DESC'
        END
        ELSE
        IF (@ColumnToOrderBy <> 'DTACID')
        BEGIN
            SELECT
                @sortColumn =
                             CASE
                                 WHEN @variableType = 'CIPHERTEXT' THEN 'DTACID, CONVERT(varchar(MAX), DecryptByKey(' + QUOTENAME(@ColumnToOrderBy) + ')) AS ' + QUOTENAME(@ColumnToOrderBy)
                                 WHEN @variableType = 'CIPHERDATE' THEN 'DTACID, CONVERT(DATE, DecryptByKey(' + QUOTENAME(@ColumnToOrderBy) + ')) AS ' + QUOTENAME(@ColumnToOrderBy)
                                 ELSE 'DTACID, ' + QUOTENAME(@ColumnToOrderBy)
                             END
            SET @ColumnToOrderBy = QUOTENAME(@ColumnToOrderBy) + ' ' + @Descending + ', tc.DTACID DESC'
        END
        ELSE
        BEGIN
            SET @sortColumn = 'DTACID'
            SET @ColumnToOrderBy = 'tc.' + QUOTENAME(@ColumnToOrderBy) + ' DESC'
        END

        --Dynamic SQL to perform sorting only on the claims that satisfies the search criteria.
        SET @sql = '
        SELECT fc.dtacid,rowID FROM 
	    (SELECT tc.DTACID,
        ROW_NUMBER() OVER(ORDER BY ' + @ColumnToOrderBy + ') RowID 
        FROM #TotalClaims tc ' +
        IIF(@sortColumn <> 'DTACID', 'INNER JOIN( SELECT ' + @sortColumn + ' FROM DTA_Claim ) c on tc.DTACID = c.DTACID ', '') +
        IIF(@sortColumn LIKE '%ecb.prcr_type%', 'LEFT JOIN LUT_CLAIM l on c.[ecb.prcr_type] = l.[shortname] COLLATE SQL_Latin1_General_Cp1_CS_AS ', '') +
        ') fc WHERE RowID > ' + CAST(@PageStart AS varchar(50)) + ' AND RowID <= ' + CAST((@PageStart + @PageLength) AS varchar(50))

        INSERT INTO #FilteredClaims
        EXEC (@sql)

        SELECT
            @totalCount = COUNT(1)
        FROM #TotalClaims

        SELECT
            f.[DTACID],
            f.[GroupID],
            f.[DTAPCID],
            f.[ClaimNum],
            f.[InsertedTS],
            f.[Source],
            f.[DTAEID],
            CONVERT(varchar(max), DECRYPTBYKEY(f.[Pcb1.med_num])) AS [Pcb1.med_num],
            CONVERT(varchar(max), DECRYPTBYKEY(f.[Oepps.member_id])) AS [Oepps.member_id],
            f.[Pcb1.npi] AS [Pcb1.npi],
            f.[Pcb1.taxonomy] AS [Pcb1.taxonomy],
            f.[Pcb1.paysrc] AS [Pcb1.paysrc],
            CONVERT(date, DECRYPTBYKEY(f.[Pcb1.from_date])) AS [Pcb1.from_date],
            CONVERT(date, DECRYPTBYKEY(f.[Pcb1.thru_date])) AS [Pcb1.thru_date],
            f.[Ecb.prcr_type] AS [Ecb.prcr_type],
            f.[Ecb.func_rtn_code] AS [Ecb.func_rtn_code],
            f.[Pcb1.facility] AS [Pcb1.facility],
            CONVERT(varchar(max), DECRYPTBYKEY(f.[Oepps.claim_id])) AS [Oepps.claim_id],
            CONVERT(varchar(max), DECRYPTBYKEY(f.[Oepps.fname])) AS [Oepps.fname],
            CONVERT(varchar(max), DECRYPTBYKEY(f.[Oepps.mname])) AS [Oepps.mname],
            CONVERT(varchar(max), DECRYPTBYKEY(f.[Oepps.lname])) AS [Oepps.lname],
            f.[StatusMsg],
            f.[StatusCode],
            f.[Oob1.opt_rtn_code] AS [Oob1.opt_rtn_code],
            f.[HasEdits],
            f.[ModifiedTS],
            f.[DTAPID],
            @totalCount AS TotalCount
        FROM [dbo].[DTA_CLAIM] f WITH (NOLOCK)
        INNER JOIN #FilteredClaims fc
            ON f.DTACID = fc.DTACID
        ORDER BY RowID

        --drop temp tables
        DROP TABLE #TotalClaims
        DROP TABLE #FilteredClaims
    END
END