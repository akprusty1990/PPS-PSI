﻿
-- ============================================================================        
-- Author:  Amy Zhao        
-- Create date: 06/12/2018        
-- Modified by: Matthew Chuong
-- Modified date: 03/05/2020
-- Description:         
-- This stored procedure is to save the xml format data of Task        
-- into database table DTA_Task and DTA_WorkflowTask.        
-- 1. Valid the input data   
--      check for valid folders
--      check for valid DTAWFID, DTACFID, DTAPID
--		check for valid DTAPEIDs for tasks.
--      if valid continue with SP else raise an error
-- 2. Get DTAWFID from <Dtawfid> 
-- 3. Update the ModifiedTS in the table DTA_Workflow
-- 4. If Dtafid=0 and Admofid>0, insert a new record into table DTA_FileInfo, then update Dtafid in #tmpDTA_Task  
-- 5. Insert the tasks into the table DTA_Task if the DTAIT is NULL or 0  
-- 6. Otherwise update the tasks DTAIT > 0  
-- 7. Merge the data in the table DTA_WorkflowTask: 
--       if DTATID+DTAWFID exists, update ModifiedTS; 
--       else , insert a new
-- 8. Delete the record in the table DTA_WorkflowTask if not exist in the passing xml
-- 9. Delete the records in DTA_Task based on the deleted result from previous step 
-- 10. If taskRelation xml has data, then put into #tmpDTA_TaskRelation
-- 11. Delete from [DTA_WorkflowTaskRelation] by DTAWFTID if any
-- 12. Insert into [DTA_WorkflowTaskRelation] if has DTAPWFTID, map by execute order
-- 13. Insert into [DTA_WorkflowTaskRelation] if has previous DTAEIDs
-- 14. Assign ModifiedTS in [DTA_WorkflowTaskRelation] only if the workflow relation is existing in the table.
-- 15. Delete the records in DTA_WorkflowTaskRelation based on deleted task for the current workflow.
-- =============================================================================       

/*******************************************************************************
--Test case 1: insert testing
DECLARE @XmlStr VARCHAR(MAX)

SET @XmlStr = '
<data>
  <Dtawfid>1076</Dtawfid>
  <WorkflowName>062251</WorkflowName>
  <DtaTask>
    <Dtatid>0</Dtatid>
    <Lutttid>2</Lutttid>
    <TaskName>asdf</TaskName>
    <TaskPurpose></TaskPurpose>
    <ImportFileLayout></ImportFileLayout>
    <InsertedTs>2018-06-22T18:05:17.343Z</InsertedTs>
    <ExecuteOrder>1</ExecuteOrder>
    <Admofid>4</Admofid>
    <Dtafid>0</Dtafid>
    <FileName>c:\\Document\\abc4</FileName>
    <Dtamid>0</Dtamid>
    <Tmpdtawfid />
    <ModifiedTs />
    <TaskType>T2</TaskType>
    <Dtapid>0</Dtapid>
    <TargetClaims>0</TargetClaims>
  </DtaTask>
  <DtaTask>
    <Dtatid>0</Dtatid>
    <Lutttid>2</Lutttid>
    <TaskName>asdf</TaskName>
    <TaskPurpose></TaskPurpose>
    <ImportFileLayout></ImportFileLayout>
    <InsertedTs>2018-06-22T18:05:17.343Z</InsertedTs>
    <ExecuteOrder>2</ExecuteOrder>
    <Admofid>0</Admofid>
    <Dtafid>0</Dtafid>
    <FileName />
    <Dtamid>0</Dtamid>
    <Tmpdtawfid />
    <ModifiedTs />
    <TaskType>T2</TaskType>
    <Dtapid>0</Dtapid>
    <TargetClaims>0</TargetClaims>
  </DtaTask>
  <DtaTask>
    <Dtatid>0</Dtatid>
    <Lutttid>2</Lutttid>
    <TaskName>asdf</TaskName>
    <TaskPurpose></TaskPurpose>
    <ImportFileLayout></ImportFileLayout>
    <InsertedTs>2018-06-22T18:05:17.343Z</InsertedTs>
    <ExecuteOrder>2</ExecuteOrder>
    <Admofid>0</Admofid>
    <Dtafid>0</Dtafid>
    <FileName>Amy3</FileName>
    <Dtamid>0</Dtamid>
    <Tmpdtawfid />
    <ModifiedTs />
    <TaskType>T2</TaskType>
    <Dtapid>0</Dtapid>
    <TargetClaims>0</TargetClaims>
  </DtaTask>
</data>
'

EXEC [dbo].[sp_DTA_Workflow_Save] @XmlStr
*********************************************************************/

/*********************************************************************
--Test case 2: Update testing
DECLARE @XmlStr VARCHAR(MAX)
SET @XmlStr = '
<data>
  <Dtawfid>1066</Dtawfid>
  <WorkflowName>062251</WorkflowName>
  <DtaTask>
    <Dtatid>1503</Dtatid>
    <Lutttid>2</Lutttid>
    <TaskName>asdf</TaskName>
    <TaskPurpose></TaskPurpose>
    <ImportFileLayout></ImportFileLayout>
    <InsertedTs>2018-06-22T18:05:17.343Z</InsertedTs>
    <ExecuteOrder>1</ExecuteOrder>
    <Admofid>4</Admofid>
    <Dtafid>0</Dtafid>
    <FileName>c:\\Document\\abc</FileName>
    <Dtamid>0</Dtamid>
    <Tmpdtawfid />
    <ModifiedTs />
    <TaskType>T2</TaskType>
    <Dtapid>0</Dtapid>
    <TargetClaims>0</TargetClaims>
  </DtaTask>
  <DtaTask>
    <Dtatid>1504</Dtatid>
    <Lutttid>2</Lutttid>
    <TaskName>asdf</TaskName>
    <TaskPurpose></TaskPurpose>
    <ImportFileLayout></ImportFileLayout>
    <InsertedTs>2018-06-22T18:05:17.343Z</InsertedTs>
    <ExecuteOrder>2</ExecuteOrder>
    <Admofid>0</Admofid>
    <Dtafid>0</Dtafid>
    <FileName />
    <Dtamid>0</Dtamid>
    <Tmpdtawfid />
    <ModifiedTs />
    <TaskType>T2</TaskType>
    <Dtapid>0</Dtapid>
    <TargetClaims>0</TargetClaims>
  </DtaTask>
  <DtaTask>
    <Dtatid>1505</Dtatid>
    <Lutttid>2</Lutttid>
    <TaskName>asdf</TaskName>
    <TaskPurpose></TaskPurpose>
    <ImportFileLayout></ImportFileLayout>
    <InsertedTs>2018-06-22T18:05:17.343Z</InsertedTs>
    <ExecuteOrder>2</ExecuteOrder>
    <Admofid>0</Admofid>
    <Dtafid>0</Dtafid>
    <FileName />
    <Dtamid>0</Dtamid>
    <Tmpdtawfid />
    <ModifiedTs />
    <TaskType>T2</TaskType>
    <Dtapid>0</Dtapid>
    <TargetClaims>0</TargetClaims>
  </DtaTask>
</data>
'
EXEC [dbo].[sp_DTA_Workflow_Save] @XmlStr

*********************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_Workflow_Save] @WorkflowXml varchar(max) = NULL

AS
BEGIN

    DECLARE @numRec int;
    SET NOCOUNT ON
	DECLARE @currentStep varchar(100)

    BEGIN TRY
        DECLARE @ErrorMessage varchar(4000)

        -- valid param
		SET @currentStep = 'Validate workflow name.'
        IF (RTRIM(ISNULL(@WorkflowXml, '')) = '')
        BEGIN
            SET @ErrorMessage = 'ERROR: Workflow name cannot be empty.'
            RAISERROR (@ErrorMessage, 16, 1)
        END

        -- parse the xml
		SET @currentStep = 'Parse xml and get workflow data.'
        DECLARE @iDoc AS int
        SET @iDoc = NULL

        EXEC sp_xml_preparedocument @iDoc OUTPUT,
                                    @WorkflowXml

        -- get Workflow data from xml
        SELECT
            * INTO #tmpDTA_Workflow
        FROM OPENXML(@iDoc, '/data', 2)
        WITH
        (
        [Dtawfid] [bigint],
        [WorkflowName] [varchar](100)
        ) xmlData

        -- get Tasks data from xml
		SET @currentStep = 'Get task data from xml.'
        SELECT
            * INTO #tmpDTA_Task
        FROM OPENXML(@iDoc, '/data/DtaTask', 2)
        WITH
        (
        [Dtatid] [bigint],
        [Lutttid] [int],
        [TaskName] [varchar](100),
        [TaskPurpose] [varchar](50),
        [TaskType] [varchar](50),
        [ExecuteOrder] [int],
        [Dtamid] [int],
        [Dtafid] [int],
        [FileName] [varchar](500),
        [Admofid] [int],
        [TargetClaims] [varchar](MAX),
        [Dtapid] [int],
        [Dtacfid] [int]
        ) xmlData
        WHERE ISNULL([TaskName], '') <> ''

        -- get Task Relation data from xml
		SET @currentStep = 'Get task relation data from xml.'
        SELECT
            * INTO #tmpDTA_TaskRelation
        FROM OPENXML(@iDoc, '/data/TaskRelation', 2)
        WITH
        (
        [TaskId] [bigint],
        [TaskName] [varchar](100),
        [ExecuteOrder] [int],
        [CurrentTaskExeOrder] [int],
        [DTAPEID] [int],
        [ExecutionName] [varchar](100),
        [Enabled] [bit],
        [IsChecked] [bit]
        ) xmlData

        -- clean up xml
        EXEC sp_xml_removedocument @iDoc
        SET @iDoc = NULL

        -- get DTAWFID
        DECLARE @DTAWFID bigint

        SELECT
            @DTAWFID = [Dtawfid]
        FROM #tmpDTA_Workflow

        -- valid DTAWFID
		SET @currentStep = 'Validate DTAWFID.'
        IF (ISNULL(@DTAWFID, 0) = 0)
        BEGIN
            SET @ErrorMessage = 'ERROR: DTAWFID cannot be empty.'
            RAISERROR (@ErrorMessage, 16, 1)
        END

        -- Check if DTAWFID Exists
        IF (NOT EXISTS ((SELECT
                *
            FROM DTA_Workflow w
            WHERE w.DTAWFID = @DTAWFID))
            )
        BEGIN
            SET @ErrorMessage = 'ERROR: This workflow no longer exists, please refresh the page to view the latest records or select Save As to copy this information to a new workflow.'
            RAISERROR (@ErrorMessage, 16, 1)
        END

        -- valid folders
		SET @currentStep = 'Validate folders.'
        IF (EXISTS (SELECT
                *
            FROM #tmpDTA_Task
            WHERE ISNULL(Admofid, 0) > 0
            AND Admofid NOT IN (SELECT
                ADMOFID
            FROM [dbo].[ADM_OEPPS_Folder]))
            )
        BEGIN
            SET @ErrorMessage = 'ERROR: There are invalid source or target folders.'
            RAISERROR (@ErrorMessage, 16, 1)
        END

		SET @currentStep = 'Check if claim filters and proc options exist.'
        --Get all Lutttid = 1 or 3 (Export or Process) DTACFIDs and count non-existent ID's       
        SELECT
            @numRec = COUNT(*)
        FROM #tmpDTA_Task tmpT
        LEFT JOIN DTA_ClaimFilter cf
            ON tmpT.DTACFID = cf.DTACFID
        WHERE tmpT.DTACFID > 0 
        AND (tmpT.Lutttid = 1 OR tmpT.Lutttid = 3)
        AND cf.DTACFID IS NULL

        --get all Lutttid = 3 or 4 (Process or Process then Import) DTAPIDs and count non-existent ID's        
        SELECT
            @numRec += COUNT(*)
        FROM #tmpDTA_Task tmpT
        LEFT JOIN DTA_ProcessInfo p
            ON tmpT.DTAPID = p.DTAPID
        WHERE (tmpT.Lutttid = 3 OR tmpT.Lutttid = 4)
        AND p.DTAPID IS NULL

        IF @numRec > 0
        BEGIN
            SET @ErrorMessage = 'ERROR: The processing option(s) and/or claim filter(s) no longer exist. Please modify accordingly.'
            RAISERROR (@ErrorMessage, 16, 1)
        END

		--check if parent EIDs are valid.
        SELECT 
			@numRec = COUNT(*)
		FROM #tmpDTA_TaskRelation tmpTR
		LEFT JOIN DTA_Execution e
			ON tmpTR.DTAPEID = e.DTAEID
		WHERE ISNULL(tmpTR.DTAPEID, 0) > 0
		AND e.DTAEID IS NULL
		IF @numRec > 0
        BEGIN
            SET @ErrorMessage = 'ERROR: The selected run(s) no longer exist. Please modify accordingly.'
            RAISERROR (@ErrorMessage, 16, 1)
        END

        -- begin tran
        BEGIN TRAN DTA_Workflow_Save_Transaction
			
			SET @currentStep = 'Get file info from temp table.'
            SELECT DISTINCT
                Admofid,
                [FileName] INTO #tmpFileInfos
            FROM #tmpDTA_Task
            WHERE ISNULL(Dtafid, 0) = 0
            AND ISNULL([Admofid], 0) <> 0
            AND ISNULL([FileName], '') <> ''

            IF (EXISTS (SELECT
                    *
                FROM #tmpFileInfos)
                )
            BEGIN
                -- create tmp to hold DTAFIDs
                DECLARE @tmpFileInfo TABLE (
                    DTAFID int,
                    ADMOFID int,
                    [FileName] varchar(500)
                );

                -- insert to DTA_FileInfo
				SET @currentStep = 'Insert to DTA_FileInfo'
                INSERT INTO DTA_FileInfo (ADMOFID, [FileName])
                OUTPUT INSERTED.DTAFID, INSERTED.ADMOFID, INSERTED.[FileName]
                INTO @tmpFileInfo
                    SELECT DISTINCT
                        Admofid,
                        [FileName]
                    FROM #tmpFileInfos

                -- update DTAFIDs in #tmpDTA_Task 
				SET @currentStep = 'Update DTAFIDs in #tmpDTA_Task.'
                UPDATE tmpT
                SET tmpT.Dtafid = tmpF.DTAFID
                FROM #tmpDTA_Task tmpT
                INNER JOIN @tmpFileInfo tmpF
                    ON tmpT.Admofid = tmpF.ADMOFID
                    AND tmpT.[FileName] = tmpF.[FileName]
            END

            -- update DAT_Workflow ModifiedTS
			SET @currentStep = 'Update ModifiedTS in DTA_Workflow.'
            UPDATE DTA_Workflow
            SET [ModifiedTS] = GETDATE()
            WHERE DTAWFID = @DTAWFID

            -- clean up the existing tmp ids
            UPDATE DTA_Task
            SET [TMPDTAWFID] = NULL

            -- insert the new id
			SET @currentStep = 'Insert new DTA_Task.'
            INSERT INTO DTA_Task ([LUTTTID]
            , [TaskName]
            , [TaskPurpose]
            , [ExecuteOrder]
            , [ImportFileLayout]
            , [DTAFID]
            , [DTAMID]
            , [DTAPID]
            , [TMPDTAWFID]
            , [InsertedTS]
            , [DTACFID])
                SELECT
                    [Lutttid],
                    [TaskName],
                    [TaskPurpose],
                    [ExecuteOrder],
                    '',
                    [Dtafid],
                    [Dtamid],
                    [Dtapid],
                    @DTAWFID,
                    GETDATE(),
                    [Dtacfid]
                FROM #tmpDTA_Task
                WHERE ISNULL(DTATID, 0) = 0

            -- UPDATE the existing tasks
			SET @currentStep = 'Update existing tasks.'
            UPDATE dtaT
            SET dtaT.[LUTTTID] = tmpT.[Lutttid],
                dtaT.[TaskName] = tmpT.[TaskName],
                dtaT.[TaskPurpose] = tmpT.[TaskPurpose],
                dtaT.[ExecuteOrder] = tmpT.[ExecuteOrder],
                dtaT.[ImportFileLayout] = '',
                dtaT.[DTAFID] = tmpT.[Dtafid],
                dtaT.[DTAMID] = tmpT.[Dtamid],
                dtaT.[DTAPID] = tmpT.[Dtapid],
                dtaT.[TMPDTAWFID] = @DTAWFID,
                dtaT.[ModifiedTS] = GETDATE(),
                dtaT.[DTACFID] = tmpT.[Dtacfid]
            FROM DTA_Task dtaT
            INNER JOIN #tmpDTA_Task tmpT
                ON dtaT.[DTATID] = tmpT.[DTATID]
            WHERE ISNULL(tmpT.DTATID, 0) > 0

            -- create a tmp table to hold the action results below
            DECLARE @tmpActionResult TABLE (
                ActionType varchar(10),
                DTATID int,
				DTAWFTID int
            );

            -- If exists update the ModifiedTS otherwise insert a new or delete existing
            ;
			SET @currentStep = 'Update DTA_WorkflowTask by merge with DTA_Task.';
            WITH T
            AS (SELECT
                *
            FROM [dbo].[DTA_WorkflowTask]
            WHERE DTAWFID = @DTAWFID)

            MERGE T AS target
            USING (SELECT
                @DTAWFID,
                DTATID
            FROM DTA_Task
            WHERE TMPDTAWFID = @DTAWFID) AS source (DTAWFID, DTATID)
            ON target.DTATID = source.DTATID
            WHEN MATCHED THEN UPDATE SET target.ModifiedTS = GETDATE()
            WHEN NOT MATCHED THEN INSERT (DTAWFID, DTATID, InsertedTS) VALUES (DTAWFID, DTATID, GETDATE())
            WHEN NOT MATCHED BY source THEN DELETE
            OUTPUT $ACTION AS ActionType, DELETED.DTATID, DELETED.DTAWFTID
            INTO @tmpActionResult
            ;

            -- delete the record from DTA_Task
			SET @currentStep = 'Delete the record from DTA_Task.'
            DELETE FROM DTA_Task
            WHERE DTATID IN (SELECT
                    DTATID
                FROM @tmpActionResult
                WHERE ActionType = 'DELETE')

			-- delete the record from DTA_WorkflowTaskRelation
			SET @currentStep = 'Delete the record from DTA_WorkflowTaskRelation'
            DELETE FROM DTA_WorkflowTaskRelation
            WHERE DTAWFTID IN (SELECT
                    DTAWFTID
                FROM @tmpActionResult
                WHERE ActionType = 'DELETE')

			SET @currentStep = 'Get updated workflow tasks into temp table.'
            SELECT
                * INTO #tmpWfTask
            FROM (SELECT
                wft.DTAWFID,
                wft.DTAWFTID,
                t.DTATID,
                t.ExecuteOrder
            FROM [dbo].[DTA_WorkflowTask] wft
            INNER JOIN [dbo].[DTA_Task] t
                ON wft.DTATID = t.DTATID
            WHERE DTAWFID = @DTAWFID) AS tmpWt

			-- get all DTAWFTID by DTAWFID and put into #tempWorkflowTask
            SELECT
                wt.DTAWFTID,
                wt.DTAWFID INTO #tempWorkflowTask
            FROM DTA_WorkflowTask wt
            WHERE wt.DTAWFID = @DTAWFID

			DECLARE @isExistingWFR BIT;
			SET @isExistingWFR = 0;

			-- check if workflow task relation exists in task relation table for current workflow.
			SET @currentStep = 'Check if task relation exists for the workflow.'
			IF EXISTS(SELECT 1
                FROM DTA_WorkflowTaskRelation
				INNER JOIN #tempWorkflowTask
                ON DTA_WorkflowTaskRelation.DTAWFTID = #tempWorkflowTask.DTAWFTID)
			BEGIN
				SET @isExistingWFR = 1;
			END

			-- check if taskRelation table has DTAWFTID from #tempWorkflowTask
			-- if so, update is done by deleting first then inserting
			SET @currentStep = 'Delete existing task relations.'
            DELETE FROM dbo.DTA_WorkflowTaskRelation
            WHERE EXISTS (SELECT
                    1
                FROM #tempWorkflowTask
                WHERE #tempWorkflowTask.DTAWFTID = DTA_WorkflowTaskRelation.DTAWFTID)

            -- insert previous task selections, mapped by execute order of tasks
			SET @currentStep = 'Insert previous task selections.'
			INSERT INTO DTA_WorkflowTaskRelation ([DTAWFTID]
            , [DTAPWFTID]
            , [DTAPEID]
            , [InsertedTS]
            , [ModifiedTS])
                SELECT
                    currentWft.DTAWFTID,
                    parentWft.DTAWFTID,
                    NULL,
                    GETDATE(),
                    IIF(@isExistingWFR=1, GETDATE(), NULL)
                FROM #tmpDTA_TaskRelation tr
                INNER JOIN #tmpWfTask AS currentWft
                    ON currentWft.ExecuteOrder = tr.CurrentTaskExeOrder
                    INNER JOIN #tmpWfTask AS parentWft
                        ON parentWft.ExecuteOrder = tr.ExecuteOrder
                WHERE --ISNULL(tr.TaskId, 0) = 0 AND 
                currentWft.DTAWFID = @DTAWFID
                AND tr.IsChecked = 1

            -- insert previous execution selections if any
			SET @currentStep = 'Insert previous execution selections.'
			INSERT INTO DTA_WorkflowTaskRelation ([DTAWFTID]
            , [DTAPWFTID]
            , [DTAPEID]
            , [InsertedTS]
            , [ModifiedTS])
                SELECT
                    currentWft.DTAWFTID,
                    NULL,
                    tr.DTAPEID,
                    GETDATE(),
                    IIF(@isExistingWFR=1, GETDATE(), NULL)
                FROM #tmpDTA_TaskRelation tr
                INNER JOIN #tmpWfTask AS currentWft
                    ON currentWft.ExecuteOrder = tr.CurrentTaskExeOrder
                WHERE --ISNULL(tr.TaskId, 0) = 0 and 
                tr.DTAPEID != 0

            -- clean up the existing tmp ids
			SET @currentStep = 'Clean up existing tmp ids.'
            UPDATE DTA_Task
            SET [TMPDTAWFID] = NULL

        COMMIT TRAN DTA_Workflow_Save_Transaction

    END TRY
    BEGIN CATCH

        IF (ISNULL(@ErrorMessage, '') = '')
        BEGIN
            SELECT
                @ErrorMessage = 'ERROR' + ERROR_MESSAGE()
        END

        IF EXISTS (SELECT
                [name]
            FROM sys.dm_tran_active_transactions
            WHERE name = 'DTA_Workflow_Save_Transaction')
        BEGIN
            ROLLBACK
        END
		
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_Workflow_Save', @errorMessage, @@TRANCOUNT, @currentStep
        RAISERROR (@ErrorMessage, 16, 1)

    END CATCH

END