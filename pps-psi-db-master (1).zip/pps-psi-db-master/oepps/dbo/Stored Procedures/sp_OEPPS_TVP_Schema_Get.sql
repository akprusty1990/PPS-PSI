﻿
-- =============================================
-- Author:		David Pinho
-- Create date: 10/07/2018
-- Description:	 To keep processing as simple as possible, 
-- the tvp that OEPPS writes to should be dynamic where when 
-- new columns are added or removed, OEPPS does not need to be updated.
-- =============================================
/*******************************************************************************
EXEC [dbo].[sp_OEPPS_TVP_Schema_Get]
*********************************************************************/
CREATE PROCEDURE [dbo].[sp_OEPPS_TVP_Schema_Get]	 @AppID INT, @AcctID INT
AS
BEGIN
SELECT
    c.name AS 'Column',
	TYPE_NAME(c.system_type_id) AS 'Type',
	c.max_length
FROM sys.table_types t
INNER JOIN sys.columns c
    ON c.[object_id] = t.type_table_object_id
WHERE  t.name = 'tvp_Claim'


SELECT
    c.name AS 'Column',
	TYPE_NAME(c.system_type_id) AS 'Type',
	c.max_length
FROM sys.table_types t
INNER JOIN sys.columns c
    ON c.[object_id] = t.type_table_object_id
WHERE  t.name = 'tvp_ClaimData'
END



