﻿-- ============================================================================        
-- Author:  Joe Lango        
-- Modified by        
-- Create date: 08/21/2020        
-- Description:         
-- Save a recurring schedule for a workflow.  
-- This operates similarly to sp_DTA_Schedule_Save, but incorporates the new DTA_ScheduleRecur table and associated logic.
-- Based on the interval and end date, create N number of DTA_Schedule records and relate them to the DTA_ScheduleRecur table.
-- Perform the same validation steps that occur in sp_DTA_Schedule_Save.
-- NOTE: Though the DTA_Schedule table was created with Frequency and RecursiveEvery columns, but they are not used here.
-- If passed a DtaSRid, consider this to be an edit.
-- All edit operations will delete the non-executed DTA_Schedule rows and insert rows that match the modified Recurrence values.
-- The recurring edits call the sp_DTA_ScheduleRecur_Delete procedure, and then proceed with the insert logic for the DTA_Schedule table.
-- If called with a DtaSid and not DtaSRid, this will turn a single Schedule into a recurring one.
-- =============================================================================       

/*******************************************************************************
--Test case 1: add recurrence
DECLARE @inXml VARCHAR(MAX)
SET @inXml = 
'<data>
	<DtaSchedule>
		<DtaWFID>145</DtaWFID>
		<ScheduleDate>2020-07-13 10:30:00</ScheduleDate>
		<RecurType>Daily</RecurType>
		<RecurEndDate>2020-08-27 10:30:00</RecurEndDate>
	</DtaSchedule>
</data>'
;

EXEC  [dbo].[sp_DTA_Schedule_SaveRecur] @inXml

*********************************************************************
--Test case 2: modify recurrence
DECLARE @inXml VARCHAR(MAX)

SET @inXml = 
'<data>
	<DtaSchedule>
		<DtaWFID>5</DtaWFID>
		<ScheduleDate>2020-07-13 10:30:00</ScheduleDate>
		<Dtasid/>
		<Dtasrid>3</Dtasrid>
		<RecurType>Daily</RecurType>
		<RecurEndDate>2020-08-27 10:30:00</RecurEndDate>
	</DtaSchedule>
</data>'

EXEC  [dbo].[sp_DTA_Schedule_SaveRecur] @inXml

*********************************************************************
--Test case 3: modify a single Schedule to be recurring
DECLARE @inXml VARCHAR(MAX)

SET @inXml = 
'<data>
	<DtaSchedule>
		<DtaWFID>5</DtaWFID>
		<ScheduleDate>2020-07-13 10:30:00</ScheduleDate>
		<Dtasid>111,112</Dtasid>
		<Dtasrid/>
		<RecurType>Daily</RecurType>
		<RecurEndDate>2020-08-27 10:30:00</RecurEndDate>
	</DtaSchedule>
</data>'

EXEC  [dbo].[sp_DTA_Schedule_SaveRecur] @inXml
*********************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_Schedule_SaveRecur] (
	@inXml varchar(max) = NULL
)
AS

BEGIN
	DECLARE @DtaWFID int
		, @ScheduleDate datetime2(0)
		, @currentStep varchar(100)
		, @DTASID varchar(MAX)
		, @DTASRID int
		, @ModifiedBy varchar(50)
		, @interval varchar(20)
		, @endDate datetime
		, @ErrorMessage varchar(4000)
		, @nRecNo int = 0
		, @nALLOWED_WORKFLOW_NO int = 10
	;

	SET NOCOUNT ON;

	BEGIN TRY
		/***
			Load data from XML
		***/

		SET @currentStep = 'Check input xml is valid.';
		IF (RTRIM(ISNULL(@inXml, '')) = '') BEGIN
			SET @ErrorMessage = 'ERROR: No schedule data provided.';
			RAISERROR (@ErrorMessage, 16, 1);
		END

		SET @currentStep = 'Parse xml.';
		DECLARE @iDoc AS int = null;

		EXEC sp_xml_preparedocument	@iDoc OUTPUT, @inXml;

		-- load Schedule data from xml
		SELECT @DtaWFID = [DtaWFID]
			, @ScheduleDate = [ScheduleDate]
			, @DTASID = NULLIF([Dtasid], '')
			, @DTASRID = NULLIF([Dtasrid], '')
			, @ModifiedBy = [ModifiedBy]
			, @interval = [RecurType]
			, @endDate = [RecurEndDate]
		FROM OPENXML(@iDoc, '/data/DtaSchedule', 2)
		WITH
		(
			[DtaWFID] [int]
			, [ScheduleDate] [datetime2]
			, [ModifiedBy] [varchar](50)
			, [Dtasid] [varchar](MAX)
			, [Dtasrid] int
			, [RecurType] varchar(20)
			, [RecurEndDate] datetime
		) xmlData
		;

		EXEC sp_xml_removedocument @iDoc;
		SET @iDoc = NULL;

		/***
			Validation Checks 
		***/

		--The workflow must have at least one task
		SET @currentStep = 'Validate workflow tasks.'
		IF NOT EXISTS(SELECT TOP(1) DTAWFTID FROM [dbo].[DTA_WorkflowTask] WITH(NOLOCK) WHERE [DTAWFID] = @DtaWFID) BEGIN
			SET @ErrorMessage = 'Info: The workflow cannot be scheduled without any tasks. Please assign tasks to the workflow.'
			RAISERROR (@ErrorMessage, 16, 1)
		END

		--end date must at least be >= schedule date
		SET @currentStep = 'Validate date range';
		IF @endDate < @ScheduleDate BEGIN
			SET @ErrorMessage = 'Info: end date must be greater than or equal to start date.';
			RAISERROR (@ErrorMessage, 16, 1);
		END
		
		--if DTASRID is provided, it must exist in the DTA_ScheduleRecur table
		IF @DTASRID is not null BEGIN
			SET @currentStep = 'Validate existing DTASRID';
			IF NOT EXISTS(SELECT DTASRID FROM dbo.DTA_ScheduleRecur WHERE DTASRID = @DTASRID) BEGIN
				SET @ErrorMessage = 'Info: The recurring schedule does not exist.  Please refresh the page to see the latest set of scheduled workflows.';
				RAISERROR (@ErrorMessage, 16, 1);
			END
		END

		--generate recurring schedule dates here, because we need them to perform the remaining validation checks
		DECLARE @recurDateGenerated table (
			RecurDate datetime NOT NULL
		);
		INSERT INTO @recurDateGenerated
		SELECT [DATE_WITH_TIME]
		FROM dbo.udf_RecurDateRange(@ScheduleDate, @endDate, @interval)
		;

		SET @currentStep = 'Validate concurrent tasks.';
		--abort and error if any of the recurring dates would violate the allowed workflow limit
		SELECT @nRecNo = COUNT(*)
		FROM (
			SELECT CONVERT(date, [ScheduleDate]) SchedDate, COUNT(*) MatchCount
			FROM @recurDateGenerated G
			CROSS APPLY (
				SELECT DISTINCT ScheduleDate, DTAWFID
				FROM DTA_Schedule S WITH(NOLOCK)
					INNER JOIN DTA_WorkflowTask WT WITH(NOLOCK)
						ON S.DTAWFTID = WT.DTAWFTID
						AND WT.DTAWFID != @DtaWFID 
					WHERE ABS(DATEDIFF(mi, [ScheduleDate], RecurDate)) < 60
			) T
			GROUP BY CONVERT(date, [ScheduleDate])
			HAVING (COUNT(*)) >= @nALLOWED_WORKFLOW_NO
		) S
		;

		IF @nRecNo > 0 BEGIN
			SET @ErrorMessage = 'Info: This workflow cannot be scheduled due to conflict(s) being encountered.';
			RAISERROR (@ErrorMessage, 16, 1);
		END

		/***
			Filter and remove duplicate schedules
		***/
		BEGIN TRANSACTION DTA_Schedule_SaveRecur_Tran;

		--remove any existing, non-executed schedules for this workflow if they will conflict with the recurring schedule 
		SET @currentStep = 'Validate concurrent dates.  Remove existing schedules that conflict with recurrence.';
		DELETE S
		FROM [dbo].[DTA_Schedule] S
			INNER JOIN dbo.DTA_WorkflowTask WFT
				ON S.DTAWFTID = WFT.DTAWFTID
		WHERE WFT.DTAWFID = @DtaWFID
			AND S.ScheduleDate IN (
				SELECT RecurDate
				FROM @recurDateGenerated
			)
			AND NOT EXISTS (
				SELECT DTAEID 
				FROM [dbo].[vw_DTA_WorkflowInfo] V
				WHERE V.DTASID = S.DTASID
					AND ISNULL([DTAEID], 0) > 0
			)
		;

		--If we could not remove a schedule above, it must be because it was executed or is executing now.  
		--	Skip creating this schedule date to avoid scheduling the same workflow multiple times at the same time.
		SET @currentStep = 'Validate concurrent dates.  Skip creation of executed schedules.';
		DELETE
		FROM @recurDateGenerated
		WHERE RecurDate IN (
			SELECT ScheduleDate 
			FROM [dbo].[DTA_Schedule] S
				INNER JOIN dbo.DTA_WorkflowTask WFT WITH(NOLOCK)
					ON S.DTAWFTID = WFT.DTAWFTID
			WHERE WFT.DTAWFID = @DtaWFID
		);

		/*** 
			Save data
		***/

		IF @DTASRID is not null BEGIN
			SET @currentStep = 'Modify schedule recurrence.';

			--delete non-executed scheduled records for this Recurrence
			EXEC dbo.[sp_DTA_ScheduleRecur_Delete] @DTASRID;	--leave off the second argument to avoid deleting the ScheduleRecur record, too.  We update that below instead.

			--update recurrence info
			UPDATE 
				dbo.DTA_ScheduleRecur
			SET
				[RecurType] = @interval
				, [RecurEndDate] = @endDate
			WHERE 
				DTASRID = @DTASRID
			;
		END
		ELSE BEGIN
			SET @currentStep = 'Create schedule recurrence.';

			--If the user chose to edit a non-recurring schedule to make it recurring, we must delete the standalone schedule to avoid duplicates.
			IF @DTASID is not null BEGIN
				DELETE s
				FROM [dbo].[DTA_Schedule] s
				WHERE CAST([DTASID] AS VARCHAR(MAX)) IN (
					SELECT RTRIM(LTRIM(value)) FROM STRING_SPLIT(@DTASID, ',')
				)
					AND NOT EXISTS (
						SELECT DTAEID 
						FROM [dbo].[vw_DTA_WorkflowInfo] v
						WHERE v.DTASID = s.DTASID
							AND ISNULL([DTAEID], 0) > 0
					)
				;
			END

			--insert recurrence info
			INSERT INTO dbo.DTA_ScheduleRecur (
				[RecurType]
				, [RecurEndDate]
			)
			SELECT @interval, @endDate
			;
			SELECT @DTASRID = SCOPE_IDENTITY();
		END

		--insert schedule records
		SET @currentStep = 'Insert new schedules from recurrence.';
		INSERT INTO DTA_Schedule (
			[DtaWFTID]
			, [InsertedTS]
			, [ModifiedBy]
			, [ScheduleDate]
			, [DTASRID]
		)
		SELECT
			WFT.DTAWFTID
			, GETUTCDATE()
			, @ModifiedBy
			, RecurDate
			, @DTASRID
		FROM @recurDateGenerated
			INNER JOIN dbo.DTA_WorkflowTask WFT WITH(NOLOCK)
				ON DTAWFID = @DtaWFID
		;

		SET @currentStep = 'Update schedule status in DTA_Workflow'
		UPDATE DTA_Workflow
		SET [ScheduleStatus] = 'Scheduled'
		WHERE [DTAWFID] = @DtaWFID
		;

		COMMIT;
	END TRY
	BEGIN CATCH
		IF (ISNULL(@ErrorMessage, '') = '')
		BEGIN
			SELECT
				@ErrorMessage = 'ERROR: ' +  ERROR_MESSAGE();
		END

		--We need this because there are errors being raised above that are outside of a transaction and we cannot roll back a transaction we do not have.
		IF EXISTS (SELECT
                [name]
            FROM sys.dm_tran_active_transactions
            WHERE name = 'DTA_Schedule_SaveRecur_Tran')
        BEGIN
            ROLLBACK;
        END

		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_Schedule_SaveRecur', @ErrorMessage, @@TRANCOUNT, @currentStep;
		RAISERROR (@ErrorMessage, 16, 1);
	END CATCH
END