﻿
-- =============================================
-- Author:  	David Pinho
-- Create date: 11/12/2018
-- Modified by: Kruti Sheth
-- Modified date: 02/07/2020
-- Description:	Delete claim and claimdata matching Id List passed in.
-- Modification: 02/07/2020 - add DTAEID as parameter for EID specific page deletion
-- Modification: 06/15/2020 - Delete claim and claimdata based on the GroupID. Claim history will no longer be tracked by DTAOCID. 
-- =============================================
/*******************************************************************************
EXEC [dbo].[sp_DTA_Claims_Delete] (WorkflowId)
*********************************************************************/
CREATE PROCEDURE [dbo].[sp_DTA_Claims_Delete] @tvpGroupID AS dbo.tvp_GroupIDList READONLY, @DTAEID int = 0
AS
BEGIN

	DECLARE @currentStep varchar(100)
	DECLARE @errorMessage varchar (4000)

	BEGIN TRY
		SET @currentStep = 'Delete claims by Id list.'
		DECLARE @del TABLE (
			DTACID bigint NOT NULL
		)
		DELETE dbo.DTA_Claim
		OUTPUT DELETED.DTACID INTO @del
		WHERE EXISTS (SELECT
				1
			FROM @tvpGroupID d
			WHERE ISNULL(d.GroupId,'') = DTA_Claim.GroupID
			AND (@DTAEID = 0
			OR DTA_Claim.DTAEID = @DTAEID))

		SET @currentStep = 'Delete Claim detail from DTA_ClaimData.'
		DELETE dbo.DTA_ClaimData
		WHERE EXISTS (SELECT
				1
			FROM @del d
			WHERE d.dtacid = DTA_ClaimData.DTACID)
	END TRY
	BEGIN CATCH
		SET @errorMessage = ERROR_MESSAGE();
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_Claims_Delete', @errorMessage, @@TRANCOUNT, @currentStep
		RAISERROR (@errorMessage, 16, 1)
	END CATCH
END


