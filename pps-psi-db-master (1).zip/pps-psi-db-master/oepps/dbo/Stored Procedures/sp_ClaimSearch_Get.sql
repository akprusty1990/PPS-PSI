﻿-- =============================================
-- Author:        David Pinho
-- Modified by : Chinnana Raja
-- Create date: 10/30/2018
-- Modified date: 09/27/2019
-- Description:  
-- Gets a list of the processing of each claim in DtaClaim for given WorkFlowTask 
-- Modification: 09/27/2019 - Added nolock to avoid dead lock
-- Modification: 10/21/2019 - Include encryption part - Callie
-- Modification: 06/15/2020 - Get latest claim based on the the value of GroupID. Claim history will no longer be tracked by DTAOCID.
-- Modification: 07/14/2020 - Remove Dependencies/References to DTAOCID and IsLatest
-- =============================================
/*****************************************************************************
--Test Case:
--exec sp_ClaimSearch_Get @PageStart=0,@PageLength=10
*****************************************************************************/

CREATE PROCEDURE [dbo].[sp_ClaimSearch_Get] @DTAEID INT = NULL,
@PageStart INT = 0,
@PageLength INT = 10
AS
BEGIN

    SET NOCOUNT ON;

    OPEN SYMMETRIC KEY SQLSymmetricKey256
    DECRYPTION BY CERTIFICATE PSICERTIFICATE;

    IF OBJECT_ID('tempdb..#FilteredClaims') IS NOT NULL DROP TABLE #FilteredClaims
    CREATE TABLE #FilteredClaims (
        DTACID varchar(255)
    )
    DECLARE @TotalCount bigint;

    IF (@DTAEID > 0)
    BEGIN
        SELECT
            @TotalCount = COUNT_BIG(1)
        FROM DTA_Claim WITH (NOLOCK)
        WHERE DTAEID = @DTAEID

        INSERT INTO #FilteredClaims
            SELECT
                DTACID
            FROM dbo.DTA_Claim WITH (NOLOCK)
            WHERE DTAEID = @DTAEID
            ORDER BY DTACID DESC
            OFFSET @PageStart ROWS
            FETCH NEXT @PageLength ROWS ONLY
    END
    ELSE
    BEGIN
        SELECT
            @TotalCount = COUNT_BIG(1)
	    FROM vw_DTA_Claim_GroupIDTotal WITH (NOLOCK)

        IF (@PageStart <= 655000)
        BEGIN
            INSERT INTO #FilteredClaims
                SELECT
                    latest.DTACID
                FROM DTA_Claim d WITH (NOLOCK)
                CROSS APPLY (SELECT TOP 1
                    dc.DTACID
                FROM vw_DTA_Claim_GroupID dc with (nolock)
                WHERE dc.GroupID = d.GroupID
                ORDER BY ModifiedTS DESC, DTACID DESC) latest
                WHERE d.DTACID = latest.DTACID
                ORDER BY d.DTACID DESC
                OFFSET @PageStart ROWS
                FETCH NEXT @PageLength ROWS ONLY
        END
        ELSE
        BEGIN
            INSERT INTO #FilteredClaims
                SELECT
                    D.DTACID
                FROM DTA_Claim d WITH (NOLOCK)
                INNER JOIN (SELECT
                    lc.DTACID,
                    ROW_NUMBER() OVER (PARTITION BY lc.GroupID ORDER BY lc.ModifiedTS DESC, lc.DTACID DESC) AS rn
                FROM vw_DTA_Claim_GroupID lc with (nolock)) latestClaim
                    ON latestClaim.rn = 1
                    AND latestClaim.DTACID = d.DTACID
                ORDER BY d.DTACID DESC
                OFFSET @PageStart ROWS
                FETCH NEXT @PageLength ROWS ONLY
        END
    END

    SELECT
        f.[DTACID],
        f.[GroupID],
        f.[DTAPCID],
        f.[ClaimNum],
        f.[InsertedTS],
        f.[Source],
        f.[DTAEID],
        CONVERT(varchar(max), DECRYPTBYKEY(f.[Pcb1.med_num])) AS [Pcb1.med_num],
        CONVERT(varchar(max), DECRYPTBYKEY(f.[Oepps.member_id])) AS [Oepps.member_id],
        f.[Pcb1.npi] AS [Pcb1.npi],
        f.[Pcb1.taxonomy] AS [Pcb1.taxonomy],
        f.[Pcb1.paysrc] AS [Pcb1.paysrc],
        CONVERT(date, DECRYPTBYKEY(f.[Pcb1.from_date])) AS [Pcb1.from_date],
        CONVERT(date, DECRYPTBYKEY(f.[Pcb1.thru_date])) AS [Pcb1.thru_date],
        f.[Ecb.prcr_type] AS [Ecb.prcr_type],
        f.[Ecb.func_rtn_code] AS [Ecb.func_rtn_code],
        f.[Pcb1.facility] AS [Pcb1.facility],
        CONVERT(varchar(max), DECRYPTBYKEY(f.[Oepps.claim_id])) AS [Oepps.claim_id],
        CONVERT(varchar(max), DECRYPTBYKEY(f.[Oepps.fname])) AS [Oepps.fname],
        CONVERT(varchar(max), DECRYPTBYKEY(f.[Oepps.mname])) AS [Oepps.mname],
        CONVERT(varchar(max), DECRYPTBYKEY(f.[Oepps.lname])) AS [Oepps.lname],
        f.[StatusMsg],
        f.[StatusCode],
        f.[Oob1.opt_rtn_code] AS [Oob1.opt_rtn_code],
        f.[HasEdits],
        f.[ModifiedTS],
        f.[DTAPID],
        @TotalCount AS [TotalCount]
    FROM [dbo].[DTA_Claim] f WITH (NOLOCK)
    INNER JOIN #FilteredClaims fc
        ON fc.[DTACID] = f.[DTACID]
    ORDER BY fc.[DTACID] DESC

END
