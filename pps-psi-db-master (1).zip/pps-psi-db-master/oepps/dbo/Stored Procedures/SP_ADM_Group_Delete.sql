﻿-- ============================================================================        
-- Author:  Chinnana Raja     
-- Modified by:    
-- Create date: 11/01/2019
-- Modified date: 
-- Description: This stored procedure is to delete user group from the table ADM_Group    
-- =============================================================================       

/*******************************************************************************
EXEC [dbo].[SP_ADM_Group_Delete]  0
*********************************************************************/


CREATE PROCEDURE [dbo].[SP_ADM_Group_Delete] @Admgid int

AS
BEGIN
    BEGIN TRY
        DECLARE @errorMessage varchar(4000)
		DECLARE @currentStep varchar(100)

		SET @currentStep =  'Validate user group.'
        IF NOT EXISTS (SELECT
                *
            FROM [dbo].[ADM_Group]
            WHERE ADMGID = @Admgid)
        BEGIN
            SET @errorMessage = 'User group does not exist.'
            RAISERROR (@errorMessage, 16, 1)
        END

        BEGIN TRAN ADM_Group_Delete_Tran
			SET @currentStep = 'Delete User group'
            DELETE FROM [dbo].[ADM_Group]
            WHERE ADMGID = @Admgid

        COMMIT TRAN ADM_Group_Delete_Tran

    END TRY
    BEGIN CATCH

        IF (ISNULL(@errorMessage, '') = '')
        BEGIN
            SELECT
                @errorMessage = ERROR_MESSAGE()
        END


        IF EXISTS (SELECT
                [name]
            FROM sys.dm_tran_active_transactions
            WHERE name = 'ADM_Group_Delete_Tran')
        BEGIN
            ROLLBACK TRAN ADM_Group_Delete_Tran
        END

		EXEC [sp_DTA_EventLog_Insert_SP] 'SP_ADM_Group_Delete', @errorMessage, @@TRANCOUNT, @currentStep
        RAISERROR (@errorMessage, 16, 1)

    END CATCH

END
