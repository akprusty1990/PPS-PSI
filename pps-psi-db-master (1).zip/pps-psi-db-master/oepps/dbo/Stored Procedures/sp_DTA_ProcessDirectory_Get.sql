﻿

--=============================================
--Author:    		Jaya Krishna
--Create date:		09/30/2019
--Description:  Get all folder paths from ADM_OEPPS_Folder based on folderType.
--=============================================
/*****************************************************************************
--Test Case
--EXEC sp_DTA_ProcessDirectory_Get 'Data'
--***************************************************************************/


CREATE PROCEDURE [dbo].[sp_DTA_ProcessDirectory_Get]
	@folderType varchar(50)
AS
BEGIN
	BEGIN TRY
		
		DECLARE @ErrorMessage varchar(4000)
		DECLARE @Admosid int
		SET @folderType = ISNULL(@folderType, '')
		
		--Get ADMOSID for default server
		SELECT TOP 1 @Admosid = ADMOSID
		FROM ADM_OEPPS_Server WITH(NOLOCK) 

		SELECT f.ADMOFID, 
				f.FolderType,
				CASE f.FolderType WHEN 'Data' THEN s.[DataPath] + '\' + COALESCE(f.[FolderName], '') 
								WHEN 'Watch' THEN s.[WatchFolder] + '\' + COALESCE(f.[FolderName], '') 
								WHEN 'Optimizer' THEN s.[OptimizerPath] + '\' + COALESCE(f.[FolderName], '') END AS FolderPath
		FROM [ADM_OEPPS_Folder] f WITH(NOLOCK) 
		INNER JOIN [ADM_OEPPS_Server] s WITH(NOLOCK) 
		ON f.ADMOSID = s.ADMOSID AND s.ADMOSID=@Admosid AND (f.FolderType = @folderType or @folderType='')
		ORDER BY FolderPath

	END TRY

	BEGIN CATCH
		IF (ISNULL(@ErrorMessage, '') = '')
		BEGIN
			SELECT @ErrorMessage = 'ERROR' + ERROR_MESSAGE()
		END
		
		RAISERROR (@ErrorMessage, 16, 1)
	END CATCH
END