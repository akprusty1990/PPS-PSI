﻿-- ============================================================================        
-- Author:  Chinnana Raja        
-- Modified by        
-- Create date: 11/12/2020      
-- Description:         
-- This stored procedure is to check the availablity of name for Claim Filter               
-- =============================================================================       

/*******************************************************************************
EXEC [dbo].[sp_DTA_ClaimFilter_CheckName] 'name'
*********************************************************************/
CREATE PROCEDURE [dbo].[sp_DTA_ClaimFilter_CheckName] @FilterName varchar(50)
AS
BEGIN

  SET NOCOUNT ON

  BEGIN TRY
    DECLARE @ErrorMessage varchar(4000)
    DECLARE @currentStep varchar(100)

    SET @currentStep = 'Check filter name.'
    IF (ISNULL(@FilterName, '') = '')
    BEGIN
      SET @ErrorMessage = 'ERROR: Filter name cannot be empty.'
      RAISERROR (@ErrorMessage, 16, 1)
    END

    IF EXISTS (SELECT
        *
      FROM [dbo].[DTA_ClaimFilter] WITH (NOLOCK)
      WHERE FilterName = @FilterName)
    BEGIN
      SET @ErrorMessage = 'ERROR: A claim filter with this name already exists.'
      RAISERROR (@ErrorMessage, 16, 1)
    END
  END TRY
  BEGIN CATCH

    IF (ISNULL(@ErrorMessage, '') = '')
    BEGIN
      SELECT
        @ErrorMessage = 'ERROR:' + ERROR_MESSAGE()
    END

    EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_ClaimFilter_CheckName',
                                     @errorMessage,
                                     @@TRANCOUNT,
                                     @currentStep
    RAISERROR (@ErrorMessage, 16, 1)

  END CATCH

END