﻿
-- ===========================================================================
-- Author:  	Anusha Subashini
-- Create date: 07/16/2018
-- Description:	This sp provides WorkflowName when passing StartDate and EndDate
-- We are not considering about the recurring, we will handle it later 
-- Modify By :   David Pinho 
-- Modify Date:  1/08/2019
-- Modificatuon: Added Dta_Schedule action column to the return
-- Modify By :   Chinnana Raja
-- Modify Date:  08/18/2020
-- Modificatuon: Convert schedule date to local time before comparison
-- Modified By :   Joe Lango
-- Modified Date:  08/21/2020
-- Modification: POC recurring schedules: pulling recurring data into schedule results
--============================================================================

/*****************************************************************************
--Test Case
--EXEC sp_DTA_Schedule_Get '2018-04-05 05:30:00', '2018-06-05 05:30:00' ,-240
--***************************************************************************/

CREATE  PROCEDURE [dbo].[sp_DTA_Schedule_Get] (@StartDate datetime, @EndDate datetime, @Offset int = 0)

AS
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from

  SET NOCOUNT ON;

  -- get the Workflowname, StartDate And EndDate
  SELECT
	Distinct wf.[DTAWFID],
    wf.[WorkflowName],
-- Following field returns comma separated list of DTASIDs associated with DTAWFID
(SELECT STUFF((
    SELECT ',' + cast([DTASID] as varchar(max))
    FROM [dbo].[DTA_Schedule] si WITH(NOLOCK) 
	INNER JOIN [dbo].[DTA_WorkflowTask] wwt WITH(NOLOCK) 
	ON si.[DTAWFTID] = wwt.[DTAWFTID]
	WHERE wwt.[DTAWFID] = wf.[DTAWFID] and si.[ScheduleDate] = s.[ScheduleDate]
	ORDER BY si.[DTAWFTID], si.[ScheduleDate]
    FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, '')) DTASID,
-- -------------------------------------------------------------------------------
    s.[ScheduleDate],
    MAX (e.[EndTime]) as [EndTime],
	s.[Action] AS [Action],
	sr.DTASRID,
	sr.RecurType,
	sr.RecurEndDate
  FROM [dbo].[DTA_Schedule] s WITH(NOLOCK) 
  INNER JOIN [dbo].[DTA_WorkflowTask] wft WITH(NOLOCK) 
    ON s.[DTAWFTID] = wft.[DTAWFTID]
  INNER JOIN [dbo].[DTA_Workflow] wf WITH(NOLOCK) 
    ON wft.[DTAWFID] = wf.[DTAWFID]
  FULL OUTER JOIN [dbo].[DTA_Execution] e WITH(NOLOCK) 
    ON s.[DTASID] = e.[DTASID]
  LEFT JOIN dbo.DTA_ScheduleRecur SR 
	ON s.DTASRID = sr.DTASRID
  WHERE DATEADD(MI,@Offset,[ScheduleDate]) BETWEEN @StartDate AND @EndDate
  GROUP BY wf.DTAWFID, s.ScheduleDate, wf.WorkflowName, s.[Action], sr.DTASRID, sr.RecurType, sr.RecurEndDate
END

