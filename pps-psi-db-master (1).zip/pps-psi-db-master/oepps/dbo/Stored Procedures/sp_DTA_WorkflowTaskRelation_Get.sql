﻿-- =============================================
-- Author:		Callie Ju
-- Create date: 10/28/2019
-- Description:	This sp is used to get parent workflow task list based on DTAWFTID list.
-- Modified date: 06/05/2020
-- Modification: 06/05/2020 - Changed date formatting to 'MM-dd-yyyy hh:mm:ss' in execution name - JK
-- =============================================
/*****************************************************************************
--Test Case:
--EXEC sp_DTA_WorkflowTaskRelation_Get 19
*****************************************************************************/
CREATE PROCEDURE [dbo].[sp_DTA_WorkflowTaskRelation_Get] @workflowId int 
AS
BEGIN 
    -- SET NOCOUNT ON added to prevent extra result sets from 
    -- interfering with SELECT statements. 
  
SET NOCOUNT ON;


WITH cte
	AS (SELECT
		e.DTAEID AS DTAEID,
		t.TaskName,
		e.ENDTIME
	FROM DTA_EXECUTION e WITH(NOLOCK) 
	INNER JOIN DTA_SCHEDULE s WITH(NOLOCK) 
		ON e.DTASID = s.DTASID
	INNER JOIN DTA_WorkflowTask wt WITH(NOLOCK) 
		ON s.DTAWFTID = wt.DTAWFTID
	INNER JOIN DTA_TASK t WITH(NOLOCK) 
		ON wt.DTATID = t.DTATID)

	SELECT 
		tr.DTAWFTRID,
		wf.WorkflowName,
		tr.DTAWFTID,
		t.DTATID,
		t.TaskName,
		tr.DTAPWFTID,
		parent.DTATID AS ParentDTATID,
		tr.DTAPEID,
		cte.TaskName + ' ' + CONVERT(varchar, cte.EndTime, 110) + ' ' + CONVERT(varchar, cte.EndTime, 108) AS ExecutionName,
		tr.InsertedTS,
		tr.ModifiedTS,
		cte.EndTime 
	FROM DTA_WorkflowTaskRelation tr WITH(NOLOCK) 
	LEFT OUTER JOIN DTA_WorkflowTask wft WITH(NOLOCK) 
	ON tr.DTAWFTID = wft.DTAWFTID
	INNER JOIN DTA_Workflow wf WITH(NOLOCK) 
	ON wft.DTAWFID = wf.DTAWFID
	INNER JOIN DTA_Task t WITH(NOLOCK) 
	ON t.DTATID = wft.DTATID
	LEFT OUTER JOIN DTA_WorkflowTask parent WITH(NOLOCK) 
	ON parent.DTAWFTID = tr.DTAPWFTID

	LEFT OUTER JOIN cte
		ON cte.DTAEID = tr.DTAPEID
	WHERE wf.[DTAWFID] = @workflowId
	ORDER BY ExecuteOrder

END