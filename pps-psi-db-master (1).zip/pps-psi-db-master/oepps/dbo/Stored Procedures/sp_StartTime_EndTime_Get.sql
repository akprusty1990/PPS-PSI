﻿

-- =================================================================================================
-- Author:    	Anusha Subashini
-- Create date: 04/02/2018
-- Description: This SP provides the latest StartTime, EndTime, ScheduleTime, InitiatedBy and Status; 
-- And called from [dbo].[sp_WorkflowSearch_get]
-- ==================================================================================================

CREATE PROCEDURE [dbo].[sp_StartTime_EndTime_Get]

AS
BEGIN


	SET NOCOUNT ON;
	DECLARE @nCount int;
	-- Creat Tempory Table

	CREATE TABLE #TempTable (
		[StartTime] datetime,
		[EndTime] datetime,
		[ScheduleTime] datetime,
		[InitiatedBy] varchar(50),
		[DTAWFID] int,
		[Status] varchar(50)
	)
	--Insert Data to tempory table
	INSERT INTO #TempTable
		SELECT
			MIN(StartTime) AS 'StartTime',
			MAX(Endtime) AS 'EndTime',
			[ScheduleTime],
			[InitiatedBy],
			wf.[DTAWFID],
			wf.[Status]
		FROM [dbo].[DTA_WorkFlowTask] wft
		LEFT OUTER JOIN [dbo].[DTA_WorkFlow] wf
			ON wft.[DTAWFID] = wf.[DTAWFID]
		LEFT OUTER JOIN [dbo].[DTA_Schedule] s
			ON wft.[DTAWFTID] = s.[DTAWFTID]
		LEFT OUTER JOIN [dbo].[DTA_Execution] e
			ON s.[DTASID] = e.[DTASID]
		WHERE EXISTS (SELECT
			MAX(E.DTAEID)
		FROM [dbo].[DTA_WorkFlowTask] wft
		LEFT OUTER JOIN [dbo].[DTA_WorkFlow] wf
			ON wft.[DTAWFID] = wf.[DTAWFID]
		LEFT OUTER JOIN [dbo].[DTA_Schedule] s
			ON wft.[DTAWFTID] = s.[DTAWFTID]
		LEFT OUTER JOIN [dbo].[DTA_Execution] e
			ON s.[DTASID] = e.[DTASID]
		GROUP BY S.[DTASID])
		GROUP BY	wf.[DTAWFID],
					[ScheduleTime],
					[InitiatedBy],
					wf.[Status]
	
	SELECT
		@nCount = COUNT(DTAWFID)
	FROM #TempTable
	GROUP BY DTAWFID
	--Fatch data from then tempory table
	SELECT
		StartTime,
		EndTime,
		ScheduleTime,
		InitiatedBy,
		DTAWFID,
		[Status]
	FROM #TempTable
	WHERE DTAWFID IN (SELECT
		DTAWFID
	FROM #TempTable
	GROUP BY DTAWFID
	HAVING COUNT(*) > 1)
	AND EndTime IS NULL
	AND InitiatedBy IS NULL
	UNION
	SELECT
		StartTime,
		EndTime,
		ScheduleTime,
		InitiatedBy,
		DTAWFID,
		[Status]
	FROM #TempTable
	WHERE DTAWFID IN (SELECT
		DTAWFID
	FROM #TempTable
	GROUP BY DTAWFID
	HAVING COUNT(*) = 1)




END
