﻿
-- ===============================================================================        
-- Author:  Anusha Subashini  
-- Create date: 04/02/2018    
-- Modified By: Chinnana Raja
-- Modified Date: 07/18/2019
-- Description: This SP is called when user click on expansion icon from 
-- Search Workflow page and gets nformation needed on UI from task details level
-- Modification: refactored Status per US463368 
-- Modification: SP returns only records for schedules/executions that are the closest to current time. (Alex Chern US481214 )
-- Modification: Added the column NumOfRuns based on the number of workflow execution(Chinnana Raja US549610 )
-- Modification: Added nolock to avoid dead lock (JK - 03/10/2020)
-- ================================================================================        
/**********************************************************************************        
exec [sp_WorkflowSearch_Get] 0, 100
***********************************************************************************/

CREATE PROCEDURE [dbo].[sp_WorkflowSearch_Get] @PageStart AS int,
@PageLength AS int
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @MAX_DATE datetime2(7) = CAST('12/31/9999' AS datetime2(7))
	DECLARE @MIN_DATE datetime2(7) = CAST('1/1/1753' AS datetime2(7))

	DECLARE @NumberOfRec int;
	SELECT
	@NumberOfRec = COUNT(1)
	FROM dbo.DTA_Workflow WITH (NOLOCK);

	DECLARE @result TABLE
	([Name] varchar(100),
	  [NumOfRuns]  varchar(20),
	  [DTAWFID] int,
	  [Status] varchar(20),
	  [StartTime] datetime2(7),
	  [EndTime] datetime2(7),
	  [NumOfClaims] int,
	  [PerSecond] int,
	  [WithEdits] int,
	  [WithReturnCodes] int,
	  [NumOfRec] int,
	  [ScheduleDate] datetime2(7),
	  [ModifiedTS] datetime2(7)
	);
	
	WITH ce	-- determine workflows that have records in DTA_Execution 
	AS
	(SELECT DISTINCT w.[DTAWFID], w.[StartTime], w.[ScheduleDate], MAX(w.[EndTime]) EndTime,d.Runs
	FROM
		[dbo].[vw_DTA_WorkflowInfo] w WITH (NOLOCK)
		INNER JOIN
		(SELECT b.*, MAX(c.[ScheduleDate]) ScheduleDate
		FROM
		(SELECT [DTAWFID], MAX([StartTime]) StartTime
		FROM [dbo].[vw_DTA_WorkflowInfo] WITH (NOLOCK)
		WHERE ISNULL(DTAEID, 0) > 0
		GROUP BY DTAWFID) b
		INNER JOIN vw_DTA_WorkflowInfo c WITH (NOLOCK)
		ON b.[DTAWFID] = c.[DTAWFID]
		AND b.[StartTime] = c.[StartTime]
		GROUP BY b.[DTAWFID], b.[StartTime]) a 
		ON w.[DTAWFID] = a.[DTAWFID]
		AND w.[StartTime] = a.[StartTime]
		AND w.[ScheduleDate] = a.[ScheduleDate]
		INNER JOIN
		(SELECT DISTINCT DTAWFID,[status],
		CASE [status] WHEN 'Reverting' THEN count(1)- 1 when 'Not Run' THEN 0 else count(1) end 'Runs'
		FROM [dbo].[vw_DTA_WorkflowInfo] vw WITH (NOLOCK)
		WHERE vw.DTAEID IS NOT NULL
		GROUP BY vw.DTAWFID,vw.DTAWFTID, vw.[status] ) d
		ON w.[DTAWFID] = d.[DTAWFID]
	GROUP BY w.[DTAWFID], w.[StartTime], w.[ScheduleDate], d.Runs)

	INSERT INTO @result
	SELECT 
		vw.[WorkflowName],
		CAST(max(ce.Runs) as varchar(20)),
		vw.[DTAWFID],
		vw.[Status],
		MIN(e.[StartTime]),
		MAX(e.[EndTime]),
		SUM(ISNULL(e.[NumOfClaims], 0)),
		AVG(ISNULL(e.[RecordsPerSecond], 0)),
		SUM(ISNULL(e.[NumEdits], 0)),
		SUM(ISNULL(e.[NumReturnCodes], 0)),
		@NumberOfRec AS [NumOfRec],
		vw.[ScheduleDate],
		vw.[ModifiedTS]
	FROM [dbo].[vw_DTA_WorkflowInfo] vw WITH (NOLOCK)
		INNER JOIN [dbo].[DTA_Execution] e WITH (NOLOCK)
		ON vw.[DTAEID] = e.[DTAEID]
		INNER JOIN ce
		ON vw.DTAWFID = ce.DTAWFID
			AND vw.[ScheduleDate] = ce.[ScheduleDate]
	GROUP BY vw.[WorkflowName],
		vw.[DTAWFID],
		vw.[Status],
		vw.[ScheduleDate],
		vw.[ModifiedTS]
	UNION
	SELECT DISTINCT 
		[WorkflowName],
		'',
		[DTAWFID],
		[Status],
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		@NumberOfRec,
		MIN(ISNULL([ScheduleDate], @MIN_DATE)),
		[ModifiedTS]
	FROM [dbo].[vw_DTA_WorkflowInfo] WITH (NOLOCK)
	WHERE [DTAWFID] NOT IN (SELECT DISTINCT [DTAWFID] FROM ce)
	GROUP BY [WorkflowName], [DTAWFID], [Status], [ModifiedTS]
	
	SELECT *
	FROM @result
	ORDER BY [EndTime] DESC, [StartTime] DESC, [ScheduleDate] DESC, ModifiedTS desc
	OFFSET @PageStart ROWS
	FETCH NEXT @PageLength ROWS ONLY


END


