﻿-- ============================================================================        
-- Author:  Matthew Chuong        
-- Create date: 01/20/2020
-- Modified by: Matthew Chuong
-- Modified Date: 03/05/2020
-- Description: This stored procedure is to delete a specified claim filter
-- from DTA_ClaimFilter and DTA_ClaimFilterDetail
-- 
-- =============================================================================   

/*******************************************************************************
--Test case 1: DELETE
EXEC sp_DTA_ClaimFilter_Delete 1
*********************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_ClaimFilter_Delete] @DTACFID int

AS
BEGIN
	
    BEGIN TRY
        DECLARE @ErrorMessage varchar(4000)
		DECLARE @currentStep varchar(100)

		SET @currentStep = 'Validate claim filter.'
        IF NOT EXISTS (SELECT
                *
            FROM [dbo].[DTA_ClaimFilter]
            WHERE DTACFID = @DTACFID)
        BEGIN
            SET @ErrorMessage = 'Filter does not exist.'
            RAISERROR (@ErrorMessage, 16, 1)
        END

        IF EXISTS (SELECT
                *
            FROM [dbo].[DTA_Task]
            WHERE DTACFID = @DTACFID)
        BEGIN
            SET @ErrorMessage = 'This filter is being utilized and cannot be deleted.'
            RAISERROR (@ErrorMessage, 16, 1)
        END

        BEGIN TRANSACTION DTA_ClaimFilter_Delete_Tran
			SET @currentStep = 'Delete claim filter.'
            DELETE FROM [dbo].[DTA_ClaimFilterDetail]
            WHERE DTACFID = @DTACFID

            DELETE FROM [dbo].[DTA_ClaimFilter]
            WHERE DTACFID = @DTACFID

        COMMIT TRANSACTION DTA_ClaimFilter_Delete_Tran

    END TRY

    BEGIN CATCH

        IF (ISNULL(@ErrorMessage, '') = '')
        BEGIN
            SELECT
                @ErrorMessage = 'Filter could not be deleted.'
        END

        IF EXISTS (SELECT
                [name]
            FROM sys.dm_tran_active_transactions
            WHERE name = 'DTA_ClaimFilter_Delete_Tran')
        BEGIN
            ROLLBACK
        END
		
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_ClaimFilter_Delete', @errorMessage, @@TRANCOUNT, @currentStep
        RAISERROR (@ErrorMessage, 16, 1)
    END CATCH
END