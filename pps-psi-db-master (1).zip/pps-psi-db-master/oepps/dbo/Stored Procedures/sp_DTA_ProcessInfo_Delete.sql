﻿

-- ===========================================================================
-- Author:  	Jaya Krishna
-- Create date: 10/22/2019
-- Modified date: 10/25/2019
-- Description:	This sp deletes ProcessInfo with DTAPID = @Dtapid
-- 10/25/2019: changed sp call to [sp_DTA_ProcessInfo_RemoveStatus_Get] instead of [sp_DTA_ProcessInfo_Status_Get].		
--============================================================================
/*****************************************************************************
--Test Case
--EXEC sp_DTA_ProcessInfo_Delete 25
--***************************************************************************/


CREATE PROCEDURE [dbo].[sp_DTA_ProcessInfo_Delete] @Dtapid int

AS
BEGIN TRY
	DECLARE @ErrorMessage varchar(4000)
	DECLARE @removeflag bit
	DECLARE @currentStep varchar(100)

	SET @currentStep = 'Check if process info is in use.'
	EXEC [sp_DTA_ProcessInfo_RemoveStatus_Get] @Dtapid, @removeflag OUTPUT

	-- check ProcessInfo remove flag
	IF (@removeflag =0)
	BEGIN
		SET @ErrorMessage = 'Processing Option could not be deleted.'
		RAISERROR (@ErrorMessage, 16, 1)
	END

	BEGIN TRANSACTION DTA_ProcessInfo_Delete_Tran
		SET @currentStep = 'Delete Process info.'
		DELETE FROM DTA_ProcessInfo 
		WHERE DTAPID = @Dtapid
	COMMIT

END TRY

BEGIN CATCH
	IF (ISNULL(@ErrorMessage, '') = '')
	BEGIN
		SELECT
			@ErrorMessage = 'Processing Option could not be deleted.'
	END

	IF EXISTS (SELECT [name] FROM sys.dm_tran_active_transactions WHERE name = 'DTA_ProcessInfo_Delete_Tran')
	BEGIN
		ROLLBACK
	END
	
	EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_ProcessInfo_Delete', @errorMessage, @@TRANCOUNT, @currentStep
	RAISERROR (@ErrorMessage, 16, 1)
END CATCH
