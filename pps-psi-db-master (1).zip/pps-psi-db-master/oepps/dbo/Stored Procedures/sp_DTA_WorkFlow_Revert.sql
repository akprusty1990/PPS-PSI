﻿-- =============================================
-- Author:    David Pinho
-- Create date: 11/12/2018
-- Modified by: Matthew Chuong
-- Modified by: Amy, Callie
-- Modified date: 01/17/2020
-- Modified date: 04/16/2020
-- Description:    Revert Latest Executions of workflow, including claim and claimdata.
-- Modification:   Use partition to truncate DTAEID specific claims; EID > 14999, use regular delete
-- This sp will also check if it has any children workflows that uses it's task and raise an error.
-- Modification: 07/14/2020 - Remove Dependencies/References to DTAOCID and IsLatest
-- Modified by: Joe Lango
-- Modified date: 09/21/2020
-- Modification:  
--                Delete from DTA_ScheduleRecur if there are no more associated Schedule records.
--				Do not set Workflow's ScheduleStatus to 'Unscheduled' if there are still scheduled runs
-- Modified by: Elliot Zhu
-- Modified date: 10/14/2020
-- Modification:  
--				Remove the condition check in the process of building #LatestExec to make 'In Progress' workflow revertable
-- Modification:  
--				Remove partition logic on the revert
--				Validation and revert logic is seperated. Parameter @isValidated is added. UI will call this SP twice. First call for validation. If successful, second call made for revert
-- =============================================
/*******************************************************************************
EXEC [dbo].[sp_DTA_WorkFlow_Revert] (WorkflowId)
*********************************************************************/
/*******************************************************************************
Test Case: Has Children Workflows that uses task
EXEC [dbo].[sp_DTA_WorkFlow_Revert] 9907, 0
EXEC [dbo].[sp_DTA_WorkFlow_Revert] 9907, 1
*********************************************************************/
CREATE PROCEDURE [dbo].[sp_DTA_WorkFlow_Revert] @DTAWFID AS int,
@isValidated bit
AS
BEGIN

    DECLARE @ErrorMessage varchar(4000)
    DECLARE @WorkflowName varchar(100)
    DECLARE @WorkflowStatus varchar(100)
    DECLARE @TaskName varchar(100)
    DECLARE @numRec int;
    DECLARE @DeletedSchedule TABLE (
        DTASRID int NULL
    );
    DECLARE @currentStep varchar(100)

    SET NOCOUNT ON
    BEGIN TRY

        --get latest execution of current workflow
        SELECT
            IDENTITY(int, 1, 1) AS RowIndex,
            e.[DTAEID],
            s.[DTASID] INTO #LatestExec
        FROM dbo.DTA_Execution e WITH (NOLOCK)
        INNER JOIN DTA_Schedule s WITH (NOLOCK)
            ON e.DTASID = s.DTASID
        INNER JOIN (SELECT
            s.DTAWFTID,
            MAX(e.StartTime) latest
        FROM dbo.DTA_Execution e WITH (NOLOCK)
        INNER JOIN DTA_Schedule s WITH (NOLOCK)
            ON e.DTASID = s.DTASID
        INNER JOIN dbo.DTA_WorkflowTask wt WITH (NOLOCK)
            ON s.DTAWFTID = wt.DTAWFTID
        INNER JOIN dbo.DTA_Workflow w WITH (NOLOCK)
            ON w.DTAWFID = wt.DTAWFID
        WHERE wt.DTAWFID = @DTAWFID
        GROUP BY s.DTAWFTID) ls
            ON s.DTAWFTID = ls.DTAWFTID
            AND e.StartTime = ls.latest;

        --See if current workflow has any children
        SELECT TOP 1
            wtr.DTAPEID,
            wtr.DTAWFTID INTO #FoundExec
        FROM DTA_WorkflowTaskRelation wtr
        INNER JOIN #LatestExec le
            ON wtr.DTAPEID = le.DTAEID
        INNER JOIN DTA_Schedule s
            ON le.DTASID = s.DTASID
        INNER JOIN DTA_WorkflowTask wt
            ON s.DTAWFTID = wt.DTAWFTID
        WHERE wt.DTAWFID = @DTAWFID
        ORDER BY wtr.InsertedTS DESC

        SELECT
            @numRec = COUNT(*)
        FROM #FoundExec

        IF (@isValidated = 0)
        BEGIN
            SET @currentStep = 'Validate before reverting the workflow.'
            SELECT
                @WorkflowStatus = Status,
                @WorkflowName = WorkflowName
            FROM DTA_Workflow
            WHERE DTAWFID = @DTAWFID
            --If workflow is in 'Reverting' staus, raise Error
            IF (@WorkflowStatus = 'Reverting')
            BEGIN
                SET @ErrorMessage = 'ERROR:  This workflow [' + @WorkflowName + '] is currently being reverted, please refresh the screen to see the latest status.'
                RAISERROR (@ErrorMessage, 16, 1)
            END

            --If any result is found raise Error
            IF (@numRec > 0)
            BEGIN
                --Get the name of the children workflow and taskflow
                SELECT
                    @WorkflowName = w.WorkflowName,
                    @TaskName = t.TaskName
                FROM DTA_WorkflowTask wt
                INNER JOIN #FoundExec fe
                    ON wt.DTAWFTID = fe.DTAWFTID
                INNER JOIN DTA_Workflow w
                    ON w.DTAWFID = wt.DTAWFID
                INNER JOIN DTA_Task t
                    ON t.DTATID = wt.DTATID

                SET @ErrorMessage = 'ERROR: The Task [' + @TaskName + '] within Workflow [' + @WorkflowName + '] is dependent on this run and cannot be reverted.'
                RAISERROR (@ErrorMessage, 16, 1)
            END

            UPDATE dbo.DTA_Workflow
            SET [STATUS] = 'Reverting'
            WHERE DTAWFID = @DTAWFID;
        END
        IF (@isValidated = 1)
        BEGIN
            IF (@numRec = 0)
            BEGIN
                SET @currentStep = 'Revert workflow after successful validation.'
                BEGIN TRANSACTION DTA_WorkFlow_Revert_Tran
                    DECLARE @rowIndex int = 1,
                            @maxRow int,
                            @DTAEID int,
                            @partitionNum int
                    SELECT
                        @maxRow = COUNT(*)
                    FROM #LatestExec

                    DELETE TOP (10000) dbo.DTA_Claim
                    WHERE EXISTS (SELECT
                            1
                        FROM #LatestExec i
                        WHERE i.DTAEID = DTA_Claim.DTAEID)

                    WHILE @@ROWCOUNT <> 0
                    BEGIN
                        DELETE TOP (10000) dbo.DTA_Claim
                        WHERE EXISTS (SELECT
                                1
                            FROM #LatestExec i
                            WHERE i.DTAEID = DTA_Claim.DTAEID)
                    END

                    DELETE TOP (10000) dbo.DTA_ClaimData
                    WHERE EXISTS (SELECT
                            1
                        FROM #LatestExec i
                            WHERE i.DTAEID = DTA_ClaimData.DTAEID)

                    WHILE @@ROWCOUNT <> 0
                    BEGIN
                        DELETE TOP (10000) dbo.DTA_ClaimData
                        WHERE EXISTS (SELECT
                                1
                            FROM #LatestExec i
                            WHERE i.DTAEID = DTA_ClaimData.DTAEID)
                    END

                    DELETE e
                        FROM dbo.DTA_Execution e
                    WHERE EXISTS (SELECT
                            1
                        FROM #LatestExec i
                        WHERE i.DTAEID = e.DTAEID)

                    DELETE s
                    OUTPUT DELETED.DTASRID INTO @DeletedSchedule
                        FROM dbo.DTA_Schedule s
                    WHERE EXISTS (SELECT
                            1
                        FROM #LatestExec i
                        WHERE i.DTASID = s.DTASID);

                    --Also delete from DTA_ScheduleRecur if there are no more associated Schedule records
                    IF EXISTS (SELECT TOP (1)
                            DTASRID
                        FROM @DeletedSchedule
                        WHERE DTASRID IS NOT NULL)
                    BEGIN
                        DELETE SR
                            FROM dbo.DTA_ScheduleRecur SR
                            INNER JOIN @DeletedSchedule D
                                ON SR.DTASRID = D.DTASRID
                        WHERE NOT EXISTS (SELECT
                                DTASID
                            FROM dbo.DTA_Schedule S
                            INNER JOIN @DeletedSchedule D
                                ON S.DTASRID = D.DTASRID
                                AND D.DTASRID IS NOT NULL)
                    END

                    SELECT
                        e.DTAEID,
                        e.[Status] INTO #newLatest
                    FROM dbo.DTA_Execution e WITH (NOLOCK)
                    INNER JOIN DTA_Schedule s WITH (NOLOCK)
                        ON e.DTASID = s.DTASID
                        INNER JOIN (SELECT
                            s.DTAWFTID,
                            MAX(e.StartTime) latest
                        FROM dbo.DTA_Execution e WITH (NOLOCK)
                        INNER JOIN DTA_Schedule s WITH (NOLOCK)
                            ON e.DTASID = s.DTASID
                            INNER JOIN dbo.DTA_WorkflowTask wt WITH (NOLOCK)
                                ON s.DTAWFTID = wt.DTAWFTID
                        WHERE wt.DTAWFID = @DTAWFID
                        GROUP BY s.DTAWFTID) ls
                            ON s.DTAWFTID = ls.DTAWFTID
                            AND e.StartTime = ls.latest;
                    SET @currentStep = 'Update workflow status after completing the revert operation.'
                    UPDATE dbo.DTA_Workflow
                    SET [STATUS] =
                                      CASE
                                          WHEN NOT EXISTS (SELECT
                                                  1
                                              FROM #newLatest) THEN 'Not Run'
                                          WHEN EXISTS (SELECT
                                                  1
                                              FROM #newLatest
                                              WHERE [Status] = 'In Progress') THEN 'In Progress'
                                          WHEN EXISTS (SELECT
                                                  1
                                              FROM #newLatest
                                              WHERE [Status] = 'Failed') THEN 'Failed'
                                          ELSE 'Completed'
                                      END,
                        ScheduleStatus =
                                            CASE
                                                WHEN NOT EXISTS (SELECT
                                                        1
                                                    FROM #newLatest) AND
                                                    NOT EXISTS (SELECT
                                                        DTAWFID
                                                    FROM [dbo].[vw_DTA_WorkflowInfo]
                                                    WHERE [DTAWFID] = @DTAWFID
                                                    AND ISNULL([DTASID], 0) > 0) THEN 'Unscheduled'
                                                ELSE ScheduleStatus
                                            END
                    WHERE DTAWFID = @DTAWFID;
                COMMIT TRANSACTION DTA_WorkFlow_Revert_Tran
            END
        END
    END TRY
    BEGIN CATCH
        IF (ISNULL(@ErrorMessage, '') = '')
        BEGIN
            SELECT
                @ErrorMessage = 'ERROR: ' + ERROR_MESSAGE()
            IF EXISTS (SELECT
                    [name]
                FROM sys.dm_tran_active_transactions
                WHERE name = 'DTA_WorkFlow_Revert_Tran')
            BEGIN
                --Rollback not required during the revert operation. Rollback could be expensive depending on the size of the workflow.
                COMMIT TRANSACTION DTA_WorkFlow_Revert_Tran
            END
            UPDATE dbo.DTA_Workflow
            SET [STATUS] = 'Reverting Incomplete'
            WHERE DTAWFID = @DTAWFID;            
        END
        EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_WorkFlow_Revert',
                                             @ErrorMessage,
                                             @@TRANCOUNT,
                                             @currentStep
        RAISERROR (@ErrorMessage, 16, 1)
    END CATCH
END
