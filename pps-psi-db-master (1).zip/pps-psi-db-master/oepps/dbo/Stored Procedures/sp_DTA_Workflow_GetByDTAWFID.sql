﻿
-- ============================================================================        
-- Author:  Amy Zhao        
-- Modified by        
-- Create date: 06/12/2018        
-- Description:         
-- This stored procedure is to get the task data based on @DTAWFID  
-- 1. Join all tables: DTA_Task, DTA_WorkflowTask and LUT_TaskType and filtered by @DTAWFID 
-- 2. Return all details from DTA_Task table plus TaskType from LUT_TaskType table     
-- ============================================================================= 
/*******************************************************************************
EXEC [dbo].[sp_DTA_Workflow_GetByDTAWFID] 2
*******************************************************************************/      
CREATE PROCEDURE [dbo].[sp_DTA_Workflow_GetByDTAWFID] (@DTAWFID bigint)
AS
BEGIN

	SET NOCOUNT ON;

	SELECT
		dtaT.[DTATID],
		dtaT.[LUTTTID],
		dtaT.[TaskName],
		dtaT.[TaskPurpose],
		dtaT.[ImportFileLayout],
		dtaT.[InsertedTS],
		dtaT.[ExecuteOrder],
		ISNULL(fileInfo.ADMOFID, 0) AS ADMOFID,
		dtaT.[DTAFID],
		fileInfo.[FileName],
		dtaT.[DTAMID],
		dtaT.[DTAPID],
		dtaT.[TMPDTAWFID],
		dtaT.[ModifiedTS],
		lutTT.[TaskType],
		dtaT.[DTACFID],
		CONVERT(bit, 0) AS HasParentTask,
		CONVERT(bit, 0) AS HasParentExecution
	FROM [dbo].[DTA_Task] dtaT WITH (NOLOCK)
	INNER JOIN [dbo].[DTA_WorkflowTask] dtaWT WITH (NOLOCK)
		ON dtaT.DTATID = dtaWT.DTATID
	INNER JOIN [dbo].[LUT_TaskType] lutTT WITH (NOLOCK)
		ON dtaT.LUTTTID = lutTT.LUTTTID
	Left JOIN [dbo].[DTA_FileInfo] fileInfo WITH (NOLOCK)
		ON dtaT.DTAFID = fileInfo.DTAFID
	Left JOIN [dbo].[ADM_OEPPS_Folder] folder WITH (NOLOCK)
		ON fileInfo.ADMOFID = folder.ADMOFID
	WHERE dtaWT.DTAWFID = @DTAWFID
	ORDER BY dtaT.[ExecuteOrder] ASC

END
