﻿-- =============================================
-- Author:		David Pinho
-- Create date: 10/17/2018
-- Description:	Mark Execution Status as 'Failed', Workflow Status as 'Failed', and subsequent tasks as 'Not Run'.
-- Modification: 02/26/2020 -	1. Update status for export because export doesn't call [dbo].[sp_OEPPS_DTA_Claim_Transfer]
--								2. Remove execution start time code to [dbo].[sp_OEPPS_DTA_Claim_Transfer]
-- Modification: 04/01/2020 -	1. Skip status update
-- Modification: 04/06/2020 -	Remove comment out code
--								--Status = @sStatus,
--								--EndTime = GETUTCDATE(),
--								Keep original status code
-- Modification: 10/16/2020 -	Luhai Huang Add try catch raise
-- =============================================
/*******************************************************************************
EXEC [dbo].[sp_OEPPS_Report_StatusCode] (ExecutionId), (StatusCode), (StatusMsg)
*********************************************************************/
CREATE PROCEDURE [dbo].[sp_OEPPS_Report_StatusCode] @AppID INT, @AcctID INT,
	@DTAEID AS INT, @StatusCode INT, @StatusMsg VARCHAR(1024), 
	@NumOfClaimStatusCodes INT = 0
AS
BEGIN
	DECLARE @DTAWFID		INT;
	DECLARE @sStatusMsg	VARCHAR(1024);
	DECLARE @currentStep varchar(100)
	DECLARE @errorMessage varchar (4000)

	BEGIN TRY
		SELECT TOP (1)
			@DTAWFID = wt.dtawfid
		FROM [dbo].[DTA_WorkflowTask] wt
		INNER JOIN [dbo].[DTA_Schedule] s
			ON wt.DTAWFTID = s.DTAWFTID
		INNER JOIN [dbo].[DTA_Execution] e
			ON s.DTASID = e.DTASID
		INNER JOIN [dbo].[DTA_Task] t
			ON wt.DTATID = t.DTATID
		WHERE e.DTAEID = @DTAEID

		SELECT @sStatusMsg = ISNULL(StatusMsg, ' ') + ' ' + @StatusMsg
		FROM [dbo].[DTA_Execution] WHERE DTAEID = @DTAEID

		UPDATE [dbo].[DTA_Execution]
		SET StatusCode = CASE WHEN (StatusCode IS NULL OR 0 = StatusCode) THEN @StatusCode 
							  ELSE [StatusCode] END,	  
			StatusMsg = @sStatusMsg,
			[NumOfClaimStatusCodes] = ISNULL([NumOfClaimStatusCodes], 0) + @NumOfClaimStatusCodes
		WHERE DTAEID = @DTAEID;
	END TRY
	BEGIN CATCH
		SET @errorMessage = ERROR_MESSAGE();
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_OEPPS_Report_StatusCode', @errorMessage, @@TRANCOUNT, @currentStep
		RAISERROR (@errorMessage, 16, 1)
	END CATCH
END



