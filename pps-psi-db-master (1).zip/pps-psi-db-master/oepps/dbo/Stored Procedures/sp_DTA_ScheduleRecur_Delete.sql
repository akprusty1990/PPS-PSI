﻿-- ============================================================================        
-- Author:  Joe Lango        
-- Modified by        
-- Create date: 08/24/2020        
-- Description:
-- Delete non-executed recurring schedules from DTA_Schedule.
-- Optionally delete the DTA_ScheduleRecur record, too.
-- This also performs the same validations as in sp_DTA_Schedule_Delete:
-- 1. Only delete schedules that do not appear in DTA_Execution table
-- 2. If after deletion there are no more schedules for workflow in future 
--		update workflow ScheduleStatus to 'Unscheduled'. 
-- =============================================================================       
/*******************************************************************************
--Test case
--delete non-executed DTA_Schedule records
EXEC dbo.sp_DTA_ScheduleRecur_Delete @DTASRID=6

--use the optional second argument to also delete the DTA_ScheduleRecur record
EXEC dbo.sp_DTA_ScheduleRecur_Delete @DTASRID=6, 1
*********************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_ScheduleRecur_Delete] (
	@DTASRID int,
	@deleteAll bit = 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE @DtaWFID int
		, @ErrorMessage varchar(1000)
		, @currentStep varchar(100)
	;

	BEGIN TRY
		-- if DTASRID is null, we error.
		IF @DTASRID is null BEGIN
			SET @ErrorMessage = 'ERROR: No recurring schedule ID provided.';
			RAISERROR (@ErrorMessage, 16, 1);
		END

		--need workflow id if we are to change its status.  make sure to get it before deleting the schedule!
		SET @currentStep = 'Get workflow id for the schedule.';
		SELECT TOP(1) @DtaWFID = [DTAWFID]
		FROM [dbo].[vw_DTA_WorkflowInfo]
		WHERE DTASRID = @DTASRID
		;

		SET @currentStep = 'Delete unexecuted schedules.';
		DELETE s
		FROM [dbo].[DTA_Schedule] s
		WHERE DTASRID is not null
			AND DTASRID = @DTASRID
			AND NOT EXISTS (
				SELECT DTAEID 
				FROM [dbo].[vw_DTA_WorkflowInfo] v
				WHERE v.DTASID = s.DTASID
					AND ISNULL([DTAEID], 0) > 0
			)
		;

		--change Workflow status if no other schedules are found
		IF NOT EXISTS(SELECT DTAWFID
						FROM [dbo].[vw_DTA_WorkflowInfo]
						WHERE [DTAWFID] = @DtaWFID AND ISNULL([DTASID], 0) > 0) BEGIN
			SET @currentStep = 'Update workflow schedule status.';
			UPDATE [dbo].[DTA_Workflow]
			SET [ScheduleStatus] = 'Unscheduled'
			WHERE [DTAWFID] = @DtaWFID
			;
		END

		IF @deleteAll = 1 BEGIN
			SET @currentStep = 'Delete recurrence definiton, if possible.';
			--if this schedule is recurring and there are no recurring schedules left, delete the DTA_ScheduleRecur record, too
			--NOTE: if some of the tasks have executed, we will never delete the recurence because it would break referential integrity.
			DELETE
			FROM dbo.DTA_ScheduleRecur
			WHERE DTASRID = @DTASRID
				AND NOT EXISTS(
					SELECT DTASID 
					FROM dbo.DTA_Schedule S
					WHERE DTASRID = @DTASRID
				)
			;
		END
	END TRY
	BEGIN CATCH
		IF (ISNULL(@ErrorMessage, '') = '')
		BEGIN
			SELECT
				@ErrorMessage = 'ERROR: ' +  ERROR_MESSAGE();
		END

		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_ScheduleRecur_Delete', @ErrorMessage, @@TRANCOUNT, @currentStep;
		RAISERROR (@ErrorMessage, 16, 1);
	END CATCH
END