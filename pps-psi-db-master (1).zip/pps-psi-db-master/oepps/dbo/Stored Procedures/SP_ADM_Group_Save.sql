﻿-- ============================================================================        
-- Author:  Chinnana Raja     
-- Modified by: 10/31/2019     
-- Create date: 10/23/2019
-- Modified date: 10/31/2019
-- Description: This stored procedure is to create new or update user group  into the table ADM_Group    
-- =============================================================================       

/*******************************************************************************
--Test case 1: INSERT
DECLARE @UserGroupXml VARCHAR(MAX) = ''
DECLARE @ADMGID int = 0
SET @UserGroupXml = '<AdmGroup>
  <Admgid>0</Admgid>
  <GroupName>MS\INGX_HSSCORP</GroupName>
  <GroupDescr>Description</GroupDescr>
  <PermissionBinaryNumber>33547233</PermissionBinaryNumber>
  <IsDefault>false</IsDefault>
  <Enabled>true</Enabled>
  <InsertedTs>2019-09-09T14:53:38.063Z</InsertedTs>
  <ModifiedTs>2019-10-22T20:47:31.83Z</ModifiedTs>
</AdmGroup>'

EXEC [dbo].[SP_ADM_Group_Save]  @UserGroupXml, @ADMGID OUTPUT
SELECT @ADMGID
*********************************************************************/

/*********************************************************************
--Test case 2: UPDATE
DECLARE @LayoutName VARCHAR(100) = 'Test'
DECLARE @UserGroupXml VARCHAR(MAX) = ''
DECLARE @ADMGID int = 0
SET @UserGroupXml = '<AdmGroup>
  <Admgid>3</Admgid>
  <GroupName>MS\INGX_HSSCORP</GroupName>
  <GroupDescr>Sch 4</GroupDescr>
  <PermissionBinaryNumber>4</PermissionBinaryNumber>
  <IsDefault>false</IsDefault>
  <Enabled>true</Enabled>
  <InsertedTs>2019-09-09T14:53:38.063Z</InsertedTs>
  <ModifiedTs>2019-10-22T20:47:31.83Z</ModifiedTs>
</AdmGroup>'

EXEC [dbo].[SP_ADM_Group_Save] @UserGroupXml, @ADMGID OUTPUT
SELECT @ADMGID
*********************************************************************/

CREATE PROCEDURE [dbo].[SP_ADM_Group_Save] @UserGroupXml varchar(max), @Admgid int = 0 OUTPUT

AS
BEGIN

    DECLARE @ID_LIST tvp_IdList
	DECLARE @currentStep varchar(100)
    BEGIN TRY
        DECLARE @errorMessage varchar(4000)
        DECLARE @groupName varchar(200)
		SET @currentStep = 'check valid parameter'
        -- valid param
        IF (RTRIM(ISNULL(@UserGroupXml, '')) = '')
        BEGIN
            SET @errorMessage = 'User Group data cannot be empty.'
            RAISERROR (@errorMessage, 16, 1)
        END

        -- parse the xml
		SET @currentStep = 'parse xml'
        DECLARE @iDoc AS int
        SET @iDoc = NULL

        EXEC sp_xml_preparedocument @iDoc OUTPUT,
                                    @UserGroupXml

        -- get user group data from xml
		SET @currentStep = 'Get user group data from xml'
        SELECT
            * INTO #tmpADM_Group
        FROM OPENXML(@iDoc, '/AdmGroup', 2)
        WITH
        (
        [Admgid] [int],
        [GroupName] [varchar](200),
        [GroupDescr] [varchar](200),
        [PermissionBinaryNumber] int,
        [IsDefault] bit,
        [Enabled] bit
        ) xmlData

        -- clean up xml
        EXEC sp_xml_removedocument @iDoc
        SET @iDoc = NULL

        --get ADMGID and GroupName
		SET @currentStep = 'Get info from table #tmpADM_Group'
        SELECT
            @Admgid = [Admgid],
            @groupName = [GroupName]
        FROM #tmpADM_Group

		-- If true, insert new user group
        IF (@Admgid = 0) 
        BEGIN
			SET @currentStep = 'Validate user group name.'
            IF EXISTS (SELECT
                    *
                FROM [dbo].[ADM_Group]
                WHERE [GroupName] = RTRIM(LTRIM(@groupName))
                AND [Enabled] = 1)
            BEGIN
                SET @errorMessage = 'A user group with this name already exists.'
                RAISERROR (@errorMessage, 16, 1)
            END

            IF (RTRIM(@groupName) = '')
            BEGIN
                SET @errorMessage = 'User group name cannot be empty.'
                RAISERROR (@errorMessage, 16, 1)
            END

			BEGIN TRAN ADM_Group_Insert_Tran
				SET @currentStep = 'Insert new user group in ADM_Group table.'
				INSERT INTO [dbo].[ADM_Group] ([GroupName]
				, [GroupDescr]
				, [PermissionBinaryNumber]
				, [IsDefault]
				, [Enabled]
				, [InsertedTS])
				OUTPUT INSERTED.ADMGID
				INTO @ID_LIST
					SELECT
						[GroupName],
						[GroupDescr],
						[PermissionBinaryNumber],
						[IsDefault],
						[Enabled],
						GETDATE()
					FROM #tmpADM_Group

			COMMIT TRAN ADM_Group_Insert_Tran
            SELECT
                @Admgid = id
            FROM @ID_LIST

        END
        ELSE
        BEGIN
			SET @currentStep = 'Checking if user group id exists.'
			IF NOT EXISTS (SELECT
                    *
                FROM [dbo].[ADM_Group]
                WHERE ADMGID = @Admgid
                AND [Enabled] = 1)
            BEGIN
                SET @errorMessage = 'User group does not exist.'
                RAISERROR (@errorMessage, 16, 1)
            END

            --update existing user group
			BEGIN TRAN ADM_Group_Update_Tran
			SET @currentStep = 'Update existing user group.'
            UPDATE g
            SET g.[GroupDescr] = t.[GroupDescr],
                g.[PermissionBinaryNumber] = t.[PermissionBinaryNumber],
                g.[IsDefault] = t.[IsDefault],
                g.[Enabled] = t.[Enabled],
                g.[ModifiedTs] = GETDATE()
            FROM [dbo].[ADM_Group] g
            INNER JOIN #tmpADM_Group t
                ON g.ADMGID = t.Admgid

			COMMIT TRAN ADM_Group_Update_Tran
        END
        IF NOT OBJECT_ID('tempdb..#tmpADM_Group') IS NULL
            DROP TABLE #tmpADM_Group
    END TRY
    BEGIN CATCH

        IF (ISNULL(@errorMessage, '') = '')
        BEGIN
            SELECT
                @errorMessage = ERROR_MESSAGE()
        END
        IF NOT OBJECT_ID('tempdb..#tmpADM_Group') IS NULL
            DROP TABLE #tmpADM_Group

		IF EXISTS (SELECT [name]
			FROM sys.dm_tran_active_transactions
			WHERE name = 'ADM_Group_Insert_Tran')
		BEGIN
			ROLLBACK TRAN ADM_Group_Insert_Tran
		END

		IF EXISTS (SELECT [name]
			FROM sys.dm_tran_active_transactions
			WHERE name = 'ADM_Group_Update_Tran')
		BEGIN
			ROLLBACK TRAN ADM_Group_Update_Tran
		END
		
		EXEC [sp_DTA_EventLog_Insert_SP] 'SP_ADM_Group_Save', @errorMessage, @@TRANCOUNT, @currentStep
        RAISERROR (@errorMessage, 16, 1)

    END CATCH

END
