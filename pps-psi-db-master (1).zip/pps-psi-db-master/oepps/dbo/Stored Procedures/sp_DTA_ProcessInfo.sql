﻿
-- ===========================================================================
-- Author:  	Alex Chern
-- Create date: 08/06/2018
-- Description:	This sp returns list of ProcessInfo with actual folder names
-- Modification: 03/02/2020 - Added new override ID Fields to Process Info - JK
-- Modification: 09/18/2020 - Added new contract fields (facility, npi, taxonomy, etc.,) to Process Info - JK
--============================================================================
/*****************************************************************************
--Test Case
--EXEC sp_DTA_ProcessInfo 
--***************************************************************************/


CREATE  PROCEDURE [dbo].[sp_DTA_ProcessInfo] @processInfoName varchar(50) = NULL, @numOfRecs int = 0
AS

IF @numOfRecs = 0	
	SELECT p.[DTAPID], 

			fu.ADMOFID,
			p.[ProcessInfoName], 

			CASE fu.FolderType WHEN 'Data' THEN su.[DataPath] + '\' + COALESCE(fu.[FolderName], '') 
								WHEN 'Watch' THEN su.[WatchFolder] + '\' + COALESCE(fu.[FolderName], '') 
								WHEN 'Optimizer' THEN su.[OptimizerPath] + '\' + COALESCE(fu.[FolderName], '') 
								ELSE COALESCE(su.[DataPath], su.[WatchFolder]) + '\' + COALESCE(fu.[FolderName], '') END AdmofidUserPath, 

			CASE fs.FolderType WHEN 'Data' THEN ss.[DataPath] + '\' + COALESCE(fs.[FolderName], '') 
								WHEN 'Watch' THEN ss.[WatchFolder] + '\' + COALESCE(fs.[FolderName], '') 
								WHEN 'Optimizer' THEN ss.[OptimizerPath] + '\' + COALESCE(fs.[FolderName], '') 
								ELSE COALESCE(ss.[DataPath], ss.[WatchFolder]) + '\' + COALESCE(fs.[FolderName], '') END AdmofidSystemPath, 
							
			CASE fr.FolderType WHEN 'Data' THEN sr.[DataPath] + '\' + COALESCE(fr.[FolderName], '') 
								WHEN 'Watch' THEN sr.[WatchFolder] + '\' + COALESCE(fr.[FolderName], '') 
								WHEN 'Optimizer' THEN sr.[OptimizerPath] + '\' + COALESCE(fr.[FolderName], '') 
								ELSE COALESCE(sr.[DataPath], sr.[WatchFolder]) + '\' + COALESCE(fr.[FolderName], '') END AdmofidRatePath, 

			CASE fo.FolderType WHEN 'Data' THEN so.[DataPath] + '\' + COALESCE(fo.[FolderName], '') 
								WHEN 'Watch' THEN so.[WatchFolder] + '\' + COALESCE(fo.[FolderName], '') 
								WHEN 'Optimizer' THEN so.[OptimizerPath] + '\' + COALESCE(fo.[FolderName], '') 
								ELSE COALESCE(so.[OptimizerPath], so.[WatchFolder]) + '\' + COALESCE(fo.[FolderName], '') END AdmofidOptimizer64Path, 
		 
				p.[Ecb.opcode1] AS EcbOpcode1,
				p.[Ecb.pattype] AS EcbPattype,
				p.[Ecb.code_class] AS EcbCodeClass,
				p.[Pcb1.accept_if] AS Pcb1AcceptIf,
				p.[Ecb.opcode3] AS EcbOpcode3,
				p.[Ecb.pyr_altlook_sw] AS EcbPyrAltlookSw,
				p.[Ecb.map_override_id] AS EcbMapOverrideId,
				p.[Ecb.hac_override_id] AS EcbHacOverrideId,
				p.[Ecb.ace_override_id] AS EcbAceOverrideId,
				p.[Ecb.apc_override_id] AS EcbApcOverrideId,
				p.[Pcb1.facility] AS Pcb1Facility,
			    p.[Pcb1.npi] AS Pcb1Npi,
			    p.[Pcb1.taxonomy] AS Pcb1Taxonomy,
			    p.[Pcb1.paysrc] AS Pcb1Paysrc,
			    p.[Pcb2.icd.hmo_risk] AS Pcb2IcdHmoRisk,
				p.IsDefault	
			
	FROM [dbo].[DTA_ProcessInfo] p WITH(NOLOCK) 
	INNER JOIN
	[dbo].[ADM_OEPPS_Folder] fu WITH(NOLOCK) 
	ON p.[ADMOFID_UserPath] = fu.[ADMOFID]
	INNER JOIN [dbo].[ADM_OEPPS_Server] su WITH(NOLOCK) 
	ON fu.[ADMOSID] = su.[ADMOSID]
	INNER JOIN [dbo].[ADM_OEPPS_Folder] fs WITH(NOLOCK) 
	ON p.[ADMOFID_SystemPath] = fs.[ADMOFID]
	INNER JOIN [dbo].[ADM_OEPPS_Server] ss WITH(NOLOCK) 
	ON fs.[ADMOSID] = ss.[ADMOSID] 
	INNER JOIN [dbo].[ADM_OEPPS_Folder] fr WITH(NOLOCK) 
	ON p.[ADMOFID_RatePath] = fr.[ADMOFID]
	INNER JOIN [dbo].[ADM_OEPPS_Server] sr WITH(NOLOCK) 
	ON fr.[ADMOSID] = sr.[ADMOSID]
	INNER JOIN [dbo].[ADM_OEPPS_Folder] fo WITH(NOLOCK) 
	ON p.[ADMOFID_Optimizer64Path] = fo.[ADMOFID] 
	INNER JOIN [dbo].[ADM_OEPPS_Server] so WITH(NOLOCK) 
	ON fo.[ADMOSID] = so.[ADMOSID]

	Order BY p.[ProcessInfoName]
ELSE
	SELECT TOP (@numOfRecs) p.[DTAPID], 

			fu.ADMOFID,
			p.[ProcessInfoName], 

			CASE fu.FolderType WHEN 'Data' THEN su.[DataPath] + '\' + COALESCE(fu.[FolderName], '') 
								WHEN 'Watch' THEN su.[WatchFolder] + '\' + COALESCE(fu.[FolderName], '') 
								WHEN 'Optimizer' THEN su.[OptimizerPath] + '\' + COALESCE(fu.[FolderName], '') 
								ELSE COALESCE(su.[DataPath], su.[WatchFolder]) + '\' + COALESCE(fu.[FolderName], '') END AdmofidUserPath, 

			CASE fs.FolderType WHEN 'Data' THEN ss.[DataPath] + '\' + COALESCE(fs.[FolderName], '') 
								WHEN 'Watch' THEN ss.[WatchFolder] + '\' + COALESCE(fs.[FolderName], '') 
								WHEN 'Optimizer' THEN ss.[OptimizerPath] + '\' + COALESCE(fs.[FolderName], '') 
								ELSE COALESCE(ss.[DataPath], ss.[WatchFolder]) + '\' + COALESCE(fs.[FolderName], '') END AdmofidSystemPath, 
							
			CASE fr.FolderType WHEN 'Data' THEN sr.[DataPath] + '\' + COALESCE(fr.[FolderName], '') 
								WHEN 'Watch' THEN sr.[WatchFolder] + '\' + COALESCE(fr.[FolderName], '') 
								WHEN 'Optimizer' THEN sr.[OptimizerPath] + '\' + COALESCE(fr.[FolderName], '') 
								ELSE COALESCE(sr.[DataPath], sr.[WatchFolder]) + '\' + COALESCE(fr.[FolderName], '') END AdmofidRatePath, 

			CASE fo.FolderType WHEN 'Data' THEN so.[DataPath] + '\' + COALESCE(fo.[FolderName], '') 
								WHEN 'Watch' THEN so.[WatchFolder] + '\' + COALESCE(fo.[FolderName], '') 
								WHEN 'Optimizer' THEN so.[OptimizerPath] + '\' + COALESCE(fo.[FolderName], '') 
								ELSE COALESCE(so.[OptimizerPath], so.[WatchFolder]) + '\' + COALESCE(fo.[FolderName], '') END AdmofidOptimizer64Path, 
		 
			p.[Ecb.opcode1] AS EcbOpcode1,
			p.[Ecb.pattype] AS EcbPattype,
			p.[Ecb.code_class] AS EcbCodeClass,
			p.[Pcb1.accept_if] AS Pcb1AcceptIf,
			p.[Ecb.opcode3] AS EcbOpcode3,
			p.[Ecb.pyr_altlook_sw] AS EcbPyrAltlookSw,
			p.[Ecb.map_override_id] AS EcbMapOverrideId,
			p.[Ecb.hac_override_id] AS EcbHacOverrideId,
			p.[Ecb.ace_override_id] AS EcbAceOverrideId,
			p.[Ecb.apc_override_id] AS EcbApcOverrideId,
			p.[Pcb1.facility] AS Pcb1Facility,
			p.[Pcb1.npi] AS Pcb1Npi,
			p.[Pcb1.taxonomy] AS Pcb1Taxonomy,
			p.[Pcb1.paysrc] AS Pcb1Paysrc,
			p.[Pcb2.icd.hmo_risk] AS Pcb2IcdHmoRisk,
			p.IsDefault	
	FROM [dbo].[DTA_ProcessInfo] p WITH(NOLOCK) 
		INNER JOIN
		[dbo].[ADM_OEPPS_Folder] fu WITH(NOLOCK) 
		ON p.[ADMOFID_UserPath] = fu.[ADMOFID]
		INNER JOIN [dbo].[ADM_OEPPS_Server] su WITH(NOLOCK) 
		ON fu.[ADMOSID] = su.[ADMOSID]
		INNER JOIN [dbo].[ADM_OEPPS_Folder] fs WITH(NOLOCK) 
		ON p.[ADMOFID_SystemPath] = fs.[ADMOFID]
		INNER JOIN [dbo].[ADM_OEPPS_Server] ss WITH(NOLOCK) 
		ON fs.[ADMOSID] = ss.[ADMOSID] 
		INNER JOIN [dbo].[ADM_OEPPS_Folder] fr WITH(NOLOCK) 
		ON p.[ADMOFID_RatePath] = fr.[ADMOFID]
		INNER JOIN [dbo].[ADM_OEPPS_Server] sr WITH(NOLOCK) 
		ON fr.[ADMOSID] = sr.[ADMOSID]
		INNER JOIN [dbo].[ADM_OEPPS_Folder] fo WITH(NOLOCK) 
		ON p.[ADMOFID_Optimizer64Path] = fo.[ADMOFID] 
		INNER JOIN [dbo].[ADM_OEPPS_Server] so WITH(NOLOCK) 
		ON fo.[ADMOSID] = so.[ADMOSID]
	WHERE LTRIM(RTRIM(ISNULL(@processInfoName, ''))) = '' 
		OR '%' + LTRIM(RTRIM(ISNULL(@processInfoName, ''))) + '%' LIKE p.[ProcessInfoName]  
	Order BY p.[ProcessInfoName]





