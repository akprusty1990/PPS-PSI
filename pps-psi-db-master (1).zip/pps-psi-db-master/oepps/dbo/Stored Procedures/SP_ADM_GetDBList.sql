﻿-- =============================================
-- Author:		Luhai Huang
-- Create date: 10/10/2019
-- Description:	Get database list
-- =============================================
/*******************************************************************************
EXEC [dbo].[SP_ADM_GetDBList] 1, 1
*********************************************************************/
CREATE PROCEDURE [dbo].[SP_ADM_GetDBList] @AppID INT, @AcctID INT, @sAppVer VARCHAR(50) = NULL
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @nColNum	INT;
	DECLARE @nColMax	INT;
	DECLARE @sDbName	VARCHAR(64);
	DECLARE @sSql		VARCHAR(1024);
	DECLARE @sUpAppVer	VARCHAR(256);
	DECLARE @tbl TABLE
	(
		DbName		VARCHAR(32),
		DbConn		VARCHAR(256),
		GroupNames	VARCHAR(256),
		ColNum		INT IDENTITY(1, 1)
	);
	DECLARE @tblAdmGroup TABLE
	(
		GroupNames	VARCHAR(256)
	);
	INSERT INTO @tbl VALUES('oepps', '', NULL);
	INSERT INTO @tbl
	SELECT [name], '', NULL FROM sys.databases WHERE [name] LIKE 'oepps[_]%';
	SELECT @nColNum = MIN(ColNum), @nColMax = MAX(ColNum) FROM @tbl;
	WHILE(@nColNum <= @nColMax)
	BEGIN
		BEGIN TRY
			DELETE FROM @tblAdmGroup;
			SELECT @sDbName = DbName FROM @tbl WHERE ColNum = @nColNum;
			SET @sSql = 'SELECT [name] FROM ' + @sDbName + '.sys.tables WHERE object_id = OBJECT_ID(N''' + @sDbName + '.dbo.ADM_Group'')  AND type in (N''U'');';
			INSERT INTO @tblAdmGroup
				EXEC(@sSql);	
			IF EXISTS (SELECT * FROM @tblAdmGroup)
			BEGIN	
				SET @sSql = 'SELECT (SELECT RTRIM(LTRIM(GroupName)) + '','' FROM ' + @sDbName + '.dbo.ADM_Group FOR XML PATH('''')) AS Ids;';		
				DELETE FROM @tblAdmGroup;
				INSERT INTO @tblAdmGroup			
				EXEC(@sSql);
				UPDATE @tbl SET GroupNames = (SELECT GroupNames FROM @tblAdmGroup) WHERE ColNum = @nColNum;
			END				
			IF (@sAppVer IS NOT NULL)
			BEGIN
				SET @sUpAppVer = 'UPDATE [' + 	@sDbName + '].[dbo].[ADM_OEPPS_SERVER] SET AppVersion = ''' + @sAppVer + ''', ModifiedTS = GETDATE();';
				EXEC(@sUpAppVer);
			END
		END TRY
		BEGIN CATCH
			--some database may not be accessible
			PRINT "Error: " + @sDbName;
		END CATCH
		SET @nColNum = @nColNum + 1;
	END
	SELECT * FROM @tbl WHERE GroupNames IS NOT NULL;
END

GO


