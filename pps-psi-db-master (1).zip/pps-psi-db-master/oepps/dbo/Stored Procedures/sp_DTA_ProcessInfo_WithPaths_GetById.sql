﻿
-- ===========================================================================
-- Author:        Joe Lango
-- Create date:	  07/27/2020
-- Description:   get ProcessInfo row, with actual Folder Paths, for the given DTAPID
-- Modified date: 10/02/2020
-- Modifications:
-- 10/02/2020 - Included new process info fields(Facility, NPI, etc), that are added to DTA_ProcessInfo table - JK.
-- ===========================================================================
/*****************************************************************************
--Test Case:
--EXEC sp_DTA_ProcessInfo_WithPaths_GetById 1
*****************************************************************************/
CREATE PROCEDURE dbo.sp_DTA_ProcessInfo_WithPaths_GetById (
	@dtapid int
)
AS

BEGIN
	--get path info, necessary to convert some processinfo fields from id to real path
	DECLARE @tblFolderPath TABLE (
		ADMOFID int NOT NULL PRIMARY KEY CLUSTERED
		,FolderType varchar(50) NOT NULL
		,FolderPath varchar(256) NOT NULL
	);

	INSERT INTO @tblFolderPath
	SELECT f.ADMOFID, 
		f.FolderType,
		CASE f.FolderType 
			WHEN 'Data' THEN s.[DataPath] + '\' + COALESCE(f.[FolderName], '') 
			WHEN 'Watch' THEN s.[WatchFolder] + '\' + COALESCE(f.[FolderName], '') 
			WHEN 'Optimizer' THEN s.[OptimizerPath] + '\' + COALESCE(f.[FolderName], '') 
		END FolderPath
	FROM [ADM_OEPPS_Folder] f WITH(NOLOCK) 
		INNER JOIN [ADM_OEPPS_Server] s WITH(NOLOCK) 
			ON f.ADMOSID = s.ADMOSID 
	;

	SELECT
		P.DTAPID,
		P.ProcessInfoName,
		OP.FolderPath AdmofidOptimizer64Path,
		RP.FolderPath AdmofidRatePath,
		SP.FolderPath AdmofidSystemPath,
		UP.FolderPath AdmofidUserPath,
		P.[Ecb.opcode1] AS EcbOpcode1,
		P.[Ecb.pattype] AS EcbPattype,
		P.[Ecb.code_class] AS EcbCodeClass,
		P.[Pcb1.accept_if] AS Pcb1AcceptIf,
		P.[Ecb.opcode3] AS EcbOpcode3,
		P.[Ecb.pyr_altlook_sw] AS EcbPyrAltlookSw,
		P.[Ecb.map_override_id] AS EcbMapOverrideId,
		P.[Ecb.hac_override_id] AS EcbHacOverrideId,
		P.[Ecb.ace_override_id] AS EcbAceOverrideId,
		P.[Ecb.apc_override_id] AS EcbApcOverrideId,
		P.[Pcb1.facility] AS Pcb1Facility,
		P.[Pcb1.npi] AS Pcb1Npi,
		P.[Pcb1.taxonomy] AS Pcb1Taxonomy,
		P.[Pcb1.paysrc] AS Pcb1Paysrc,
		IIF(P.[Pcb2.icd.hmo_risk] = '0', '', P.[Pcb2.icd.hmo_risk]) AS Pcb2IcdHmoRisk,
		P.IsDefault
	FROM dbo.DTA_ProcessInfo P WITH(NOLOCK)
		LEFT JOIN @tblFolderPath OP 
			ON P.ADMOFID_Optimizer64Path = OP.ADMOFID
		LEFT JOIN @tblFolderPath RP 
			ON P.ADMOFID_RatePath = RP.ADMOFID
		LEFT JOIN @tblFolderPath SP 
			ON P.ADMOFID_SystemPath = SP.ADMOFID
		LEFT JOIN @tblFolderPath UP 
			ON P.ADMOFID_UserPath = UP.ADMOFID
	WHERE DTAPID = @dtapid
	;
END
