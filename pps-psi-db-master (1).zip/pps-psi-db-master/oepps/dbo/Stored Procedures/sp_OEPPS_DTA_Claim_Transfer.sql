﻿--=============================================
--Author:    		David Pinho
--Create date:		09/17/2018
--Modified date:	04/10/2019
--Modified date:	02/26/2020
--Description:  Transfer Data to DTA_Claim Tables using TVP
--1. Insert Data to DTA_Claim Table 
--2. Insert Data to DTA_ClaimData Table 
--3. Call sp to update DTA_Execution with complete status
-- Modification: 07/01/2019 - Include encryption part - Callie
-- Modification: 02/26/2020 - Update start time passed from Oepps - Luhai Huang
-- Modification: 03/27/2020 - Use @NumOfClaimStatusCodes to tell [dbo].[sp_OEPPS_Execution_Status_Update] the caller is [dbo].[sp_OEPPS_DTA_Claim_Transfer] - Luhai Huang
-- Modification: 04/06/2020 - Remove the changed made on 03/27/2020 --  Luhai Huang
-- Modification: 04/07/2020 - add @ExportNumClaims to indicate the exported number of claims -- Luhai Huang
-- Modification: 06/15/2020 - Compute and update value for the GroupID column while inserting/updating the records on the DTA_Claim table
-- Modification: 07/14/2020 - Remove Dependencies/References to DTAOCID and IsLatest
-- Modification: 10/19/2020 - Adding a transaction for the data insertion. Adding DTAEID check and Status Check before the transection and before the commit -- Elliot Zhu
-- Modification: 10/21/2020 - Added logic for the new column 'partitiondate' for the table DTA_Claim during insert
-- Modification: 11/09/2020 - Luhai Huang let commit trans include calling [dbo].[sp_OEPPS_Execution_Status_Update] so that it won't have a partial success
--=============================================

--**************************************************************************
--Test Case
--DECLARE @tvpClaim AS dbo.TVP_CLAIM; DECLARE @tvpClaimData AS TVP_CLAIMDATA; 
--DECLARE @returnCode int;
--DECLARE @DTAEID int = '1224';
--INSERT INTO @tvpClaim ([claimnum], [dtaeid], [pcb1.npi], [pcb1.taxonomy], [pcb1.paysrc], [ecb.prcr_type], [pcb1.facility]) 
--SELECT TOP 10 [claimnum], [dtaeid], [pcb1.npi], [pcb1.taxonomy], [pcb1.paysrc], [ecb.prcr_type], [pcb1.facility] FROM dbo.dta_claim cs WHERE DTAEID = @DTAEID
--INSERT INTO @tvpClaimData ([cblockname], [claimdata], [claiminput], [claimoutput], [insertedts], [claimnum], [DTAEID]) 
--SELECT TOP 10 [cblockname], [claimdata], [claiminput], [claimoutput], [insertedts], [claimnum], [DTAEID] FROM dbo.dta_claimdata cs WHERE DTAEID = @DTAEID
--EXEC @returnCode = [dbo].[sp_OEPPS_DTA_Claim_Transfer] 0, 1, @DTAEID, @tvpClaim, @tvpClaimData, 0, 5, 869591828129891241
--PRINT(@returnCode)

--**************************************************************************

CREATE PROCEDURE [dbo].[sp_OEPPS_DTA_Claim_Transfer] (@AppID INT, @AcctID INT, @DTAEID INT,
	@tvpClaim AS dbo.tvp_Claim READONLY,
	@tvpClaimData AS dbo.tvp_ClaimData READONLY,
	@NumBatches INT,
	@ExportNumClaims INT,
	@ExecutionStartTime BIGINT)
AS
BEGIN TRY
	SET NOCOUNT ON;
	OPEN SYMMETRIC KEY SQLSymmetricKey256 
	DECRYPTION BY CERTIFICATE PSICERTIFICATE;

	-- Update all affected records with the same time
	DECLARE @Time datetime2(0) = GETUTCDATE()
	DECLARE @InsertedClaims TABLE (DTACID BIGINT NOT NULL, ClaimNum BIGINT NULL)
	DECLARE @DTAPID INT = (SELECT p.DTAPID FROM dbo.DTA_Execution e INNER JOIN dbo.DTA_Schedule s ON s.DTASID = e.DTASID INNER JOIN dbo.DTA_WorkflowTask wft ON wft.DTAWFTID = s.DTAWFTID INNER JOIN dbo.DTA_Task t ON t.DTATID = wft.DTATID INNER JOIN dbo.DTA_ProcessInfo p ON p.DTAPID = t.DTAPID WHERE e.DTAEID = @DTAEID)
	DECLARE @WorkflowStatus varchar(20)
	DECLARE @ErrorMessage varchar(4000)

	

	-- Return 704 if 1. Requested DTAEID does not exist 2.  Workflow status is either 'Reverting' or 'Reverting Incomplete'
	SELECT TOP(1) @WorkflowStatus = w.Status
		FROM [dbo].[DTA_Execution] e
	    INNER JOIN dbo.DTA_Schedule s WITH (NOLOCK)
		ON e.DTASID = s.DTASID
		INNER JOIN dbo.DTA_WorkflowTask wt WITH (NOLOCK)
	    ON s.DTAWFTID = wt.DTAWFTID
		INNER JOIN dbo.DTA_Workflow w WITH(NOLOCK)
		ON w.DTAWFID = wt.DTAWFID
		WHERE e.DTAEID = @DTAEID
	IF( NOT EXISTs (SELECT TOP(1) DTAEID FROM [dbo].[DTA_Execution] WITH (NOLOCK) WHERE DTAEID = @DTAEID) OR
	    @WorkflowStatus = 'Reverting' OR @WorkflowStatus = 'Reverting Incomplete') 
	BEGIN
		RETURN 704
	END
	
	-- Start the transaction with default isolation level
	BEGIN TRAN DTA_Claim_Oepps_Transfer_Tran

  -- Insert Claims into DTA_Claim
  INSERT INTO [dbo].[DTA_Claim] (
  [DTAPCID],
  [ClaimNum],
  [InsertedTS],
  [Source],
  [DTAEID],
  [Pcb1.med_num],
  [Oepps.member_id],
  [Pcb1.ctr_num],
  [Pcb1.hplan_id],
  [Pcb1.npi],
  [Pcb1.taxonomy],
  [Pcb1.paysrc],
  [Pcb1.from_date],
  [Pcb1.thru_date],
  [Pcb1.birth_date],
  [Pcb1.admit_date],
  [Ecb.prcr_type],
  [Ecb.func_rtn_code],
  [Pcb1.facility],
  [Oepps.claim_id],
  [Oepps.fname],
  [Oepps.mname],
  [Oepps.lname],
  [StatusMsg],
  [StatusCode],	
  [Oob1.opt_rtn_code],
  [HasEdits], 
  [FileName],
  [ModifiedTS],  
  DTAPID,
  GroupID,
  PartitionDate)	
  OUTPUT Inserted.DTACID, Inserted.ClaimNum INTO @InsertedClaims
    SELECT
      NULL AS DTAPCID,
      cs.[ClaimNum],
      @Time AS InsertedTS,
      'OEPPS' AS Source,
      cs.[DTAEID],
      EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, REPLACE(cs.["Input":~"PatientClaim":~"med_num":], '"', ''))),
	  EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, REPLACE(cs.["Oepps":~"member_id":], '"', ''))),
	  EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, REPLACE(cs.["Input":~"PatientClaim":~"ctr_num":], '"', ''))), 
	  EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, REPLACE(cs.["Input":~"PatientClaim":~"hplan_id":], '"', ''))),      
	  cs.[Pcb1.npi],
      cs.[Pcb1.taxonomy],
	  cs.[Pcb1.paysrc],
      EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, NULLIF(ISNULL(CONVERT(DATE, SUBSTRING(cs.["Input":~"PatientClaim":~"from_date":], 2, 4) + '-' + SUBSTRING(cs.["Input":~"PatientClaim":~"from_date":], 6, 2) + '-' + SUBSTRING(cs.["Input":~"PatientClaim":~"from_date":], 8, 2)), ''), ''))),--save as NULL instead of 1900-01-01
	  EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, NULLIF(ISNULL(CONVERT(DATE, SUBSTRING(cs.["Input":~"PatientClaim":~"thru_date":], 2, 4) + '-' + SUBSTRING(cs.["Input":~"PatientClaim":~"thru_date":], 6, 2) + '-' + SUBSTRING(cs.["Input":~"PatientClaim":~"thru_date":], 8, 2)), ''), ''))),--save as NULL instead of 1900-01-01
	  EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, NULLIF(ISNULL(CONVERT(DATE, SUBSTRING(cs.["Input":~"PatientClaim":~"birth_date":], 2, 4) + '-' + SUBSTRING(cs.["Input":~"PatientClaim":~"birth_date":], 6, 2) + '-' + SUBSTRING(cs.["Input":~"PatientClaim":~"birth_date":], 8, 2)), ''), ''))),--save as NULL instead of 1900-01-01
	  EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, NULLIF(ISNULL(CONVERT(DATE, SUBSTRING(cs.["Input":~"PatientClaim":~"admit_date":], 2, 4) + '-' + SUBSTRING(cs.["Input":~"PatientClaim":~"admit_date":], 6, 2) + '-' + SUBSTRING(cs.["Input":~"PatientClaim":~"admit_date":], 8, 2)), ''), ''))),--save as NULL instead of 1900-01-01
      cs.[Ecb.prcr_type],
	  cs.[Ecb.func_rtn_code],
      cs.[Pcb1.facility],
      EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, REPLACE(cs.["Oepps":~"claim_id":], '"', ''))),
	  EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, REPLACE(cs.["Oepps":~"fname":], '"', ''))),
	  EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, REPLACE(cs.["Oepps":~"mname":], '"', ''))),
	  EncryptByKey(Key_GUID('SQLSymmetricKey256'),  CONVERT(varbinary, REPLACE(cs.["Oepps":~"lname":], '"', ''))),
	  cs.[StatusMsg],
	  cs.[StatusCode],
	  cs.[Oob1.opt_rtn_code],
	  cs.[HasEdits],
	  cs.[FileName],
	  @Time AS ModifiedTS,  
	  @DTAPID,
	  (SELECT ISNULL([output],'') FROM [dbo].[udf_ForGroupID](REPLACE(cs.["Oepps":~"claim_id":], '"', ''))) AS GroupID,
	  --Convert 'Fromdate' to first day of the month. If 'Fromdate' has NULL or mindate, the value is set to '1900-01-01'
	  CONVERT(date, ISNULL(NULLIF(SUBSTRING(cs.["Input":~"PatientClaim":~"from_date":], 2, 4) + '-' + SUBSTRING(cs.["Input":~"PatientClaim":~"from_date":], 6, 2) + '-01','0001-01-01'),'')) AS [PartitionDate]
    FROM @tvpClaim cs
	
	-- Insert Claims into [dbo].[DTA_ClaimData] 
	INSERT INTO [dbo].[DTA_ClaimData] (
	[DTACID],
	[CBlockName],
	[ClaimData],
	[ClaimInput],
	[ClaimOutput],
	[InsertedTS],
	[ClaimNum],
	[DTAEID])
	SELECT
		c.[DTACID],
		tcd.[CBlockName],
		tcd.[ClaimData],
		tcd.[ClaimInput],
		tcd.[ClaimOutput],
		@Time,
		tcd.[ClaimNum],
		@DTAEID
	FROM @tvpClaimData tcd
	INNER JOIN @InsertedClaims c
		ON tcd.[ClaimNum] = c.ClaimNum
	
	-- Return 704 and Rollback if 1. Requested DTAEID does not exist 2.  Workflow status is either 'Reverting' or 'Reverting Incomplete'
	SELECT TOP(1) @WorkflowStatus = w.Status
		FROM [dbo].[DTA_Execution] e
	    INNER JOIN dbo.DTA_Schedule s WITH (NOLOCK)
		ON e.DTASID = s.DTASID
		INNER JOIN dbo.DTA_WorkflowTask wt WITH (NOLOCK)
	    ON s.DTAWFTID = wt.DTAWFTID
		INNER JOIN dbo.DTA_Workflow w WITH(NOLOCK)
		ON w.DTAWFID = wt.DTAWFID
		WHERE e.DTAEID = @DTAEID
	IF( NOT EXISTs (SELECT TOP(1) DTAEID FROM [dbo].[DTA_Execution] WITH (NOLOCK) WHERE DTAEID = @DTAEID) OR
	    @WorkflowStatus = 'Reverting' OR @WorkflowStatus = 'Reverting Incomplete') 
	BEGIN
		ROLLBACK TRAN DTA_Claim_Oepps_Transfer_Tran
		RETURN 704
	END
	
	-- Update DTA_Execution with complete status
	DECLARE @NumClaims INT = (SELECT COUNT(1) FROM @tvpClaim)
	DECLARE @NumEdits INT = (SELECT COUNT(1) FROM @tvpClaim WHERE HasEdits = 1);
	DECLARE @NumReturnCodes INT = (SELECT COUNT(1) FROM @tvpClaim WHERE [Oob1.opt_rtn_code] IS NOT NULL);
	--For export, the exported claim number will be passed.
	IF(@ExportNumClaims > 0)
		SET @NumClaims = @ExportNumClaims;
	EXEC [dbo].[sp_OEPPS_Execution_Status_Update] 
		@AppID = @AppID, 
		@AcctID = @AcctID,
		@DTAEID = @DTAEID, 
		@NumClaims = @NumClaims, 
		@NumBatches = @NumBatches, 
		@NumEdits = @NumEdits, 
		@NumReturnCodes = @NumReturnCodes,
		@NumOfClaimStatusCodes = 0,
		@ExecutionStartTime = @ExecutionStartTime;
		
	COMMIT TRAN DTA_Claim_Oepps_Transfer_Tran
END TRY
BEGIN CATCH
	SET @ErrorMessage = ERROR_MESSAGE();
	--Rollback if transaction still exist/didnt commit
	IF EXISTS (SELECT *
        FROM sys.dm_tran_active_transactions
        WHERE name = 'DTA_Claim_Oepps_Transfer_Tran')
	BEGIN
		ROLLBACK TRAN DTA_Claim_Oepps_Transfer_Tran
	END
	--Throw the original error
	RAISERROR (@ErrorMessage, 16, 1)
END CATCH




