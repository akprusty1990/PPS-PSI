﻿


-- ===========================================================================
-- Author:  	Jaya Krishna
-- Create date: 10/08/2019
-- Modified date: 10/25/2019
-- Description:	This sp returns list of ProcessInfo based on @processInfoName
-- 10/25/2019: Added OR condition to include exact match for process info name. (specifically, for names with special characters)
-- Modification: 03/02/2020 - Added new override ID Fields to Process Info - JK
-- Modification: 09/18/2020 - Added new contract fields (facility, npi, taxonomy, etc.,) to Process Info - JK
--============================================================================
/*****************************************************************************
--Test Case
--EXEC sp_DTA_ProcessInfo_Get 'TEST'
--***************************************************************************/


CREATE  PROCEDURE [dbo].[sp_DTA_ProcessInfo_Get] @processInfoName varchar(50) = NULL
AS

BEGIN
	SELECT TOP 10 p.[DTAPID], 
			p.[ProcessInfoName], 
			ISNULL(p.[ADMOFID_RatePath],0) as [ADMOFID_RatePath], 
			ISNULL(p.[ADMOFID_UserPath],0) as [ADMOFID_UserPath],
			ISNULL(p.[ADMOFID_SystemPath],0) as [ADMOFID_SystemPath],
			ISNULL(p.[ADMOFID_Optimizer64Path],0) as [ADMOFID_Optimizer64Path],
			p.[Ecb.opcode1],
			p.[Ecb.pattype],
			p.[Ecb.code_class],
			p.[Pcb1.accept_if],
			p.[Ecb.opcode3],
			p.[Ecb.pyr_altlook_sw],
			p.[Ecb.map_override_id],
			p.[Ecb.hac_override_id],
			p.[Ecb.ace_override_id],
			p.[Ecb.apc_override_id],
			p.[Pcb1.facility],
			p.[Pcb1.npi],
			p.[Pcb1.taxonomy],
			p.[Pcb1.paysrc],
			p.[Pcb2.icd.hmo_risk],
			p.[IsDefault],
			p.[InsertedTS],
			p.[ModifiedTS]
	FROM [dbo].[DTA_ProcessInfo] p WITH(NOLOCK) 
	WHERE RTRIM(LTRIM(ISNULL(@processInfoName, ''))) = '' 
		OR p.[ProcessInfoName] LIKE '%' + RTRIM(LTRIM(@processInfoName)) + '%'
		OR p.[ProcessInfoName] = RTRIM(LTRIM(@processInfoName))
	Order By p.[ModifiedTS] DESC, p.[InsertedTS] DESC, p.[ProcessInfoName]
END