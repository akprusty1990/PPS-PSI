﻿-- ===========================================================================
-- Author:  	Jaya Krishna
-- Create date: 09/29/2020
-- Description: This sp deletes Claim form from DTA_Claim & DTA_ClaimData by DTACID.
-- Returns (as output param): latest dtacid with the same group ID for claims.
--============================================================================
/*****************************************************************************
--Test Case
--DECLARE @result int;
--EXEC sp_DTA_Claim_DeleteByDTACID 20, @result out;
--PRINT(@result);
--***************************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_Claim_DeleteByDTACID]
	@DTACID int,
	@latestDtacid int output
AS
BEGIN TRY
	DECLARE @ErrorMessage varchar(4000)
	DECLARE @currentStep varchar(100)
	SET @latestDtacid = 0;

	--Validate whether the claim exists in db.
	SET @currentStep = 'Validate whether the claim exists in db.'
	IF(NOT EXISTS(
		SELECT *
		FROM dbo.DTA_Claim WITH (NOLOCK)
		WHERE DTACID = @DTACID))
	BEGIN
		SET @ErrorMessage = 'ERROR: This claim has already been deleted.'
		RAISERROR (@ErrorMessage, 16, 1)
	END

	CREATE TABLE #tempClaimHistory (
        DTACID bigint NOT NULL,
		[Task Name] varchar(100) NULL,
		[Modified Time] datetime NULL
    );

	SET @currentStep = 'Get claim history for current dtacid';
	INSERT INTO #tempClaimHistory
	EXEC [sp_DTA_Claim_History_Get] @DTACID;

	BEGIN TRAN DTA_Claim_DeleteByDTACID_Tran
		SET @currentStep = 'Delete claim record.';
		DELETE dbo.DTA_Claim
		WHERE DTACID = @DTACID;

		DELETE dbo.DTA_ClaimData
		WHERE DTACID = @DTACID;

		DELETE #tempClaimHistory
		WHERE DTACID = @DTACID;

		SELECT TOP(1) @latestDtacid = ISNULL(t.DTACID, 0)
		FROM #tempClaimHistory t
		ORDER BY t.[Modified Time] DESC, t.[DTACID] DESC;

		DROP TABLE #tempClaimHistory;
	COMMIT TRAN DTA_Claim_DeleteByDTACID_Tran

END TRY
BEGIN CATCH
	SET @ErrorMessage = ERROR_MESSAGE();
	IF EXISTS(
		SELECT *
        FROM sys.dm_tran_active_transactions
        WHERE name = 'DTA_Claim_DeleteByDTACID_Tran')
    BEGIN
		ROLLBACK TRAN DTA_Claim_DeleteByDTACID_Tran
    END
	EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_Claim_DeleteByDTACID', @ErrorMessage, @@TRANCOUNT, @currentStep
	RAISERROR (@ErrorMessage, 16, 1)
END CATCH
