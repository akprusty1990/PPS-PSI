﻿-- ==============================================================================
-- Author:        Callie Ju
-- Create date:   05/27/2020
-- Description:	  Get GroupBox from TML table to get group sections
-- ==============================================================================
/********************************************************************************
--Test Case:
--DECLARE @Ids dbo.TVP_IDLIST;
  INSERT @Ids VALUES (1)
  EXEC [dbo].[sp_TML_ClaimVariable_GroupBox_Get] @Ids
*********************************************************************************/
CREATE PROCEDURE [dbo].[sp_TML_ClaimVariable_GroupBox_Get] @idList dbo.TVP_IDLIST READONLY
AS
BEGIN

	SET NOCOUNT ON;

	SELECT *
	FROM [TML_ClaimVariable] AS [t] WITH (NOLOCK)
	WHERE [t].[LUTCID] IS NOT NULL
	AND ([t].[LUTCID] IN (SELECT
						 Id
					     FROM @idList)
	AND [t].[FieldType] = 'GroupBox')
	ORDER BY [t].[DisplayOrder]
END