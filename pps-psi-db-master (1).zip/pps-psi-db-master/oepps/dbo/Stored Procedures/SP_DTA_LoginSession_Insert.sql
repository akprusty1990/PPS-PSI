﻿-- =============================================
-- Author: Chinnana Raja
-- Create date: 10/08/2019
-- Description:  This stored procedure is to insert login info into table DTA_LoginSession 

-- ============================================================================
/*
DECLARE @xmlData VARCHAR(MAX)
SET @xmlData=N'<LoginData>
  <LoginSession>
    <Groups>
      <group>MS\PEGA-ASOT-PROD</group>
      <group>MS\Domain Users</group>
      <group>MS\Domain Users</group>
      <group>MS\Domain Users</group>
      <group>MS\Domain Users</group>
      <group>LHTU0CND7349KG9\HelpLibraryUpdaters</group>
      <group>BUILTIN\Administrators</group>
      <group>BUILTIN\Users</group>
      <group>BUILTIN\Performance Log Users</group>
      <group>BUILTIN\Distributed COM Users</group>
      <group>NT AUTHORITY\INTERACTIVE</group>
      <group>NT AUTHORITY\This Organization Certificate</group>
    </Groups>
  </LoginSession>
</LoginData>'
exec [sp_DTA_LoginSession_Insert] 'MS\cchinnan', 0, @xmlData
********************************************************************************/
CREATE PROCEDURE [dbo].[SP_DTA_LoginSession_Insert] @LoginUser varchar(50), @HasError bit, @LoginData varchar(max)
AS
BEGIN
    BEGIN TRY
        -- SET NOCOUNT ON added to prevent extra result sets from
        SET NOCOUNT ON;
        DECLARE @errorMessage varchar(4000)
		DECLARE @currentStep varchar(100)
        BEGIN TRAN LoginSession_Insert_Tran
			SET @currentStep = 'Delete existing records for current user.'
            -- Need to delete all records for the same LoginUser before attempting to insert
            IF EXISTS (SELECT TOP 1
                    *
                FROM [dbo].[DTA_LoginSession]
                WHERE [LoginUser] = @LoginUser)
            BEGIN
                DELETE FROM [dbo].[DTA_LoginSession]
                WHERE [LoginUser] = @LoginUser
            END

			SET @currentStep = 'Insert login info into DTA_LoginSession'
            INSERT INTO DTA_LoginSession ([LoginUser]
            , [LoginData]
            , [HasError]
            , [LoginTS])
            VALUES (@LoginUser, @LoginData, @HasError, GETDATE())

        COMMIT TRAN LoginSession_Insert_Tran
		EXEC sp_DTA_EventLog_Insert_All @LoginUser, 1, 2, 3, 'SP_DTA_LoginSession_Insert', 'User logged in', ''
    END TRY
    BEGIN CATCH
        SELECT
            @errorMessage = ERROR_MESSAGE()
        IF EXISTS (SELECT
                [name]
            FROM sys.dm_tran_active_transactions
            WHERE name = 'LoginSession_Insert_Tran')
        BEGIN
            ROLLBACK TRAN LoginSession_Insert_Tran
        END

		EXEC [sp_DTA_EventLog_Insert_SP] 'SP_DTA_LoginSession_Insert', @errorMessage, @@TRANCOUNT, @currentStep
        RAISERROR (@errorMessage, 16, 1)
    END CATCH
END