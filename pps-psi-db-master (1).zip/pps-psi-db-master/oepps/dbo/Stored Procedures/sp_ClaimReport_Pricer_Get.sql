﻿-- =========================================================================
-- Author:          Callie Ju
-- Create date:     08/19/2020
-- Description:     
-- return totals for each pricer type based on DTAEID and DTACFID
-- call sp_ClaimSearchDynamic_Get with parameters
-- ==========================================================================
/****************************************************************************
--Test Case:
--exec [dbo].[sp_ClaimReport_Pricer_Get] @DTACFID=4450
*****************************************************************************/
CREATE PROCEDURE [dbo].[sp_ClaimReport_Pricer_Get]  @DTAEID int = 0, @DTACFID INT = 0
AS
BEGIN
       -- SET NOCOUNT ON added to prevent extra result sets from
       -- interfering with SELECT statements.
       SET NOCOUNT ON;

       CREATE TABLE #tempPricer
       (
             [DTACID] BIGINT NOT NULL,
			 [Ecb.prcr_type] VARCHAR(2) NULL,
			 [Oob1.opt_rtn_code] VARCHAR(2) NULL
       )
      
	   DECLARE @dynamicSQL varchar(max)='';
       EXEC sp_ClaimSearchDynamic_Get @DTAEID=@DTAEID,@DTACFID = @DTACFID, @IsReport =1, @DynamicSQL = @dynamicSQL OUTPUT 
	 
	   IF(@dynamicSQL <> '')
	   BEGIN
		   INSERT INTO #tempPricer
		   EXEC (@dynamicSQL) 
	   END

       SELECT
             PricerDetail.*,
			 lc.[LongName] AS [PricerType]
       FROM [dbo].[LUT_Claim] lc WITH(NOLOCK) 
	   INNER JOIN (
             SELECT MAX(cd.[DTACID]) AS PricerId,
					COUNT(cd.[DTACID]) AS [GroupIDCount],
                    ISNULL(CONVERT(numeric(15, 2), SUM(cd.[TotalCharge])), 0.00) AS TotalCharge,
                    ISNULL(CONVERT(numeric(15, 2), SUM(cd.[InpatientOutlierPay])), 0.00) + ISNULL(CONVERT(numeric(15, 2), SUM(cd.[OutpatientOutlierPay])), 0.00) + ISNULL(CONVERT(numeric(15, 2), SUM(cd.[ApgOutlierPay])), 0.00)+ ISNULL(CONVERT(numeric(15, 2), SUM(cd.[IrfOutlierPay])), 0.00) AS OutlierPay,
                    ISNULL(CONVERT(numeric(15, 2), SUM(cd.[InpatientTotalReimb])), 0.00) + ISNULL(CONVERT(numeric(15, 2), SUM(cd.[OutpatientTotalReimb])), 0.00) + ISNULL(CONVERT(numeric(15, 2), SUM(cd.[ApgTotalReimb])), 0.00) + ISNULL(CONVERT(numeric(15, 2), SUM(cd.[IrfTotalReimb])), 0.00) + ISNULL(CONVERT(numeric(15, 2), SUM(cd.[PhysicianTotalReimb])), 0.00) + ISNULL(CONVERT(numeric(15, 2), SUM(cd.[SnfTotalReimb])), 0.00)  AS TotalPay,
					tp.[Ecb.prcr_type] AS PricerTypeShort
             FROM [dbo].[DTA_ClaimData] cd WITH (NOLOCK)
             INNER JOIN #tempPricer tp 
                    ON tp.[DTACID] = cd.[DTACID]
             GROUP BY tp.[Ecb.prcr_type]
       ) AS PricerDetail
	   ON lc.[ShortName] = PricerDetail.[PricerTypeShort] COLLATE SQL_Latin1_General_Cp1_CS_AS
       --ORDER BY [PricerType]

END