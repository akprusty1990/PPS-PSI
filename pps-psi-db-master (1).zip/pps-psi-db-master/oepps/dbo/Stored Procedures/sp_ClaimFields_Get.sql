﻿

-- ==============================================================================
-- Author:        Callie Ju
-- Create date: 06/21/2019
-- Description: 
-- Modification: add [Enabled] = 1 to filter out "removed" varibles (Enabled = 0)
-- Gets all claim fields by LUTCID 
-- ==============================================================================
/********************************************************************************
--Test Case:
--DECLARE @Ids dbo.TVP_IDLIST;
  INSERT @Ids VALUES (21)
  EXEC sp_ClaimFields_Get @Ids
*********************************************************************************/

CREATE PROCEDURE [dbo].[sp_ClaimFields_Get] @idList dbo.TVP_IDLIST readonly 
AS 
BEGIN 
      SET NOCOUNT ON;

      SELECT ROW_NUMBER() OVER(ORDER BY [tmlCV].[ParentTMLCVID]) AS CFDBID,
	         [lutC].[LUTCID], 
             [cv].[lutcvid] AS [LUTCVID], 
             [tmlCV].[TMLCVID], 
             [tmlCVA].TMLCVAID, 
             [tmlCV].[ParentTMLCVID], 
             [cv].[VariableName], 
             [cv].[VariableDescr], 
             [tmlCV].[UIUsage], 
             [cv].[LabelOnUI], 
             [tmlCV].[FieldType], 
             [cv].[VariableType], 
             [cv].[VariableFormat], 
             [cv].[VarType], 
             [cv].[VarLength], 
             [cv].[EzgWSField], 
             [tmlCV].[FieldTextName], 
             [tmlCV].[FieldTextValue], 
             [tmlCV].[UILength], 
             [tmlCV].[DisplayOrder], 
             [tmlCVA].[AttributeName], 
             [tmlCVA].[AttributeValue] 
      FROM   [tml_claimvariable] AS [tmlCV] WITH(NOLOCK) 
             INNER JOIN [lut_claim] AS [lutC] WITH(NOLOCK) 
                     ON [tmlCV].[LUTCID] = [lutC].[LUTCID] 
             LEFT JOIN [tml_claimvariableattr] AS [tmlCVA] WITH(NOLOCK) 
                    ON [tmlCV].[TMLCVID] = [tmlCVA].[TMLCVID] 
             LEFT JOIN [lut_claimvariable] AS [cv] WITH(NOLOCK) 
                    ON [tmlCV].[LUTCVID] = [cv].[LUTCVID] 
      WHERE  ( ( [tmlCV].[FieldType] <> 'GroupBox' ) 
                OR [tmlCV].[FieldType] IS NULL ) 
             AND [lutC].[LUTCID] IN (SELECT Id 
                                     FROM   @idList) 
			 AND ([cv].[Enabled] = 1 OR [cv].[LUTCVID] is null)

      ORDER  BY [tmlCV].[ParentTMLCVID],
                [tmlCV].[DisplayOrder] 
  END