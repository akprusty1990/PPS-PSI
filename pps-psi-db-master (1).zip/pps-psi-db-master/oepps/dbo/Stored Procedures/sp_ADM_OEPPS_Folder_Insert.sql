﻿-- ============================================================================        
-- Author:  Matthew Chuong        
-- Create date: 01/20/2020        
-- Modified Date: 01/22/2020
-- Description: This stored procedure is to save the Folder location
--				into database table ADM_OEPPS_Folder        
-- =============================================================================   

/*******************************************************************************
--Test case 1: INSERT
DECLARE @FolderName varchar(100) = 'Test 1'
DECLARE @FolderType varchar(50) = 'Data'
EXEC sp_ADM_OEPPS_Folder_Insert @FolderName, @FolderType
*********************************************************************/

CREATE PROCEDURE [dbo].[sp_ADM_OEPPS_Folder_Insert] @FolderName varchar(100), @FolderType varchar(50)

AS
BEGIN
	
	DECLARE @ADMOSID int;
	DECLARE @currentStep varchar(100)
	SET NOCOUNT ON

	--Get ADMOSID for default server
	SET @currentStep = 'Get default server id.'
	SELECT TOP 1 @ADMOSID = ADMOSID
	FROM ADM_OEPPS_Server

	BEGIN TRY
		DECLARE @ErrorMessage varchar (4000)

		 -- valid param
		 SET @currentStep = 'Check input parameters.'
        IF (RTRIM(ISNULL(@FolderName, '')) = '')
        BEGIN
            SET @ErrorMessage = 'ERROR: Folder name required and not supplied.'
            RAISERROR (@ErrorMessage, 16, 1)
        END

		--valid param
		IF(RTRIM(ISNULL(@FolderType, '')) = '')
		BEGIN
            SET @ErrorMessage = 'ERROR: Folder Type required and not supplied.'
            RAISERROR (@ErrorMessage, 16, 1)
        END

		--if record already exists
		IF (EXISTS(SELECT * FROM dbo.ADM_OEPPS_Folder 
			WHERE [FolderName] = RTrim(LTrim(@FolderName)) 
			AND [FolderType] = RTrim(LTrim(@FolderType))))
		BEGIN
			SET @ErrorMessage = 'ERROR: Folder already exists.'
			RAISERROR (@ErrorMessage, 16, 1)
		END

		BEGIN TRANSACTION ADM_OEPPS_Folder_Insert_Tran
			SET @currentStep = 'Insert new record in ADM_OEPPS_Folder.'
			INSERT INTO ADM_OEPPS_Folder ([ADMOSID],[FolderName],[FolderType], [InsertedTS])
			VALUES (@ADMOSID, RTRIM(LTRIM(@FolderName)), Rtrim(Ltrim(@FolderType)), GETDATE())

		COMMIT TRANSACTION ADM_OEPPS_Folder_Insert_Tran

	END TRY

	BEGIN CATCH

		IF (ISNULL(@ErrorMessage, '') = '')
		BEGIN
			SELECT
				@ErrorMessage = 'ERROR: Folder Name could not be saved.'
		END

		IF EXISTS (SELECT [name] FROM sys.dm_tran_active_transactions WHERE name = 'ADM_OEPPS_Folder_Insert_Tran')
		BEGIN
			ROLLBACK TRAN ADM_OEPPS_Folder_Insert_Tran
		END

		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_ADM_OEPPS_Folder_Insert', @errorMessage, @@TRANCOUNT, @currentStep
		RAISERROR (@ErrorMessage, 16, 1)
	END CATCH
END