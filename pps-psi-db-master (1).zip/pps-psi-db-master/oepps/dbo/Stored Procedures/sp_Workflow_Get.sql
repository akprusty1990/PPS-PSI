﻿
-- =============================================
-- Author:		Anusha Subashini
-- Create date: 04/07/18
-- Description:	Returns All Work Flow Search  
-- =============================================
/******************************************************************************************************
EXEC [sp_Workflow_Get]

********************************************************************************/
CREATE PROCEDURE [dbo].[sp_Workflow_Get]

AS

BEGIN

  SELECT
     [WorkflowName],
     [DTAWFID],
     [ModifiedTS]
  FROM [dbo].[DTA_Workflow] WITH(NOLOCK) 

END
