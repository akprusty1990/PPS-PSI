﻿-- ==============================================================================================
-- Author:    	Amy Zhao
-- Create date: 11/1/2020
-- Description:	Get database list and permission binary number based on the login user name
-- This SP will query DTA_LoginSession by login user name to get all the groups for the user
-- and then call the table ADM_Group in each database on the server to see if the group has 
-- the access to the database, if yes, will put into the return list and corresponding permission
-- binary number.
-- ==============================================================================================
/************************************************************************************************
EXEC [dbo].[SP_ADM_DBList_Get] @LoginUser='MS\dzhao2'
EXEC [dbo].[SP_ADM_DBList_Get] @LoginUser='Optid_stg_dzhao2'
*********************************************************************/
CREATE PROCEDURE [dbo].[SP_ADM_DBList_Get] @LoginUser varchar(500) = NULL
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE	@total int,
			@dbName varchar(50),
			@index int,
			@sqlStr varchar(max),
			@groupXml varchar(max)

	DECLARE @currentStep varchar(200)

	BEGIN TRY
		DECLARE @errorMessage varchar(4000)

		SET @currentStep = 'Clean up the temp tables'
		IF OBJECT_ID('tempdb..#dbListAll') IS NOT NULL
		BEGIN
			DROP TABLE #dbListAll
		END
		IF OBJECT_ID('tempdb..#dbListReturn') IS NOT NULL
		BEGIN
			DROP TABLE #dbListReturn
		END
		IF OBJECT_ID('tempdb..#userGroups') IS NOT NULL
		BEGIN
			DROP TABLE #userGroups
		END

		SET @currentStep = 'Create temp table #dbListAll'
		SELECT
			IDENTITY(smallint) AS "index",
			name AS "dbName" INTO #dbListAll
		FROM sys.sysdatabases
		WHERE name LIKE 'oepps%'
		AND name <> 'oepps_dacpac'

		SET @currentStep = 'Get the total record in #dbListAll'
		SELECT
			@index = 1,
			@total = COUNT(dbName)
		FROM #dbListAll

		SET @currentStep = 'Create temp table #dbListReturn'
		CREATE TABLE #dbListReturn (
			[dbName] [varchar](500),
			[GroupName] [varchar](1000) NULL,
			[PermissionBinaryNumber] [int] NULL
		) ON [PRIMARY]

		SET @currentStep = 'Get the group xml from DTA_LoginSession table'
		SELECT
			@groupXml = logindata
		FROM DTA_LoginSession
		WHERE LoginUser = @LoginUser

		DECLARE @ixml AS int
		SET @ixml = NULL
		EXEC sp_xml_preparedocument	@ixml OUTPUT,
									@groupXml

		SELECT
		DISTINCT
			[group] AS GroupName INTO #userGroups
		FROM OPENXML(@ixml, '/LoginSession/Groups/group', 2)
		WITH
		(
		[group] varchar(50) '.'
		) xmlData

		-- clean up xml
		EXEC sp_xml_removedocument @ixml

		SET @currentStep = 'Loop thru the records from #dbListAll'
		WHILE (@index <= @total)
		BEGIN
			SELECT
				@dbName = dbName
			FROM #dbListAll
			WHERE [index] = @index

			SET @sqlStr = 'INSERT INTO #dbListReturn SELECT ''' + @dbName + ''' AS dbname, GroupName, PermissionBinaryNumber from [' + @dbName + '].[dbo].[ADM_Group] WHERE groupName in (SELECT groupname FROM #userGroups) or (isDefault=1)'
			--PRINT @sqlstr
			SET @currentStep = @sqlStr
			EXECUTE (@sqlstr)
			SET @index = @index + 1;
		END

		SET @currentStep = 'Return data'
		SELECT
			dbName,
			GroupName,
			PermissionBinaryNumber
		FROM #dbListReturn
		ORDER BY dbName ASC

		SET @currentStep = 'Delete temp tables'
		DROP TABLE #dbListAll
		DROP TABLE #dbListReturn
		DROP TABLE #userGroups

	END TRY
	BEGIN CATCH

		SELECT
			@errorMessage = ERROR_MESSAGE()
		EXEC [sp_DTA_EventLog_Insert_SP]	'SP_ADM_DBList_Get',
											@errorMessage,
											@@TRANCOUNT,
											@currentStep
		RAISERROR (@errorMessage, 16, 1)

	END CATCH

END