﻿
-- ============================================================================        
-- Author:  Alex Chern        
-- Create date: 11/28/2018
-- Description:         
-- This stored procedure is to delete schedules from DTA_Schedule table        
-- With following validations:        
-- 1. If provided schedule ids are in DTA_Execution table do not perform deletion and throw error.
-- 2. If after deletion there are no more schedules for workflow in future update workflow ScheduleStatus to 'Unscheduled'. 
-- 
-- Modified by Joe Lango
-- Modified on: 9/11/2020
-- if recurring, delete the recurrence data if there are no remaining schedules
-- =============================================================================       

/*******************************************************************************
--Test case
EXEC [sp_DTA_Schedule_Delete] '78,79';
*********************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_Schedule_Delete] @DTASID varchar(MAX)

AS
BEGIN

	SET NOCOUNT ON

	DECLARE @DtaWFID int
		, @ErrorMessage varchar(1000)
		, @date datetime2(0)
		, @currentStep varchar(100)
		, @DTASRID int
	;
	DECLARE @DTASID_split table (
		DTASID_value varchar(MAX)
	);

	BEGIN TRY
		INSERT INTO @DTASID_split
		SELECT RTRIM(LTRIM(value)) FROM STRING_SPLIT(@DTASID, ',')
		;

		SET @currentStep = 'Check if the schedule can be deleted.'
		IF EXISTS(SELECT DTAEID 
					FROM [dbo].[vw_DTA_WorkflowInfo]
					WHERE CAST([DTASID] AS varchar(MAX)) IN (SELECT DTASID_value FROM @DTASID_split)
						AND ISNULL([DTAEID], 0) > 0)
			BEGIN
				SET @ErrorMessage = 'ERROR: This schedule cannot be deleted for this workflow. Please refresh the screen to see the latest set of workflows and time.'
				RAISERROR (@ErrorMessage, 16, 1)
			END

		--get the schedule recurrence id if this schedule record has one.  We would need it later to possibly delete the schedulerecur information
		SET @currentStep = 'Get recurrence id for the schedule.'
		SELECT @DTASRID = DTASRID
		FROM dbo.DTA_Schedule
		WHERE CAST([DTASID] AS varchar(MAX)) IN (SELECT DTASID_value FROM @DTASID_split)
			AND DTASRID is not null
		;

		SET @currentStep = 'Get workflow id for the schedule.'
		SELECT TOP 1 @DtaWFID = [DTAWFID]
		FROM [dbo].[vw_DTA_WorkflowInfo]
		WHERE CAST([DTASID] AS varchar(MAX)) IN (SELECT DTASID_value FROM @DTASID_split)

		SET @currentStep = 'Delete schedule from DTA_Schedule.'
		DELETE [dbo].[DTA_Schedule]
		WHERE CAST([DTASID] AS varchar(MAX)) IN (SELECT DTASID_value FROM @DTASID_split)

		IF NOT EXISTS(SELECT *
					FROM [dbo].[vw_DTA_WorkflowInfo]
					WHERE [DTAWFID] = @DtaWFID AND ISNULL([DTASID], 0) > 0)
			BEGIN
				SET @currentStep = 'Update workflow schedule status.'
				UPDATE [dbo].[DTA_Workflow]
				SET [ScheduleStatus] = 'Unscheduled'
				WHERE [DTAWFID] = @DtaWFID
			END

		--if this schedule is recurring and there are no recurring schedules left, delete the DTA_ScheduleRecur record, too
		--NOTE: if some of the tasks have executed, we will never delete the recurence because it would break referential integrity.
		IF @DTASRID is not null BEGIN
			DELETE
			FROM dbo.DTA_ScheduleRecur
			WHERE DTASRID = @DTASRID
				AND NOT EXISTS(
					SELECT DTASID 
					FROM dbo.DTA_Schedule S
					WHERE DTASRID = @DTASRID
				)
			;
		END
	END TRY
	BEGIN CATCH
		IF (ISNULL(@ErrorMessage, '') = '')
		BEGIN
			SELECT
				@ErrorMessage = 'ERROR: ' +  ERROR_MESSAGE();
		END

		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_Schedule_Delete', @ErrorMessage, @@TRANCOUNT, @currentStep
		RAISERROR (@ErrorMessage, 16, 1)
	END CATCH
END