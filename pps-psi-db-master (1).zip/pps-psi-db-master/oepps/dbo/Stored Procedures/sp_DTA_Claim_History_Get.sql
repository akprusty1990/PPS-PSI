﻿-- =============================================
-- Author:        David Pinho
-- Create date: 2/5/2019
-- Description:  
-- Gets a list Claim History associated with the Given Claim ID 
-- Modification: 06/15/2020 - Get claim history based on the the value of GroupID. Claim history will no longer be tracked by DTAOCID. 
-- Modification: 06/19/2020 - Get the Claim History based on wider variety of sources.
-- =============================================
/*****************************************************************************
--Test Case:
--exec [sp_DTA_Claim_History_Get] @DTACID = 112
*****************************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_Claim_History_Get] @DTACID bigint
AS
BEGIN

    DECLARE @GroupID varchar(256) = (SELECT
        c.GroupID
    FROM [dbo].[DTA_Claim] c WITH (NOLOCK)
    WHERE c.[DTACID] = @DTACID)

    SELECT
        c.[DTACID],
        CASE [Source]
            WHEN 'OEPPS' THEN t.[TaskName]
            WHEN 'PSI' THEN 'Manual Entry'
            WHEN 'Web' THEN 'Web Entry'
            ELSE [Source]
        END [Task Name],
        c.[ModifiedTS] [Modified Time]
    FROM [dbo].[DTA_Claim] c WITH (NOLOCK)
    LEFT JOIN [dbo].[DTA_Execution] e WITH (NOLOCK)
        ON c.[DTAEID] = e.[DTAEID]
    LEFT JOIN [dbo].[DTA_Schedule] s WITH (NOLOCK)
        ON e.[DTASID] = s.[DTASID]
    LEFT JOIN [dbo].[DTA_WorkflowTask] wft WITH (NOLOCK)
        ON s.[DTAWFTID] = wft.[DTAWFTID]
    LEFT JOIN [dbo].[DTA_Task] t WITH (NOLOCK)
        ON wft.[DTATID] = t.[DTATID]
    WHERE c.GroupID = @GroupID
    ORDER BY c.[ModifiedTS] DESC, c.[DTACID] DESC

END
