﻿
--=============================================
--Author:    		Jaya Krishna
--Create date:		11/06/2019
--Description:  Get dynamic fields of 'Configured Values' section in Admin->Processing Options page.
--=============================================
/*****************************************************************************
--Test Case:
  EXEC sp_ProcessInfo_Fields_Get
*****************************************************************************/

CREATE PROCEDURE [dbo].[sp_ProcessInfo_Fields_Get]
AS

BEGIN
	DECLARE @displayflag BIT
	SET @displayflag =1
	SELECT ROW_NUMBER() OVER(ORDER BY [tmlPV].[ParentTMLPVID]) AS PFDBID,
	        [tmlPV].[TMLPVID],
			[tmlPV].[LUTCVID],
			[tmlPV].[ParentTMLPVID],
			[tmlPV].[FieldType],
			[tmlPV].[FieldTextName],
			[tmlPV].[FieldTextValue],
			[tmlPV].[EventTMLPVID],
			[tmlPV].[EventValue],
			[tmlPV].[DisplayOrder],
			[lutCV].[VariableName],
			[lutCV].[LabelOnUI],
			[lutCV].[VarLength],
			[lutCV].[VariableFormat],
			@displayflag as DisplayFlag
	FROM	[TML_ProcessInfoVariable] [tmlPV] WITH(NOLOCK) 
			INNER JOIN [LUT_ClaimVariable] [lutCV] WITH(NOLOCK) 
			ON [tmlPV].[LUTCVID] = [lutCV].[LUTCVID]
	ORDER  BY [tmlPV].[ParentTMLPVID], [tmlPV].[DisplayOrder]

END
