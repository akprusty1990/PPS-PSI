﻿

--=============================================
--Author:    		Jaya Krishna
--Create date:		09/30/2019
--Modified date:	12/04/2019
--Description:  Save Process Config UI data to 'DTA_ProcessInfo' table
-- Modification: 12/04/2019 - Save configured values as NULL if empty string value - JK
-- Modification: 03/02/2020 - Added new override ID Fields to Process Info - JK
-- Modification: 09/18/2020 - Added new contract fields (facility, npi, taxonomy, etc.,) to Process Info - JK
--=============================================
/*****************************************************************************
--Test Case 1
DECLARE @xmlProcInfo varchar(max)
SET @xmlProcInfo=
'<data>
<Dtapid>122</Dtapid>
<ProcessInfoName>TestingT1</ProcessInfoName>
<AdmofidRatePath>86</AdmofidRatePath>
<AdmofidUserPath>74</AdmofidUserPath>
<AdmofidSystemPath>85</AdmofidSystemPath>
<AdmofidOptimizer64Path>90</AdmofidOptimizer64Path>
<EcbOpcode1>16</EcbOpcode1>
<EcbPattype>02</EcbPattype>
<EcbCodeClass>01</EcbCodeClass>
<Pcb1AcceptIf>05</Pcb1AcceptIf>
<EcbOpcode3>01</EcbOpcode3>
<EcbPyrAltlookSw>2</EcbPyrAltlookSw>
<EcbMapOverrideId></EcbMapOverrideId>
<EcbHacOverrideId></EcbHacOverrideId>
<EcbAceOverrideId>ace123</EcbAceOverrideId>
<EcbApcOverrideId>apc456</EcbApcOverrideId>
<IsDefault>false</IsDefault>
</data>'
EXEC sp_DTA_ProcessInfo_Save @xmlProcInfo
===================================================
--Test Case 2 (empty string values for Configured values fields)
DECLARE @xmlProcInfo varchar(max)
SET @xmlProcInfo=
'<data>
<Dtapid>122</Dtapid>
<ProcessInfoName>TestingT1</ProcessInfoName>
<AdmofidRatePath>86</AdmofidRatePath>
<AdmofidUserPath>74</AdmofidUserPath>
<AdmofidSystemPath>85</AdmofidSystemPath>
<AdmofidOptimizer64Path>90</AdmofidOptimizer64Path>
<EcbOpcode1></EcbOpcode1>
<EcbPattype></EcbPattype>
<EcbCodeClass></EcbCodeClass>
<Pcb1AcceptIf></Pcb1AcceptIf>
<EcbOpcode3></EcbOpcode3>
<EcbPyrAltlookSw></EcbPyrAltlookSw>
<EcbMapOverrideId></EcbMapOverrideId>
<EcbHacOverrideId></EcbHacOverrideId>
<EcbAceOverrideId></EcbAceOverrideId>
<EcbApcOverrideId></EcbApcOverrideId>
<IsDefault>false</IsDefault>
</data>'
EXEC sp_DTA_ProcessInfo_Save @xmlProcInfo
--***************************************************************************/


CREATE PROCEDURE [dbo].[sp_DTA_ProcessInfo_Save]
	@xmlProcInfo varchar(max)
AS
BEGIN
	BEGIN TRY
		DECLARE @ErrorMessage varchar(4000)
		DECLARE @currentStep varchar(100)

		-- valid param
		SET @currentStep = 'Check input xml is valid.'
		IF (RTRIM(ISNULL(@xmlProcInfo, '')) = '')
		BEGIN
			SET @ErrorMessage = 'Processing Option could not be saved.'
			RAISERROR (@ErrorMessage, 16, 1)
		END

		BEGIN
			-- get the data of DTA_ProcessInfo
			SET @currentStep = 'Parse xml and get data for process info.'
			DECLARE @ixmlProcInfo AS int
			SET @ixmlProcInfo = NULL
			EXEC sp_xml_preparedocument	@ixmlProcInfo OUTPUT, @xmlProcInfo

			SELECT * INTO #tmpDTA_ProcessInfo
			FROM OPENXML(@ixmlProcInfo, '/data', 2)
			WITH
			(
			[Dtapid] [int],
			[ProcessInfoName] [varchar](50),
			[AdmofidRatePath] [int],
			[AdmofidUserPath] [int],
			[AdmofidSystemPath] [int],
			[AdmofidOptimizer64Path] [int],
			[EcbOpcode1] [char](2),
			[EcbPattype] [char](2),
			[EcbCodeClass] [char](2),
			[Pcb1AcceptIf] [char](2),
			[EcbOpcode3] [char](2),
			[EcbPyrAltlookSw] [char](1),
			[EcbMapOverrideId] [varchar](20),
			[EcbHacOverrideId] [varchar](10),
			[EcbAceOverrideId] [varchar](20),
			[EcbApcOverrideId] [varchar](20),
			[Pcb1Facility] [varchar](16),
			[Pcb1Npi] [varchar](10),
			[Pcb1Taxonomy] [varchar](10),
			[Pcb1Paysrc] [varchar](13),
			[Pcb2IcdHmoRisk] [char](1),
			[IsDefault] [bit]
			) xmlData

			-- clean up xml
			EXEC sp_xml_removedocument @ixmlProcInfo
			SET @ixmlProcInfo = NULL

			DECLARE @DTAPID int, @Admofid_rp int, @Admofid_up int, @Admofid_sp int, @Admofid_op int
			DECLARE @changeflag bit
			SELECT TOP 1 @DTAPID = tmppi.[Dtapid],
					@Admofid_rp = tmppi.[AdmofidRatePath],
					@Admofid_up = tmppi.[AdmofidUserPath],
					@Admofid_sp = tmppi.[AdmofidSystemPath],
					@Admofid_op = tmppi.[AdmofidOptimizer64Path]
			FROM #tmpDTA_ProcessInfo tmppi

			SET @currentStep = 'Check if DTAPID is valid.'
			IF(@DTAPID = 0)
			BEGIN
				SET @ErrorMessage = 'Processing Option could not be saved.'
				RAISERROR (@ErrorMessage, 16, 1)
			END

			EXEC sp_DTA_ProcessInfo_Status_Get @DTAPID, @changeflag OUTPUT

			-- valid param
			SET @currentStep = 'Validate the process info data.'
			IF ((SELECT
					COUNT(*)
				FROM #tmpDTA_ProcessInfo)
				<> 1
				or @changeflag =0
				or @Admofid_rp =0 or @Admofid_up=0 or @Admofid_sp=0 or @Admofid_op=0)
			BEGIN
				SET @ErrorMessage = 'Processing Option could not be saved.'
				RAISERROR (@ErrorMessage, 16, 1)
			END


			BEGIN TRAN DTA_ProcessInfo_Save_Transaction
				SET @currentStep = 'Update existing record in DTA_ProcessInfo.'
				UPDATE DTA_ProcessInfo
				SET [ADMOFID_RatePath] = tmppi.[AdmofidRatePath],
					[ADMOFID_UserPath] = tmppi.[AdmofidUserPath],
					[ADMOFID_SystemPath] = tmppi.[AdmofidSystemPath],
					[ADMOFID_Optimizer64Path] = tmppi.[AdmofidOptimizer64Path],
					[Ecb.opcode1] = NULLIF(RTRIM(tmppi.[EcbOpcode1]), ''),
					[Ecb.pattype] = NULLIF(RTRIM(tmppi.[EcbPattype]), ''),
					[Ecb.code_class] = NULLIF(RTRIM(tmppi.[EcbCodeClass]), ''),
					[Pcb1.accept_if] = NULLIF(RTRIM(tmppi.[Pcb1AcceptIf]), ''),
					[Ecb.opcode3] = NULLIF(RTRIM(tmppi.[EcbOpcode3]), ''),
					[Ecb.pyr_altlook_sw] = NULLIF(RTRIM(tmppi.[EcbPyrAltlookSw]), ''),
					[Ecb.map_override_id] = NULLIF(RTRIM(tmppi.[EcbMapOverrideId]), ''),
					[Ecb.hac_override_id] = NULLIF(RTRIM(tmppi.[EcbHacOverrideId]), ''),
					[Ecb.ace_override_id] = NULLIF(RTRIM(tmppi.[EcbAceOverrideId]), ''),
					[Ecb.apc_override_id] = NULLIF(RTRIM(tmppi.[EcbApcOverrideId]), ''),
					[Pcb1.facility] = NULLIF(RTRIM(tmppi.[Pcb1Facility]), ''),
					[Pcb1.npi] = NULLIF(RTRIM(tmppi.[Pcb1Npi]), ''),
					[Pcb1.taxonomy] = NULLIF(RTRIM(tmppi.[Pcb1Taxonomy]), ''),
					[Pcb1.paysrc] = NULLIF(RTRIM(tmppi.[Pcb1Paysrc]), ''),
					[Pcb2.icd.hmo_risk] = NULLIF(RTRIM(tmppi.[Pcb2IcdHmoRisk]), ''),
					[IsDefault] = tmppi.[IsDefault],
					[ModifiedTS] = GETDATE()
				FROM #tmpDTA_ProcessInfo tmppi
				WHERE [DTA_ProcessInfo].[DTAPID] = tmppi.[Dtapid]

			COMMIT TRAN DTA_ProcessInfo_Save_Transaction
		END
	END TRY

	BEGIN CATCH
		IF (ISNULL(@ErrorMessage, '') = '')
		BEGIN
			SELECT
				@ErrorMessage = 'Processing Option could not be saved.'
		END

		IF EXISTS (SELECT [name]
			FROM sys.dm_tran_active_transactions
			WHERE name = 'DTA_ProcessInfo_Save_Transaction')
		BEGIN
			ROLLBACK
		END
		
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_ProcessInfo_Save', @ErrorMessage, @@TRANCOUNT, @currentStep
		RAISERROR (@ErrorMessage, 16, 1)
	END CATCH
END