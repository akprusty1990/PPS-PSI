﻿-- ==================================================================================
-- Author:		Jaya Krishna
-- Create date: 03/20/2020
-- Description:	
-- This stored procedure is to insert data into table 'DTA_EventLog'.
-- Modification: 05/18/2020 - Delete old records from DTA_EventLog (before 7 days) - JK
-- ===================================================================================
/*************************************************************************************
EXEC [sp_DTA_EventLog_Insert_All]  null, 1, 1, 1, 'SaveWorkflow()', 'Test Error', 'Test detail'
**************************************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_EventLog_Insert_All]
@LoginUser varchar(100),
@TypeEnum smallint,
@ApplicationEnum smallint,
@SourceEnum smallint,
@SourceName varchar(100),
@Description varchar(1000),
@DescriptionDetail varchar(max),
@Data varchar(max) = null, 
@DTAELID bigint = null out
AS
BEGIN

	SET NOCOUNT ON;

	IF(EXISTS(
			SELECT 1 
			FROM DTA_EventLog 
			WHERE InsertedTS < (GETDATE()-7)))
	BEGIN
		DELETE 
		FROM DTA_EventLog 
		WHERE InsertedTS < (GETDATE()-7);
	END

	INSERT INTO
		DTA_EventLog(
		  [LoginUser]
		  ,[TypeEnum]
		  ,[ApplicationEnum]
		  ,[SourceEnum]
		  ,[SourceName]
		  ,[Description]
		  ,[DescriptionDetail]		  
		  ,[Data]
		  ,[InsertedTS]
      )VALUES
      (
          @LoginUser
		  ,@TypeEnum
		  ,@ApplicationEnum
		  ,@SourceEnum
		  ,@SourceName
		  ,@Description
		  ,@DescriptionDetail		  
		  ,@Data
		  , GETDATE()
      )
      
      SET @DTAELID = @@IDENTITY
END