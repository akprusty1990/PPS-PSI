﻿

--=============================================
--Author:    		Jaya Krishna
--Create date:		10/10/2019
--Description:  Get change status flag for process info based on DTAPID
--Expected Output: Should be 1(true) if it satisfies both the following conditions. Else, it should be 0(false)
----(1) all tasks with the DTAPID have not been scheduled or run (DTA_Task -> DTA_WorkflowTask -> DTA_Schedule)
----(2) no claims have the DTAPID assigned (DTA_Claim). 
--=============================================
/*****************************************************************************
--Test Case
DECLARE @status bit
EXEC sp_DTA_ProcessInfo_Status_Get 45, @status OUTPUT
PRINT @status
--***************************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_ProcessInfo_Status_Get]
	@DTAPID int = 0,
	@status bit OUTPUT
AS

BEGIN
	-- valid param check
	IF (ISNULL(@DTAPID, 0)=0 or 
		(SELECT COUNT(*)
		FROM DTA_ProcessInfo
		WHERE DTAPID = @DTAPID) = 0)
	BEGIN
		SET @status = 0
	END

	ELSE
	BEGIN
		DECLARE @cnt1 int, @cnt2 int
		SELECT @cnt1 = count(*)
		FROM DTA_ProcessInfo p
		INNER JOIN DTA_Task t
		ON p.DTAPID = t.DTAPID AND p.DTAPID = @DTAPID
		INNER JOIN DTA_WorkflowTask w
		ON t.DTATID = w.DTATID
		INNER JOIN DTA_Schedule s
		ON w.DTAWFTID = s.DTAWFTID

		SELECT @cnt2 = count(*)
		FROM DTA_ProcessInfo p
		INNER JOIN [DTA_Claim] c
		ON p.DTAPID = c.DTAPID AND p.DTAPID = @DTAPID

		if(@cnt1=0 and @cnt2=0) SELECT @status = 1
		else SELECT @status = 0
	END
END