﻿-- ============================================================================        
-- Author:  Alex Chern        
-- Modified by: Callie Ju        
-- Create date: 11/30/2018     
-- Modified date: 02/21/2020
-- Description:         
-- This stored procedure is to delete workflow and corresponding records from DTA_Schedule, DTA_Task, DTA_WorkflowTask, DTA_Workflow
-- Modification 02/21/2020: DTA_WorkflowTaskRelation records should be deleted when a worfklow is deleted

-- Modified by: Joe Lango
-- Modified on: 9/16/2020
-- Delete from DTA_ScheduleRecur if necessary.
-- =============================================================================       

/*******************************************************************************
--Test cases 
--EXEC [dbo].[sp_DTA_Workflow_Delete] 16 
*********************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_Workflow_Delete] @DTAWFID int

AS
BEGIN

	SET NOCOUNT ON

	DECLARE @ErrorMessage varchar(1000);
	DECLARE @DeletedIds table (
		DTATID bigint NOT NULL,
		DTAWFTID bigint NOT NULL
	);
	DECLARE @currentStep varchar(100);
	DECLARE @DeletedSchedule table (
		DTASRID int NULL
	);

	BEGIN TRY
		SET @currentStep = 'Delete schedules for workflow.';
		DELETE 
		FROM [dbo].[DTA_Schedule]
		OUTPUT deleted.DTASRID INTO @DeletedSchedule
		WHERE [DTASID] IN (
			SELECT [DTASID]
			FROM [dbo].[vw_DTA_WorkflowInfo]
			WHERE [DTAWFID] = @DTAWFID
		);

		IF EXISTS(SELECT TOP(1) DTASRID FROM @DeletedSchedule WHERE DTASRID is not null) BEGIN
			SET @currentStep = 'Delete any recurring schedule info for workflow.';
			DELETE 
			FROM [dbo].[DTA_ScheduleRecur]
			WHERE [DTASRID] IN (
				SELECT [DTASRID]
				FROM @DeletedSchedule
				WHERE DTASRID is not null
			);
		END

		SET @currentStep = 'Delete workflow tasks.'
		DELETE [dbo].[DTA_WorkflowTask]
		OUTPUT deleted.DTATID, deleted.DTAWFTID INTO @DeletedIds
		WHERE [DTAWFID] = @DTAWFID

		DELETE [dbo].[DTA_Task]
		WHERE [DTATID] IN (SELECT
				DTATID
			FROM @DeletedIds)

		SET @currentStep = 'Delete workflow task relations.'
		DELETE [dbo].[DTA_WorkflowTaskRelation]
		WHERE [DTAWFTID] IN (SELECT
				DTAWFTID
			FROM @DeletedIds)

		SET @currentStep = 'Delete workflow from DTA_Workflow.'
		DELETE [dbo].[DTA_Workflow]
		WHERE [DTAWFID] = @DTAWFID

	END TRY
	BEGIN CATCH
		SET @ErrorMessage = ERROR_MESSAGE();
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_Workflow_Delete', @ErrorMessage, @@TRANCOUNT, @currentStep
		RAISERROR (@errorMessage, 16, 1)
	END CATCH
END