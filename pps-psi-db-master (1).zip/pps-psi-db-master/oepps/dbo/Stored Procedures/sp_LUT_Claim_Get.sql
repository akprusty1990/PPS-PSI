﻿-- =============================================
-- Author:        Callie Ju
-- Create date:	  05/27/2020
-- Description:  
-- Get a list of Pricer Types for UI DDL
-- =============================================
/*****************************************************************************
--Test Case:
--EXEC sp_LUT_Claim_Get
*****************************************************************************/
CREATE PROCEDURE [dbo].[sp_LUT_Claim_Get]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT
		*
	FROM [dbo].[LUT_Claim] WITH (NOLOCK)
	WHERE [Enabled] = 1
	AND [Pattype] IS NOT NULL
	ORDER BY [LongName]
END