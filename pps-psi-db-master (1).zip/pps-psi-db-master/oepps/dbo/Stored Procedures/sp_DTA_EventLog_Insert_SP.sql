﻿-- =========================================================================================
-- Author: Jaya Krishna
-- Create date: 03/20/2020
-- Description:	
-- This stored procedure is to insert error info into table DTA_EventLog for StoredProcedure
-- ==========================================================================================
/********************************************************************************************
EXEC [SP_DTA_EventLog_Insert_SP] 'sp_DTA_Claim_Get',0,'Test Error',0,'other'
********************************************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_EventLog_Insert_SP]
@storedProcedureName varchar(50),
@errMsg AS varchar(max),
@tranCount int,
@currentStep varchar(100),
@raiseERROR bit = 0
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @OtherErrMsg varchar(500), @HasRollBack bit, @typeEnum smallint

	BEGIN TRY
		SELECT @HasRollBack = 0, @typeEnum = 3 -- 3 is error type
		IF(@tranCount > 0 AND @raiseERROR = 1)  
		BEGIN  
			ROLLBACK TRAN  
			SET @hasRollBack = 1
		END

		-- log error
		SET @otherErrMsg = 'CurrentStep: ' + ISNULL(@currentStep,'') +  ' HasRollBack: ' + CAST(@HasRollBack AS CHAR(1)) 
		EXEC sp_DTA_EventLog_Insert_All null, @typeEnum, 2, 3, @storedProcedureName, @errMsg, @otherErrMsg

	END TRY
	BEGIN CATCH

		declare @err varchar(max)
		set @err = ERROR_MESSAGE()
		IF(@raiseERROR = 1)
			RAISERROR(@err, 16, 1)

	END CATCH
END
