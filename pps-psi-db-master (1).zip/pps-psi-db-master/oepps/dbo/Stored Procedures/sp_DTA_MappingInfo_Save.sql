﻿

-- ============================================================================        
-- Author:  Alexander Chern        
-- Modified by: Callie Ju       
-- Create date: 05/28/2019
-- Modified date: 07/25/2019
-- Description:         
-- This stored procedure is to create new mappingInfo or save data into DTA_MappingInfo table       
-- 1. Get @Dtamid if it is 0 
-- 2. Update the ModifiedTS in the table DTA_MappingInfo
-- 3. Set InsertedTS if row is inserted.
-- 4. Trim leading and trailing spaces from layoutName
-- 5. Raise error is layoutName is empty or just spaces
-- =============================================================================       

/*******************************************************************************
--Test case 1: insert testing
DECLARE @LayoutName VARCHAR(100) = 'Test'
DECLARE @Content VARCHAR(MAX) = ''
DECLARE @Dtamid int = 0

EXEC [dbo].[sp_DTA_MappingInfo_Save] @LayoutName, @Content, @Dtamid
*********************************************************************/

/*********************************************************************
--Test case 2: Update testing
DECLARE @LayoutName VARCHAR(100) = 'Test'
DECLARE @Content VARCHAR(MAX) = ''
DECLARE @Dtamid int = 5

EXEC [dbo].[sp_DTA_MappingInfo_Save] @LayoutName, @Content, @Dtamid

*********************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_MappingInfo_Save] @LayoutName varchar(100), @Content varchar(max), @Dtamid int = 0 OUTPUT 

AS
BEGIN

	DECLARE @ID_LIST tvp_IdList

	BEGIN TRY
		DECLARE @ErrorMessage varchar(4000)

		IF @Dtamid = 0 
		BEGIN
			IF EXISTS(
				SELECT *
				FROM [dbo].[DTA_MappingInfo] 
				WHERE [LayoutName] = RTrim(LTrim(@LayoutName)))
			BEGIN
				SET @ErrorMessage = 'ERROR: A layout with this name already exists.'
				RAISERROR (@ErrorMessage, 16, 1)
			END

			IF (RTRIM(@LayoutName) = '')
		    BEGIN
			SET @ErrorMessage = 'ERROR: Layout name cannot be empty.'
			RAISERROR (@ErrorMessage, 16, 1)
		    END

			INSERT INTO [dbo].[DTA_MappingInfo]
				([LayoutName]
				,[Content]
				,[InsertedTS]
				,[ModifiedTS])
			OUTPUT inserted.DTAMID
			INTO @ID_LIST
			VALUES
				(Rtrim(Ltrim(@LayoutName))
				,@Content
				,GETUTCDATE()
				,GETUTCDATE()
			)

			SELECT @Dtamid = id
			FROM @ID_LIST

		END
		ELSE
		BEGIN
			IF [dbo].[udf_DTA_MappingInfo_Status_Get](@Dtamid) = 1
			BEGIN
				SET @ErrorMessage = 'ERROR: Layout has been used in a workflow that has been scheduled or run.'
				RAISERROR (@ErrorMessage, 16, 1)
			END

			UPDATE [dbo].[DTA_MappingInfo]
			SET [LayoutName] = @LayoutName
				,[Content] = @Content
				,[ModifiedTS] = GETUTCDATE()
			WHERE [DTAMID] = @Dtamid
		END
	END TRY
	BEGIN CATCH

		IF (ISNULL(@ErrorMessage, '') = '')
		BEGIN
			SELECT
				@ErrorMessage = 'ERROR' + ERROR_MESSAGE()
		END

		RAISERROR (@ErrorMessage, 16, 1)

	END CATCH
			
END