﻿

--=============================================
--Author:    		David Pinho
--Create date:		04/10/2019
--Description:  Update Execution Status and Workflow Complete
--1. Update DTA_Execution with complete status
--2. Update status DTA_Workflow table if all complete
--Modification: 02/27/2020 Luhai Huang - Update start time only when start time is passed from Oepps
--Modification: 03/27/2020 Luhai Huang - Batch executed number doesn't increase when it is not called by [dbo].[sp_OEPPS_DTA_Claim_Transfer]
--Modification: 04/01/2020 Luhai Huang - Update execution status wording 
--Modification: 04/02/2020 Phil Schelhorn - Remove export-specific logic, it should follow the same flow and parameters as other task types
--Modification: 04/02/2020 Phil Schelhorn - Remove @iIncr parameter, this procedure should always increase the NumCompletedBatches when called (it should only be called to update batch information)
--Modification: 04/02/2020 Phil Schelhorn - Consolidated status set statement into DTA_Execution table update, and based the setting off StatusCode
--Modification: 04/02/2020 Phil Schelhorn - Reintroduced check on the number of batches before setting end time
--Modification: 04/08/2020 Luhai Huang - Remove GRANT EXECUTE ON OBJECT::[dbo].[sp_OEPPS_Execution_Status_Update] TO PUBLIC AS [dbo];
--Modification: 07/21/2020 Jaya Krishna - Update start time only for the first batch.
--Modification: 11/09/2020 Luhai Huang - Update execution status after completed batch >= batch number because sometimes a batch is tried multiple time.
--Modification: 11/09/2020 Luhai Huang - Roll back Update execution status after completed batch >= batch number because sometimes a batch is tried multiple time.
--=============================================

--**************************************************************************
--Test Case
--EXEC [dbo].[sp_OEPPS_Execution_Status_Update] 1, 1, 1
--**************************************************************************

CREATE PROCEDURE [dbo].[sp_OEPPS_Execution_Status_Update] (
	@AppID INT, 
	@AcctID INT,
	@DTAEID INT,
	@NumClaims INT,
	@NumBatches INT,
	@NumEdits INT = 0,
	@NumReturnCodes INT = 0,
	@NumOfClaimStatusCodes INT = 0,
	@ExecutionStartTime BIGINT = 0)
AS
BEGIN
	DECLARE @null TIME = '';
	DECLARE @Time datetime2(0) = GETUTCDATE();
	DECLARE @completedBatches INT;
	DECLARE @sStatus VARCHAR(20);
	DECLARE @StatusCode INT = 0;

	--Assess current status of the execution
	SELECT @completedBatches = ISNULL(NumCompletedBatches, 0) + 1,
		 @NumBatches = CASE WHEN @NumBatches = 0 THEN NumBatches ELSE @NumBatches END,
		 @StatusCode = [StatusCode]
	FROM [dbo].[DTA_Execution] WHERE [DTAEID] = @DTAEID

	--Update execution start time
	IF (@ExecutionStartTime > 0 and @completedBatches = 1)
	BEGIN
		DECLARE @dtInput DATETIME2 = '00010101';
		SET @dtInput = DATEADD(DAY, @ExecutionStartTime / 864000000000, @dtInput);
		SET @dtInput = DATEADD(SECOND, (@ExecutionStartTime % 864000000000) / 10000000, @dtInput);
		SET @dtInput = DATEADD(NANOSECOND, (@ExecutionStartTime % 10000000 ) * 100, @dtInput);
		--Convert execution start time (sent from oepps) to utc and update it in DTA_Execution.
		UPDATE [dbo].[DTA_Execution] SET [StartTime] = DATEADD(second, DATEDIFF(second, GETDATE(), GETUTCDATE()), @dtInput) WHERE [DTAEID] = @DTAEID;
	END

	UPDATE [dbo].[DTA_Execution]
	SET Endtime = CASE WHEN (@completedBatches = @NumBatches) THEN @Time ELSE Endtime END,
		[NumOfClaims] = ISNULL([NumOfClaims], 0) + @NumClaims,
		[RecordsPerSecond] = ((ISNULL([NumOfClaims], 0) + @NumClaims) / ISNULL(NULLIF((DATEPART(hh, DATEADD(SECOND, -DATEDIFF(SECOND, @Time, StartTime), @null)) * 60 * 60) +
		(DATEPART(mi, DATEADD(SECOND, -DATEDIFF(SECOND, @Time, StartTime), @null)) * 60) +
		DATEPART(s, DATEADD(SECOND, -DATEDIFF(SECOND, @Time, StartTime), @null)), 0), 1)),
		[NumBatches] = @NumBatches,
		[NumCompletedBatches] = @completedBatches,
		[Status] = CASE WHEN (@completedBatches = @NumBatches) AND (@StatusCode is not NULL and @StatusCode <> 0 and @StatusCode <> 702) THEN 'Failed' 
						WHEN (@completedBatches = @NumBatches) AND (@StatusCode is NULL or @Statuscode = 0 or @StatusCode = 702) THEN 'Completed' 
						ELSE [Status] END,
		[NumEdits] =  ISNULL([NumEdits], 0) + @NumEdits,
		[NumReturnCodes] = ISNULL([NumReturnCodes], 0) + @NumReturnCodes,
		[NumOfClaimStatusCodes] = ISNULL([NumOfClaimStatusCodes], 0) + @NumOfClaimStatusCodes
	WHERE [DTAEID] = @DTAEID
	
	/* Update workflow status once all executions within the workflow are finished:
	   - If all tasks are complete, then 'Completed'
	   - If any task fails, then 'Failed'
	*/
	IF (@completedBatches = @NumBatches)
	BEGIN 
		DECLARE @DTAWFID INT;
		SELECT TOP(1) @DTAWFID = wft.[DTAWFID]
		FROM [dbo].[DTA_Execution] e WITH (NOLOCK)
		INNER JOIN [dbo].[DTA_Schedule] s WITH (NOLOCK)
			ON e.DTASID = s.DTASID
		INNER JOIN [dbo].[DTA_WorkflowTask] wft WITH (NOLOCK)
			ON s.DTAWFTID = wft.DTAWFTID
		WHERE e.DTAEID = @DTAEID
		--Update workflow status according to latest task status
		DECLARE @nRun		INT = 0;
		DECLARE @tbl TABLE
		(
			Run			INT,
			DTASID		INT,
			DTAEID		INT,
			[Status]	VARCHAR(20)
		)	
		INSERT INTO @tbl
		SELECT [Run], [DTASID], [DTAEID], [Status] FROM [dbo].[fnWorkflowRunInfo] (@DTAWFID);
		SELECT @nRun = MAX(Run) FROM @tbl WHERE DTAEID = 0;
		SELECT @sStatus = [Status] FROM @tbl WHERE Run = @nRun AND [DTAEID] = 0;
		UPDATE [dbo].[DTA_Workflow] SET [Status] = @sStatus WHERE [DTAWFID] = @DTAWFID AND @nRun > 0;
	END  
END
GO