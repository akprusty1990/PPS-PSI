﻿

-- ============================================================================        
-- Author:  Alex Chern        
-- Modified by        
-- Create date: 10/10/2018        
-- Description:         
-- This stored procedure is to save the xml format data of Claim Filter        
-- into database table DTA_ClaimFilter and DTA_ClaimFilterDetail.        
-- 1. Validate the input data   
-- 2. Get DTACFID from <Dtacfid> 
-- 3. Update the ModifiedTS in the table DTA_ClaimFilter
-- 5. Insert the claim filter details into the table DTA_ClaimFilterDetail if the DTACFDID is NULL or 0  
-- 6. Otherwise update the details DTACFDID > 0  
-- 7. Merge the data in the table DTA_WorkflowTask: 
--       if DTATID+DTAWFID exists, update ModifiedTS; 
--       else , insert a new
-- 8. Delete the record in the table DTA_WorkflowTask if not exist in the passing xml
-- 9. Delete the records in DTA_Task based on the deleted result from previous step  
-- Note: this sp can be called when user enters data manually on screen and it can be called without user intervention. If there is user interaction
--		the sp throws error if user entered duplicate name and forces the user to change filter name. Otherwise (no user intervention)the sp appends
--		[seqnum] to provided name to create unique name.     
-- =============================================================================       

/*******************************************************************************
--Test case 1: insert testing (no data)
DECLARE @XmlStr VARCHAR(MAX)

SET @XmlStr = ''

EXEC [dbo].[sp_DTA_ClaimFilter_Save] @XmlStr
*********************************************************************/
/*******************************************************************************
--Test case 2: insert testing (duplicate name) (run twise to get duplicate name error)
DECLARE @XmlStr VARCHAR(MAX)

SET @XmlStr = '<data><Dtacfid>0</Dtacfid><FilterName>Alex create new workflow</FilterName><Lutcndid>1</Lutcndid><Detail><Dtacfdid>0</Dtacfdid><Dtacfid>0</Dtacfid><DisplayOrder>1</DisplayOrder><Lutcvid>6</Lutcvid><Lutcoid>1</Lutcoid><VariableValue>smith</VariableValue><VariableType>TEXT</VariableType><ModifiedTS></ModifiedTS></Detail></data>'

EXEC [dbo].[sp_DTA_ClaimFilter_Save] @XmlStr
*********************************************************************/
/*******************************************************************************
--Test case 3: insert testing (success new fiter id returned) 
DECLARE @XmlStr VARCHAR(MAX)
DECLARE @DTACFID int

SET @XmlStr = '<data><Dtacfid>0</Dtacfid><FilterName>Alex create new workflow 99</FilterName><Lutcndid>1</Lutcndid><Detail><Dtacfdid>0</Dtacfdid><Dtacfid>0</Dtacfid><DisplayOrder>1</DisplayOrder><Lutcvid>6</Lutcvid><Lutcoid>1</Lutcoid><VariableValue>smith</VariableValue><VariableType>TEXT</VariableType><ModifiedTS></ModifiedTS></Detail></data>'

EXEC [dbo].[sp_DTA_ClaimFilter_Save] @XmlStr, @DTACFID OUTPUT

SELECT @DTACFID
*********************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_ClaimFilter_Save] @ClaimFilterXml varchar(max) = NULL, @DTACFID int = 0 OUTPUT, @isNameAdjust bit = 0

AS
BEGIN

	DECLARE @numRec int;
	SET NOCOUNT ON

	BEGIN TRY
		DECLARE @ErrorMessage varchar(4000)
		DECLARE @filterName [varchar](50)
		DECLARE @nameIncrement varchar(5)
		DECLARE @currentStep varchar(100)

		-- valid param
		SET @currentStep = 'Check input parameters.'
		IF (RTRIM(ISNULL(@ClaimFilterXml, '')) = '')
		BEGIN
			SET @ErrorMessage = 'ERROR: Claim filter cannot be empty.'
			RAISERROR (@ErrorMessage, 16, 1)
		END

		-- parse the xml
		SET @currentStep = 'Parse xml.'
		DECLARE @iDoc AS int
		SET @iDoc = NULL

		EXEC sp_xml_preparedocument	@iDoc OUTPUT,
									@ClaimFilterXml

		-- get claim filter data from xml
		SET @currentStep = 'Get claim filter data from xml.'
		SELECT
			* INTO #tmpDTA_ClaimFilter
		FROM OPENXML(@iDoc, '/data', 2)
		WITH
		(
		[Dtacfid] [bigint],
		[FilterName] [varchar](50),
		[Lutcndid] [int],
		[Source] [varchar] (MAX)
		) xmlData

		-- get claim filter detail data from xml
		SET @currentStep = 'Get claim filter detail from xml.'
		SELECT
			* INTO #tmpDTA_ClaimFilterDetail
		FROM OPENXML(@iDoc, '/data/Detail', 2)
		WITH
		(
		[Dtacfdid] [bigint],
		[Dtacfid] [int],
		[DisplayOrder] [tinyint],
		[Lutcvid] [int],
		[Lutcoid] [int],
		[VariableValue] [varchar](MAX)
		) xmlData

		-- clean up xml
		EXEC sp_xml_removedocument @iDoc
		SET @iDoc = NULL

			-- get DTACFID
		SELECT
			@DTACFID = [Dtacfid], @filterName = LTRIM(RTRIM([FilterName]))
		FROM #tmpDTA_ClaimFilter

		--if DTACFID does not exist in Table
		SET @currentStep = 'Check DTACFID.'
		IF NOT EXISTS(
			SELECT * FROM DTA_ClaimFilter cf WITH (NOLOCK)
			WHERE cf.DTACFID = @DTACFID) AND @DTACFID != 0
		BEGIN
			SET @ErrorMessage = 'Filter does not exist.'
			RAISERROR (@ErrorMessage, 16, 1)
		END

		SET @currentStep = 'Check filter name.'
		IF EXISTS(
			SELECT *
			FROM [dbo].[DTA_ClaimFilter] WITH (NOLOCK)
			WHERE LTRIM(RTRIM([FilterName])) IN (SELECT LTRIM(RTRIM(FilterName))
									FROM #tmpDTA_ClaimFilter))

			AND (ISNULL(@DTACFID, 0) = 0)
		BEGIN
			IF @isNameAdjust = 0
			BEGIN
				SET @ErrorMessage = 'ERROR: A claim filter with this name already exists.'
				RAISERROR (@ErrorMessage, 16, 1)
			END
			ELSE
			BEGIN
			-- In order to create unique filter name we append [seqnum] to provided name. After this manipulation we check whether name we built
			-- is unique. If it is not unique we increase seqnum by 1 and repeat check. 
				WHILE EXISTS(
						SELECT *
						FROM [dbo].[DTA_ClaimFilter] WITH (NOLOCK)
						WHERE LTRIM(RTRIM([FilterName])) = RTRIM(LTRIM(@filterName)) + '[' + ISNULL(@nameIncrement, '1') + ']')
				BEGIN
						SET @nameIncrement = ISNULL(@nameIncrement, '1') + 1
				END

				SET @filterName = RTRIM(LTRIM(@filterName)) + '[' + ISNULL(@nameIncrement, '1') + ']'
			END
		END

		-- begin tran
		BEGIN TRAN DTA_ClaimFilter_Save_Transaction
			
			-- get DTACFID
			IF (ISNULL(@DTACFID, 0) = 0)
			BEGIN
				SET @currentStep = 'Insert new claim filter.'
				CREATE TABLE #DTACFID(DTACFID bigint)
				INSERT INTO [dbo].[DTA_ClaimFilter]
					(
					[FilterName],
					[Lutcndid],
					[Source]
					)
				OUTPUT inserted.DTACFID
				INTO #DTACFID
				SELECT @filterName, 
						[Lutcndid],
						[Source]
				FROM #tmpDTA_ClaimFilter
				SELECT @DTACFID = [DTACFID]
				FROM #DTACFID
				DROP TABLE #DTACFID
			END
			ELSE	
			BEGIN
				SET @currentStep = 'Update existing claim filter.'
			-- update DTA_ClaimFilter ModifiedTS
				UPDATE [dbo].[DTA_ClaimFilter] 
				SET [FilterName] = t.[FilterName],
					[Lutcndid] = t.[Lutcndid],
					[Source] = t.[Source],
					[ModifiedTS] = GETUTCDATE()
				FROM #tmpDTA_ClaimFilter t
				WHERE [dbo].[DTA_ClaimFilter].[DTACFID] = @DTACFID
			END

			SET @currentStep = 'Update filter detail for existing claim filter.'
			-- delete the record from DTA_ClaimDetail
			DELETE FROM [dbo].[DTA_ClaimFilterDetail]
			WHERE [DTACFID] = @DTACFID
				AND NOT [DTACFDID] IN (SELECT [DTACFDID] 
									FROM #tmpDTA_ClaimFilterDetail) 

			-- insert the new id
			INSERT INTO [dbo].[DTA_ClaimFilterDetail] ([DTACFID]
				, [DisplayOrder]
				, [LUTCVID]
				, [Lutcoid]
				, [VariableValue]
				, [ModifiedTS])
			SELECT
				@DTACFID,
				[DisplayOrder],
				[Lutcvid],
				[Lutcoid],
				[VariableValue],
				GETUTCDATE()
			FROM #tmpDTA_ClaimFilterDetail tmpCFD
			WHERE ISNULL(tmpCFD.[DTACFDID], 0) = 0

			-- UPDATE the existing filters
			UPDATE dtaCFD
			SET	dtaCFD.[DTACFID] = tmpCFD.[DTACFID],
				dtaCFD.[DisplayOrder] = tmpCFD.[DisplayOrder],
				dtaCFD.[LUTCVID] = tmpCFD.[Lutcvid],
				dtaCFD.[Lutcoid] = tmpCFD.[Lutcoid],
				dtaCFD.[VariableValue] = tmpCFD.[VariableValue],
				dtaCFD.[ModifiedTS] = GETUTCDATE()
			FROM [dbo].[DTA_ClaimFilterDetail] dtaCFD
			INNER JOIN #tmpDTA_ClaimFilterDetail tmpCFD
				ON dtaCFD.[DTACFDID] = tmpCFD.[DTACFDID]
			WHERE ISNULL(tmpCFD.[DTACFDID], 0) > 0

		COMMIT TRAN DTA_ClaimFilter_Save_Transaction

	END TRY
	BEGIN CATCH

		IF (ISNULL(@ErrorMessage, '') = '')
		BEGIN
			SELECT
				@ErrorMessage = 'ERROR' + ERROR_MESSAGE()
		END

		IF EXISTS (SELECT
				[name]
			FROM sys.dm_tran_active_transactions
			WHERE name = 'DTA_ClaimFilter_Save_Transaction')
		BEGIN
			ROLLBACK
		END
		
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_ClaimFilter_Save', @errorMessage, @@TRANCOUNT, @currentStep
		RAISERROR (@ErrorMessage, 16, 1)

	END CATCH

END
