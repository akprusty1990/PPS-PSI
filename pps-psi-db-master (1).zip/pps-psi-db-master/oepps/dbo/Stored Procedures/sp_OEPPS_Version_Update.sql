﻿--=============================================
--Author:    		Jaya Krishna
--Create date:		01/02/2020
--Description:  Update OEPPS app version in 'ADM_OEPPS_Server' table based on server name. If @serverName = null, update all the rows
--=============================================
/*****************************************************************************
--Test Case:
  EXEC [sp_OEPPS_Version_Update] 'oeppspsi01', '1912.00'
  EXEC [sp_OEPPS_Version_Update] null, '1912.02'
*****************************************************************************/

CREATE PROCEDURE [dbo].[sp_OEPPS_Version_Update]
	@serverName varchar(50) =null,
	@appVersion varchar(50)
AS
BEGIN
	BEGIN TRY
		DECLARE @ErrorMessage varchar(4000)
		DECLARE @currentStep varchar(100)

		BEGIN TRAN ADM_OEPPS_Version_Updt_Tran
			SET @currentStep = 'Update oepps app version in ADM_OEPPS_Server.'
			UPDATE ADM_OEPPS_Server
			SET AppVersion = @appVersion,
				ModifiedTS = GETDATE()
			WHERE ServerName = @serverName OR @serverName = NULL
		COMMIT TRAN ADM_OEPPS_Version_Updt_Tran

	END TRY

	BEGIN CATCH
		IF (ISNULL(@ErrorMessage, '') = '')
		BEGIN
			SELECT
				@ErrorMessage = 'ERROR' + ERROR_MESSAGE()
		END
		IF EXISTS (SELECT [name]
					FROM sys.dm_tran_active_transactions
					WHERE name = 'ADM_OEPPS_Version_Updt_Tran')
		BEGIN
			ROLLBACK
		END
		
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_OEPPS_Version_Update', @ErrorMessage, @@TRANCOUNT, @currentStep
		RAISERROR (@ErrorMessage, 16, 1)

	END CATCH
END
