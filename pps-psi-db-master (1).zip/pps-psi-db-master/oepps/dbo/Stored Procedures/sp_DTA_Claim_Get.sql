﻿

-- =============================================
-- Author:        Callie Ju
-- Create date:	  07/01/201p
-- Description:  
-- Get DTA_Claim detail for given DTACID
-- Modification: 06/15/2020 -  Add the GroupID column to the resultset.
-- Modification: 07/14/2020 - Remove Dependencies/References to DTAOCID and IsLatest
-- =============================================
/*****************************************************************************
--Test Case:
--EXEC sp_DTA_Claim_Get 10130
*****************************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_Claim_Get] @DTACID bigint
AS
BEGIN

	SET NOCOUNT ON;
	OPEN SYMMETRIC KEY SQLSymmetricKey256 
	DECRYPTION BY CERTIFICATE PSICERTIFICATE;
	SELECT [DTACID]
      ,[GroupID]
      ,[DTAPCID]
      ,[ClaimNum]
      ,[InsertedTS]
      ,[Source]
      ,[DTAEID]
      ,CONVERT(varchar(MAX), DecryptByKey([Pcb1.med_num])) AS Pcb1MedNum
      ,CONVERT(varchar(MAX), DecryptByKey([Oepps.member_id])) AS OeppsMemberId
      ,CONVERT(varchar(MAX), DecryptByKey([Pcb1.ctr_num])) AS Pcb1CtrNum
      ,CONVERT(varchar(MAX), DecryptByKey([Pcb1.hplan_id])) AS Pcb1HplanId
      ,[Pcb1.npi] AS Pcb1Npi
      ,[Pcb1.taxonomy] AS Pcb1Taxonomy
      ,[Pcb1.paysrc] AS Pcb1Paysrc
      ,CONVERT(date, DecryptByKey([Pcb1.from_date])) AS Pcb1FromDate
      ,CONVERT(date, DecryptByKey([Pcb1.thru_date])) AS Pcb1ThruDate
      ,CONVERT(date, DecryptByKey([Pcb1.birth_date])) AS Pcb1birthDate
      ,CONVERT(date, DecryptByKey([Pcb1.admit_date])) AS Pcb1AdmitDate
      ,[Ecb.prcr_type] AS EcbPrcrType
      ,[Ecb.func_rtn_code] AS EcbFuncRtnCode
      ,[Pcb1.facility] AS Pcb1Facility
      ,CONVERT(varchar(MAX), DecryptByKey([Oepps.claim_id])) AS OeppsClaimId
      ,CONVERT(varchar(MAX), DecryptByKey([Oepps.fname])) AS OeppsFname
      ,CONVERT(varchar(MAX), DecryptByKey([Oepps.mname])) AS OeppsMname
      ,CONVERT(varchar(MAX), DecryptByKey([Oepps.lname])) AS OeppsLname
      ,[StatusMsg]
      ,[StatusCode]
      ,[Oob1.opt_rtn_code] AS Oob1OptRtnCode
      ,[HasEdits]
      ,[ModifiedTS]
      ,[DTAPID]
	
	FROM DTA_Claim WITH (NOLOCK)
	WHERE DTACID = @DTACID
END