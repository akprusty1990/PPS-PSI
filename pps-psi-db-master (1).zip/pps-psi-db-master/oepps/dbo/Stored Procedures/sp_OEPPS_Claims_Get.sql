﻿
-- =============================================
-- Author:  David Pinho
-- Create date: 11/12/2018
-- Modified by: Jaya Krishna
-- Modified date: 01/30/2020
-- Description:     Send all claims defined by the filter to OEPPS
-- Modification: 07/26/2019 (Chinnana Raja)- Updated the SP to return empty results when the filter (DTACFID) is not available 
-- Modified date: 10/22/2019 Luhai Huang
--                  Get extra data from dbo.DTA_Claim
-- Modification: 01/23/2020 (Jaya Krishna) - Updated sp to incorporate Task relationship.
-- Modification: 01/30/2020 (Jaya Krishna) - When multiple runs exist for parent tasks, take latest ones based on Start Time.
-- Modification: 06/15/2020 - Get latest claim based on the the value of GroupID. Claim history will no longer be tracked by DTAOCID.
-- Modification: 07/14/2020 - Remove Dependencies/References to DTAOCID and IsLatest
-- Modification: 08/31/2020 - Call sp_ClaimSearchDynamic_Get to get the dynamic SQL for filtering the claims based on the search criteria.
-- Modification: 10/16/2020 - Luhai Huang Add try catch raise
-- =============================================
/*******************************************************************************
EXEC [dbo].[sp_OEPPS_Claims_Get] 1,1,1001
*********************************************************************/
CREATE PROCEDURE [dbo].[sp_OEPPS_Claims_Get] @AppID int, @AcctID int, @DTAEID AS int WITH RECOMPILE
AS
BEGIN
    OPEN SYMMETRIC KEY SQLSymmetricKey256
    DECRYPTION BY CERTIFICATE PSICERTIFICATE;

    SET NOCOUNT ON;
    DECLARE @filter varchar(max) = '';
    DECLARE @dynamicSQL varchar(max) = '';
    DECLARE @dtacfid int;
    DECLARE @dtawftid int;
    DECLARE @hasParentRelation bit = 0;
    CREATE TABLE #tmp_ParentExecutionList (
        Dtaeid int
    )
    CREATE TABLE #tmp_FilteredClaims (
        DTACID bigint NOT NULL PRIMARY KEY
    )
    DECLARE @currentStep varchar(100)
    DECLARE @errorMessage varchar(4000)

    BEGIN TRY
        SELECT
            @dtacfid = t.DTACFID
        FROM dbo.DTA_Execution e WITH (NOLOCK)
        INNER JOIN dbo.DTA_Schedule s WITH (NOLOCK)
            ON s.DTASID = e.DTASID
        INNER JOIN dbo.DTA_WorkflowTask w WITH (NOLOCK)
            ON w.DTAWFTID = s.DTAWFTID
        INNER JOIN dbo.DTA_Task t WITH (NOLOCK)
            ON t.DTATID = w.DTATID
        WHERE e.dtaeid = @DTAEID;

        SELECT
            @dtawftid = s.DTAWFTID
        FROM dbo.DTA_Execution e WITH (NOLOCK)
        INNER JOIN dbo.DTA_Schedule s WITH (NOLOCK)
            ON e.DTASID = s.DTASID
        WHERE e.DTAEID = @DTAEID;

        SELECT
            * INTO #tmp_WFTaskRelation
        FROM DTA_WorkflowTaskRelation WITH (NOLOCK)
        WHERE DTA_WorkflowTaskRelation.DTAWFTID = @dtawftid

        IF (EXISTS (SELECT
                *
            FROM #tmp_WFTaskRelation)
            )
        BEGIN
            SET @hasParentRelation = 1;
            -- check if the task relation is for parent execution or parent task.
            IF ((SELECT TOP 1
                    [DTAPEID]
                FROM #tmp_WFTaskRelation)
                IS NOT NULL)
            BEGIN
                --get list of parent execution ids (DTAPEID) for the current task.
                INSERT INTO #tmp_ParentExecutionList
                    SELECT
                        [DTAPEID]
                    FROM #tmp_WFTaskRelation
            END
            ELSE
            BEGIN
                --link parent tasks to corres. EIDs in DTA_Execution table.
                --If multiple EIDs exist for same parent task, take the latest one (ordered by 'StartTime' desc, while partitioned by parent task id).
                WITH cte
                AS (SELECT
                    wftr.[DTAPWFTID] AS DTAPWFTID,
                    e.[DTAEID] AS DTAPEID,
                    e.[StartTime] AS StartTime,
                    ROW_NUMBER() OVER (PARTITION BY wftr.DTAPWFTID ORDER BY e.StartTime DESC) AS rownum
                FROM #tmp_WFTaskRelation wftr
                INNER JOIN DTA_WorkflowTask wft WITH (NOLOCK)
                    ON wftr.DTAPWFTID = wft.DTAWFTID
                INNER JOIN DTA_Schedule s WITH (NOLOCK)
                    ON wft.DTAWFTID = s.DTAWFTID
                INNER JOIN DTA_Execution e WITH (NOLOCK)
                    ON s.DTASID = e.DTASID)
                INSERT INTO #tmp_ParentExecutionList
                    SELECT
                        DTAPEID
                    FROM cte
                    WHERE rownum = 1
            END
        END

        DECLARE @MaxDTACID varchar(20) = IDENT_CURRENT('dta_claim');
        SET @filter = ' c.dtacid <= ' + @MaxDTACID +
        IIF(@hasParentRelation = 1, ' AND c.DTAEID IN (SELECT * FROM #tmp_ParentExecutionList) ', '')

        --Execute sp_ClaimSearchDynamic_Get to get the dynamic SQL for filtering the claims
        IF (ISNULL(@DTACFID, 0) > 0
            OR @hasParentRelation = 1)
        BEGIN
            EXEC [dbo].[sp_ClaimSearchDynamic_Get] @isProcess = 1,
                                                   @DTACFID = @dtacfid,
                                                   @Filters = @filter,
                                                   @DynamicSQL = @dynamicSQL OUTPUT

            INSERT INTO #tmp_FilteredClaims
            EXEC (@dynamicSQL)

            DECLARE @sEncryptData varchar(max) =
            '	''"'' + CONVERT(VARCHAR(MAX), DecryptByKey(c.[Oepps.fname])) + ''"''  AS ["Oepps":~"fname":],
		    ''"'' + CONVERT(VARCHAR(MAX), DecryptByKey(c.[Oepps.mname])) + ''"''  AS ["Oepps":~"mname":],
		    ''"'' + CONVERT(VARCHAR(MAX), DecryptByKey(c.[Oepps.lname])) + ''"''  AS ["Oepps":~"lname":],
		    ''"'' + CONVERT(VARCHAR(MAX), DecryptByKey(c.[Oepps.claim_id])) + ''"'' COLLATE SQL_Latin1_General_CP1_CS_AS AS ["Oepps":~"claim_id":],
		    ''"'' + CONVERT(VARCHAR(MAX), DecryptByKey(c.[Oepps.member_id])) + ''"''  AS ["Oepps":~"member_id":],
		    ''"'' + FORMAT(CONVERT(DATE, DecryptByKey(c.[Pcb1.birth_date])), ''yyyyMMdd'') + ''"'' AS ["Input":~"PatientClaim":~"birth_date":],
		    ''"'' + FORMAT(CONVERT(DATE, DecryptByKey(c.[Pcb1.from_date])), ''yyyyMMdd'') + ''"'' AS ["Input":~"PatientClaim":~"from_date":],
		    ''"'' + FORMAT(CONVERT(DATE, DecryptByKey(c.[Pcb1.admit_date])), ''yyyyMMdd'') + ''"'' AS ["Input":~"PatientClaim":~"admit_date":],
		    ''"'' + FORMAT(CONVERT(DATE, DecryptByKey(c.[Pcb1.thru_date])), ''yyyyMMdd'') + ''"'' AS ["Input":~"PatientClaim":~"thru_date":],
		    ''"'' + CONVERT(VARCHAR(MAX), DecryptByKey(c.[Pcb1.med_num])) + ''"''  AS ["Input":~"PatientClaim":~"med_num":],
		    ''"'' + CONVERT(VARCHAR(MAX), DecryptByKey(c.[Pcb1.ctr_num])) + ''"''  AS ["Input":~"PatientClaim":~"ctr_num":],
		    ''"'' + CONVERT(VARCHAR(MAX), DecryptByKey(c.[Pcb1.hplan_id])) + ''"''  AS ["Input":~"PatientClaim":~"hplan_id":] ';
            DECLARE @SQL varchar(max) = 'SELECT DISTINCT  cd.ClaimData, ' + @sEncryptData +
            ' FROM dbo.[DTA_Claim] c WITH(NOLOCK) INNER JOIN dbo.[DTA_ClaimData] cd WITH(NOLOCK) on cd.dtacid = c.dtacid 
            INNER JOIN #tmp_FilteredClaims fc on fc.dtacid = c.dtacid '
            EXEC (@SQL)
        END
        DROP TABLE IF EXISTS #tmp_WFTaskRelation, #tmp_ParentExecutionList, #tmp_FilteredClaims
    END TRY
    BEGIN CATCH
        SET @errorMessage = ERROR_MESSAGE();
        EXEC [sp_DTA_EventLog_Insert_SP] 'sp_OEPPS_Claims_Get',
                                         @errorMessage,
                                         @@TRANCOUNT,
                                         @currentStep
        RAISERROR (@errorMessage, 16, 1)
    END CATCH
END