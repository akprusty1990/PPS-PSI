﻿



-- ============================================================================        
-- Author:  Alex Chern        
-- Create date: 07/03/2018        
-- Description:         
-- This stored procedure is to save the xml format data of Schedule        
-- into database table DTA_Schedule. With following validations:        
-- 1. Validate to make sure that there is no more than one workflow scheduled for the same time.
-- 2. Validate to make sure the same workflow is not scheduled at different time. 
-- 3. Update the ModifiedTS in the table DTA_Schedule
-- 4. Insert the schedule into the table DTA_Schedule if the validation passed.  
-- 5. Update Status as In Progress and ScheduleStatus as Scheduled on 08/27/2018 
-- =============================================================================       
-- Modified On: 10/07/2020
-- Modified By: Joe Lango
-- Modification: Added validation check that the Schedule exists.

/*******************************************************************************
--Test case 1: No tasks Workflow. There s/b error:
'Info: The workflow cannot be scheduled without any tasks. Please assign tasks to the workflow.'
DECLARE @inXml VARCHAR(MAX)

SET @inXml = 
'<data>
	<DtaSchedule>
		<DtaWFID>1086</DtaWFID>
		<ScheduleType>recurring</ScheduleType>
		<ScheduleDate>7/13/2018 10:30 PM</ScheduleDate>
		<Frequency>Weekly</Frequency>
		<RecursiveEvery>weekday</RecursiveEvery>
		<ModifiedBy>Alex C</ModifiedBy>
	</DtaSchedule>
</data>'

EXEC  [dbo].[sp_DTA_Schedule_Save] @inXml

*********************************************************************
--Test case 2: Multiple Workflows at the same time. There s/b error:
'Info: The workflow cannot be scheduled at this time. Please try a different time or refresh the page to see the latest set of scheduled workflows'
DECLARE @inXml VARCHAR(MAX)

SET @inXml = 
'<data>
	<DtaSchedule>
		<DtaWFID>5</DtaWFID>
		<ScheduleType>recurring</ScheduleType>
		<ScheduleDate>7/13/2018 04:00:00 AM</ScheduleDate>
		<Frequency>Weekly</Frequency>
		<RecursiveEvery>weekday</RecursiveEvery>
		<ModifiedBy>Alex C</ModifiedBy>
	</DtaSchedule>
</data>'

EXEC  [dbo].[sp_DTA_Schedule_Save] @inXml

*********************************************************************
--Test case 3: 
Insert Data in DTA_Schedule

DECLARE @inXml VARCHAR(MAX)

SET @inXml = 
'<data>
	<DtaSchedule>
		<DtaWFID>8</DtaWFID>
		<ScheduleType>recurring</ScheduleType>
		<ScheduleDate>7/14/2018 22:00:00</ScheduleDate>
		<Frequency>Weekly</Frequency>
		<RecursiveEvery>weekday</RecursiveEvery>
		<ModifiedBy>Alex C</ModifiedBy>
	</DtaSchedule>
</data>'

EXEC  [dbo].[sp_DTA_Schedule_Save] @inXml

*********************************************************************
--Test case 4: 
Upate Data in DTA_Schedule. Test is valid for oepps_Dev. For other DBs make sure workflow and schedule info in place

DECLARE @inXml VARCHAR(MAX)

SET @inXml = 
'<data>
	<DtaSchedule>
		<DtaWFID>2401</DtaWFID>
		<ScheduleDate>2018-10-07T06:00:00Z</ScheduleDate>
		<Dtasid>1462,1463,1464</Dtasid>
	</DtaSchedule>
</data>'

EXEC  [dbo].[sp_DTA_Schedule_Save] @inXml

*********************************************************************/

CREATE PROCEDURE [dbo].[sp_DTA_Schedule_Save] @inXml varchar(max) = NULL

AS
BEGIN

	DECLARE @DtaWFID int
		, @ScheduleDate datetime2(0)
		, @nRecNo int
		, @nALLOWED_WORKFLOW_NO int = 10
		, @DTASID varchar(MAX)
		, @currentStep varchar(100)
		, @ErrorMessage varchar(4000)
		, @IsCreateSchedule bit
	;
	DECLARE @DTASID_split table (
		DTASID_value varchar(MAX)
	);

	SET NOCOUNT ON

	BEGIN TRY
		SET @currentStep = 'Check input xml is valid.'
		IF (RTRIM(ISNULL(@inXml, '')) = '')
		BEGIN
			SET @ErrorMessage = 'ERROR: No schedule data provided.'
			RAISERROR (@ErrorMessage, 16, 1)
		END

		SET @currentStep = 'Parse xml.'
		-- parse the xml
		DECLARE @iDoc AS int
		SET @iDoc = NULL

		EXEC sp_xml_preparedocument	@iDoc OUTPUT,
									@inXml

		-- load Schedule data from xml to temp table
		SELECT * 
		INTO #tmpDTA_Schedule
		FROM OPENXML(@iDoc, '/data/DtaSchedule', 2)
		WITH
		(
			[DtaWFID] [int],
			[ScheduleType] [varchar](50),
			[ScheduleDate] [datetime2],
			[Dtasid] [varchar](MAX),
			[Frequency] [varchar](50),
			[RecursiveEvery] [varchar](50),
			[InsertedTS] [datetime],
			[ModifiedBy] [varchar](50)
		) xmlData

		-- clean up xml
		EXEC sp_xml_removedocument @iDoc
		SET @iDoc = NULL

		SELECT @DtaWFID = [DtaWFID]
			, @ScheduleDate = [ScheduleDate]
			, @DTASID = [DTASID]
		FROM #tmpDTA_Schedule
		;

		SET @IsCreateSchedule = CASE 
			WHEN ISNULL(@DTASID, '') = '' THEN 1
			ELSE 0
		END
		;

		INSERT INTO @DTASID_split
		SELECT RTRIM(LTRIM(value)) FROM STRING_SPLIT(@DTASID, ',')
		;

		-- Validate concurrent tasks
		SET @currentStep = 'Validate concurrent tasks.'
		SELECT @nRecNo = COUNT(*)
		FROM
			(SELECT DISTINCT [DTAWFID]
			FROM [dbo].[DTA_Schedule] s (nolock)
			JOIN [dbo].[DTA_WorkflowTask] wt (nolock)
			ON s.[DTAWFTID] = wt.[DTAWFTID]
			AND wt.[DTAWFID] <> @DtaWFID 
			WHERE ABS(DATEDIFF(mi, [ScheduleDate], @ScheduleDate)) < 60) wf

		IF @nRecNo + 1 > @nALLOWED_WORKFLOW_NO
		BEGIN
			SET @ErrorMessage = 'Info: The workflow cannot be scheduled at this time. Please try a different time or refresh the page to see the latest set of scheduled workflows.'
			RAISERROR (@ErrorMessage, 16, 1)
		END 
			
		-- Validate concurrent dates
		SET @currentStep = 'Validate concurrent dates.'
		SELECT @nRecNo = Count(*)
		FROM
			(SELECT  [DtaWFID], [ScheduleDate] 
			FROM [dbo].[DTA_Schedule] s (nolock)
			JOIN [dbo].[DTA_WorkflowTask] wt (nolock)
			ON
			s.[DTAWFTID] = wt.[DTAWFTID]
			AND [DtaWFID] = @DtaWFID
			AND [ScheduleDate] = @ScheduleDate) wf

		IF @nRecNo > 0
		BEGIN
			SET @ErrorMessage = 'Info: The workflow cannot be scheduled at this time. Please try a different time or refresh the page to see the latest set of scheduled workflows.'
			RAISERROR (@ErrorMessage, 16, 1)
		END

		SET @currentStep = 'Validate workflow tasks.'
		IF NOT EXISTS(
			SELECT *
			FROM [dbo].[DTA_WorkflowTask] (nolock)
			WHERE [DTAWFID] = @DtaWFID)

			BEGIN
				SET @ErrorMessage = 'Info: The workflow cannot be scheduled without any tasks. Please assign tasks to the workflow.'
				RAISERROR (@ErrorMessage, 16, 1)
			END

		-- If this is an edit, the Schedule must exist
		IF @IsCreateSchedule = 0 BEGIN
			SET @currentStep = 'Validate existing DTASID';
			IF NOT EXISTS(SELECT DTASID FROM dbo.DTA_Schedule WHERE CAST([DTASID] AS varchar(MAX)) IN (SELECT DTASID_value FROM @DTASID_split)) BEGIN
				SET @ErrorMessage = 'Info: The schedule does not exist.  Please refresh the page to see the latest set of scheduled workflows.';
				RAISERROR (@ErrorMessage, 16, 1);
			END
		END
	
		-- Update/insert into DTA_Schedule

		IF @IsCreateSchedule = 1 BEGIN		-- insert
			SET @currentStep = 'Insert new schedule.'
			INSERT INTO DTA_Schedule
				([DtaWFTID],
				[Frequency],
				[InsertedTS],
				[ModifiedBy],
				[RecursiveEvery],
				[ScheduleDate],
				[ScheduleType])
			SELECT
				[DtaWFTID],
				[Frequency],
				GETUTCDATE(),
				[ModifiedBy],
				[RecursiveEvery],
				@ScheduleDate,
				[ScheduleType]
			FROM #tmpDTA_Schedule t
			JOIN [dbo].[DTA_WorkflowTask] wt (nolock)
			ON t.[DTAWFID] = wt.[DTAWFID]

			SET @currentStep = 'Update schedule status in DTA_Workflow'
			UPDATE DTA_Workflow
			SET [ScheduleStatus] = 'Scheduled'
			WHERE [DTAWFID] = @DtaWFID
		END
		ELSE BEGIN
			-- Do not change schedule if it was set for execution
			SET @currentStep = 'Check if schedule was set for execution.'
			IF EXISTS(SELECT DTAEID
						FROM [dbo].[DTA_EXECUTION] WITH(NOLOCK)
						WHERE [DTASID] IN (SELECT DTASID_value FROM @DTASID_split)) BEGIN
				SET @ErrorMessage = 'Info: The workflow cannot be scheduled at this time.'
				RAISERROR (@ErrorMessage, 16, 1)
			END

			SET @currentStep = 'Update existing schedule.'
			UPDATE [dbo].[DTA_Schedule]		-- Update existing rows in DTA_Schedule
			SET 
				[Frequency] = t.[Frequency],
				[InsertedTS] = GETUTCDATE(),
				[ModifiedBy] = t.[ModifiedBy],
				[RecursiveEvery] = t.[RecursiveEvery],
				[ScheduleDate] = t.[ScheduleDate],
				[ScheduleType] = t.[ScheduleType]
			FROM #tmpDTA_Schedule t 
			WHERE [dbo].[DTA_Schedule].[DTASID] IN (
				SELECT DTASID_value FROM @DTASID_split
			);
		END

		DROP TABLE #tmpDTA_Schedule
	END TRY
	BEGIN CATCH

		IF (ISNULL(@ErrorMessage, '') = '')
		BEGIN
			SELECT
				@ErrorMessage = 'ERROR: ' +  ERROR_MESSAGE()
		END

		IF NOT OBJECT_ID('tempdb..#tmpDTA_Schedule') IS NULL
			DROP TABLE #tmpDTA_Schedule
		
		EXEC [sp_DTA_EventLog_Insert_SP] 'sp_DTA_Schedule_Save', @ErrorMessage, @@TRANCOUNT, @currentStep
		RAISERROR (@ErrorMessage, 16, 1)

	END CATCH

END