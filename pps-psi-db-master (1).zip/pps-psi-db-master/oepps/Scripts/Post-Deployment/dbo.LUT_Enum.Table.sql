﻿
INSERT [dbo].[LUT_Enum] ([LUTEID], [EnumName], [EnumValue], [EnumDescription]) VALUES (1, 'TypeEnum', 1, 'Information')
INSERT [dbo].[LUT_Enum] ([LUTEID], [EnumName], [EnumValue], [EnumDescription]) VALUES (2, 'TypeEnum', 2, 'Warning')
INSERT [dbo].[LUT_Enum] ([LUTEID], [EnumName], [EnumValue], [EnumDescription]) VALUES (3, 'TypeEnum', 3, 'Error')
INSERT [dbo].[LUT_Enum] ([LUTEID], [EnumName], [EnumValue], [EnumDescription]) VALUES (4, 'TypeEnum', 4, 'Exception')
INSERT [dbo].[LUT_Enum] ([LUTEID], [EnumName], [EnumValue], [EnumDescription]) VALUES (5, 'ApplicationEnum', 1, 'Web')
INSERT [dbo].[LUT_Enum] ([LUTEID], [EnumName], [EnumValue], [EnumDescription]) VALUES (6, 'ApplicationEnum', 2, 'DB')
INSERT [dbo].[LUT_Enum] ([LUTEID], [EnumName], [EnumValue], [EnumDescription]) VALUES (7, 'SourceEnum', 1, 'Screens')
INSERT [dbo].[LUT_Enum] ([LUTEID], [EnumName], [EnumValue], [EnumDescription]) VALUES (8, 'SourceEnum', 2, 'SystemAdmin')
INSERT [dbo].[LUT_Enum] ([LUTEID], [EnumName], [EnumValue], [EnumDescription]) VALUES (9, 'SourceEnum', 3, 'Stored Procedure')
INSERT [dbo].[LUT_Enum] ([LUTEID], [EnumName], [EnumValue], [EnumDescription]) VALUES (10, 'ApplicationEnum', 3, 'API')
INSERT [dbo].[LUT_Enum] ([LUTEID], [EnumName], [EnumValue], [EnumDescription]) VALUES (11, 'SourceEnum', 4, 'API')

