﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]		
--------------------------------------------------------------------------------------
*/
TRUNCATE TABLE [dbo].[ADM_Group];
TRUNCATE TABLE [dbo].[ADM_Permission];
TRUNCATE TABLE [dbo].[LUT_Claim];
TRUNCATE TABLE [dbo].[LUT_ClaimToForm];
TRUNCATE TABLE [dbo].[LUT_ClaimVariable];
TRUNCATE TABLE [dbo].[LUT_ComparisonOperator];
TRUNCATE TABLE [dbo].[LUT_ConditionalOperator];
TRUNCATE TABLE [dbo].[LUT_Enum];
TRUNCATE TABLE [dbo].[LUT_StatusCode];
TRUNCATE TABLE [dbo].[TML_ClaimVariable];
TRUNCATE TABLE [dbo].[TML_ClaimVariableAttr];
TRUNCATE TABLE [dbo].[LUT_CBlock_Structures];
TRUNCATE TABLE [dbo].[LUT_MappingElements];
TRUNCATE TABLE [dbo].[TML_ProcessInfoVariable];
TRUNCATE TABLE [dbo].[LUT_Report];
TRUNCATE TABLE [dbo].[LUT_ReportVariable];
--Delete From [dbo].[ADM_OEPPS_Folder];
--Delete From [dbo].[ADM_OEPPS_Server];

/*drop fk constraint*/
ALTER TABLE [dbo].[DTA_Task] DROP CONSTRAINT [FK_DTA_Task_LUT_TaskName]
TRUNCATE TABLE [dbo].[LUT_TaskType];

--:r dbo.ADM_OEPPS_Server.Table.sql
--:r dbo.ADM_OEPPS_Folder.Table.sql
:r dbo.ADM_Group.Table.sql
:r dbo.ADM_Permission.Table.sql
:r dbo.LUT_Claim.Table.sql
:r dbo.LUT_ClaimToForm.Table.sql
:r dbo.LUT_ClaimVariable.Table.sql
:r dbo.LUT_ComparisonOperator.Table.sql
:r dbo.LUT_ConditionalOperator.Table.sql
:r dbo.LUT_Enum.Table.sql
:r dbo.LUT_StatusCode.Table.sql
:r dbo.LUT_TaskType.Table.sql
:r dbo.TML_ClaimVariable.Table.sql
:r dbo.TML_ClaimVariableAttr.Table.sql
:r dbo.LUT_CBlock_Structures.Table.sql
:r dbo.LUT_MappingElements.Table.sql
:r dbo.TML_ProcessInfoVariable.Table.sql
:r dbo.LUT_Report.Table.sql
:r dbo.LUT_ReportVariable.Table.sql
/*add fk constraint back*/
ALTER TABLE [dbo].[DTA_Task] ADD CONSTRAINT [FK_DTA_Task_LUT_TaskName] FOREIGN KEY ([LUTTTID]) REFERENCES [dbo].[LUT_TaskType] ([LUTTTID])
